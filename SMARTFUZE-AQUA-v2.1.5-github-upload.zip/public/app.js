/* SMARTFUZE AQUA v2.0.0 - dashboard
 * Displays only what the server has received from real hardware.
 * When there is nothing real to show, it says so ("—", "Waiting for real hardware").
 */
'use strict';
(() => {
  // ------------------------------------------------------------ utilities
  const $ = (s, r = document) => r.querySelector(s);
  const $$ = (s, r = document) => [...r.querySelectorAll(s)];
  const esc = v => String(v ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const isNum = v => typeof v === 'number' && Number.isFinite(v);
  const fmt = (v, d = 2) => (isNum(v) ? v.toFixed(d) : '—');
  const DASH = '—';

  function rel(ts) {
    if (!ts) return DASH;
    const s = Math.max(0, Math.round((Date.now() - Date.parse(ts)) / 1000));
    if (s < 10) return 'just now';
    if (s < 60) return s + ' s ago';
    if (s < 3600) return Math.floor(s / 60) + ' min ago';
    if (s < 86400) return Math.floor(s / 3600) + ' h ' + Math.floor((s % 3600) / 60) + ' min ago';
    return Math.floor(s / 86400) + ' d ago';
  }
  const clock = ts => (ts ? new Date(ts).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' }) : DASH);
  const dateTime = ts => (ts ? new Date(ts).toLocaleString([], { day: '2-digit', month: 'short', hour: '2-digit', minute: '2-digit' }) : DASH);
  function uptime(sec) {
    if (!isNum(sec)) return DASH;
    const d = Math.floor(sec / 86400), h = Math.floor((sec % 86400) / 3600), m = Math.floor((sec % 3600) / 60);
    return (d ? d + 'd ' : '') + (d || h ? h + 'h ' : '') + m + 'm';
  }
  function rssiLabel(r) {
    if (!isNum(r)) return DASH;
    const q = r > -60 ? 'strong' : r > -72 ? 'good' : r > -82 ? 'weak' : 'poor';
    return r + ' dBm, ' + q;
  }

  const I = (name, cls = '') => `<svg class="${cls}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${ICONS[name] || ''}</svg>`;
  const ICONS = {
    home: '<path d="M3 11l9-7 9 7"/><path d="M5 10v10h14V10"/><path d="M10 20v-5h4v5"/>',
    ponds: '<path d="M2 8c2.5 2 5 2 7.5 0s5-2 7.5 0 3.5 2 5 1"/><path d="M2 13c2.5 2 5 2 7.5 0s5-2 7.5 0 3.5 2 5 1"/><path d="M2 18c2.5 2 5 2 7.5 0s5-2 7.5 0 3.5 2 5 1"/>',
    trends: '<path d="M3 17l6-6 4 4 8-8"/><path d="M15 7h6v6"/>',
    feed: '<path d="M4 11h16a8 8 0 0 1-16 0z"/><circle cx="9" cy="6" r="1.2"/><circle cx="13" cy="4.5" r="1.2"/><circle cx="15.5" cy="7.5" r="1.2"/>',
    controls: '<path d="M4 6h10M18 6h2M4 12h4M12 12h8M4 18h12"/><circle cx="16" cy="6" r="2"/><circle cx="10" cy="12" r="2"/><circle cx="18" cy="18" r="2"/>',
    apps: '<rect x="3" y="3" width="7" height="7" rx="2"/><rect x="14" y="3" width="7" height="7" rx="2"/><rect x="3" y="14" width="7" height="7" rx="2"/><path d="M17.5 14v7M14 17.5h7"/>',
    alerts: '<path d="M6 16v-5a6 6 0 0 1 12 0v5l2 2H4z"/><path d="M10 21h4"/>',
    calibration: '<path d="M9 3h6M10 3v6l-5 9a2 2 0 0 0 1.8 3h10.4a2 2 0 0 0 1.8-3l-5-9V3"/><path d="M7.5 15h9"/>',
    settings: '<circle cx="12" cy="12" r="3"/><path d="M12 2v3M12 19v3M2 12h3M19 12h3M4.9 4.9 7 7M17 17l2.1 2.1M4.9 19.1 7 17M17 7l2.1-2.1"/>',
    more: '<circle cx="5" cy="12" r="1.6"/><circle cx="12" cy="12" r="1.6"/><circle cx="19" cy="12" r="1.6"/>',
    thermo: '<path d="M14 14.8V5a2 2 0 0 0-4 0v9.8a4 4 0 1 0 4 0z"/><path d="M12 9v7"/>',
    drop: '<path d="M12 3c-4 5-7 8.5-7 12a7 7 0 0 0 14 0c0-3.5-3-7-7-12z"/><path d="M9 15.5a3 3 0 0 0 3 2.5"/>',
    chip: '<rect x="6" y="6" width="12" height="12" rx="2"/><path d="M9 2v4M15 2v4M9 18v4M15 18v4M2 9h4M2 15h4M18 9h4M18 15h4"/>',
    clock: '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
    aerator: '<circle cx="12" cy="12" r="2"/><path d="M12 10c0-4 1-7 4-7 2 0 2 3 0 5M14 12c4 0 7 1 7 4 0 2-3 2-5 0M12 14c0 4-1 7-4 7-2 0-2-3 0-5M10 12c-4 0-7-1-7-4 0-2 3-2 5 0"/>',
    pump: '<circle cx="9" cy="13" r="5"/><path d="M14 13h7M18 10v6M9 8V4h4"/><path d="M7 13h4"/>',
    camera: '<rect x="3" y="7" width="13" height="10" rx="2"/><path d="M16 11l5-3v8l-5-3"/>',
    plug: '<path d="M9 7V3M15 7V3M7 7h10v4a5 5 0 0 1-10 0z"/><path d="M12 16v5"/>',
    wifi: '<path d="M2 9a15 15 0 0 1 20 0M5 12.5a10 10 0 0 1 14 0M8.5 16a5 5 0 0 1 7 0"/><circle cx="12" cy="19" r="1"/>',
    external: '<path d="M14 4h6v6M20 4l-9 9M18 14v5a1 1 0 0 1-1 1H5a1 1 0 0 1-1-1V7a1 1 0 0 1 1-1h5"/>',
    code: '<path d="M8 8l-5 4 5 4M16 8l5 4-5 4"/>',
    plus: '<path d="M12 5v14M5 12h14"/>',
    mqtt: '<circle cx="12" cy="12" r="2"/><path d="M7.8 7.8a6 6 0 0 0 0 8.4M16.2 7.8a6 6 0 0 1 0 8.4M4.9 4.9a10 10 0 0 0 0 14.2M19.1 4.9a10 10 0 0 1 0 14.2"/>',
    edit: '<path d="M4 20h4L19 9l-4-4L4 16z"/>',
    trash: '<path d="M4 7h16M10 11v6M14 11v6M6 7l1 13h10l1-13M9 7V4h6v3"/>',
    download: '<path d="M12 4v11M7 10l5 5 5-5M5 20h14"/>',
    shield: '<path d="M12 3l8 3v6c0 5-3.5 8-8 9-4.5-1-8-4-8-9V6z"/>',
    box: '<path d="M3 7l9-4 9 4v10l-9 4-9-4z"/><path d="M3 7l9 4 9-4M12 11v10"/>',
    water: '<path d="M9 3h6M10 3v14a2 2 0 0 0 4 0V3"/><path d="M10 11h4"/>',
    cycle: '<path d="M4 12a8 8 0 0 1 14-5.3L20 9"/><path d="M20 4v5h-5"/><path d="M20 12a8 8 0 0 1-14 5.3L4 15"/><path d="M4 20v-5h5"/>',
    level: '<path d="M3 17c3 2 6 2 9 0s6-2 9 0"/><path d="M3 12h18" stroke-dasharray="2 3"/><path d="M12 3v6M9 6l3 3 3-3"/>',
    o2: '<circle cx="9" cy="14" r="5"/><circle cx="17" cy="7" r="3"/>',
    poc: '<path d="M9 3h6v4l4 9a3 3 0 0 1-2.7 4.3H7.7A3 3 0 0 1 5 16l4-9z"/><path d="M8 13h8"/><circle cx="11" cy="16.5" r="0.8"/>',
    finance: '<rect x="3" y="5" width="18" height="14" rx="2"/><path d="M3 10h18M7 15h4"/>',
    vault: '<rect x="4" y="4" width="16" height="16" rx="2"/><circle cx="12" cy="12" r="3"/><path d="M12 9V7M15 12h2"/>',
    audit: '<path d="M8 4h11v16H5V7z"/><path d="M8 4v3H5M9 12l2 2 4-4M9 17h6"/>',
    users: '<circle cx="9" cy="8" r="3.5"/><path d="M2.5 20a6.5 6.5 0 0 1 13 0"/><path d="M16 4.5a3.5 3.5 0 0 1 0 7M18 14a6 6 0 0 1 3.5 6"/>',
    lock: '<rect x="5" y="11" width="14" height="9" rx="2"/><path d="M8 11V8a4 4 0 0 1 8 0v3"/>',
    investor: '<path d="M4 20V10M10 20V4M16 20v-7M22 20H2"/>'
  };

  // ------------------------------------------------------------ state
  const state = {
    ponds: {}, selected: null, info: null,
    integrations: [], catalog: null,
    feeding: { schedules: [], events: [] },
    alerts: { rules: [], alerts: [] },
    calibrations: [], controls: null,
    water: { entries: [], limits: {} }, cycles: [], full: null, auth: null, creds: null,
    biz: { meta: null, pocs: null, pocSel: null, expenses: null, inbox: null, fin: null, finFilter: {}, evidence: null, evFilter: {}, audit: null, auditFilter: {}, users: null },
    history: {}, trendsRange: '24h',
    ws: null, wsOk: false, loaded: false
  };
  try { state.selected = localStorage.getItem('aqua.pond') || null; } catch (_) {}

  const ROUTES = [
    { id: 'overview', title: 'Overview', icon: 'home', group: 'Monitoring', perm: 'monitor.read' },
    { id: 'ponds', title: 'Ponds', icon: 'ponds', group: 'Monitoring', perm: 'monitor.read' },
    { id: 'trends', title: 'Trends', icon: 'trends', group: 'Monitoring', perm: 'monitor.read' },
    { id: 'water', title: 'Water quality', icon: 'water', group: 'Monitoring', perm: 'monitor.read' },
    { id: 'cycle', title: 'Crop cycle', icon: 'cycle', group: 'Monitoring', perm: 'monitor.read' },
    { id: 'feeding', title: 'Feeding', icon: 'feed', group: 'Monitoring', perm: 'monitor.read' },
    { id: 'controls', title: 'Controls', icon: 'controls', group: 'Monitoring', perm: 'monitor.read' },
    { id: 'alerts', title: 'Alerts', icon: 'alerts', group: 'Monitoring', perm: 'monitor.read' },
    { id: 'calibration', title: 'Calibration', icon: 'calibration', group: 'Monitoring', perm: 'monitor.read' },
    { id: 'poc', title: 'POC research', icon: 'poc', group: 'Business', perm: 'poc.read' },
    { id: 'finance', title: 'Finance', icon: 'finance', group: 'Business', perm: 'finance.read' },
    { id: 'evidence', title: 'Evidence vault', icon: 'vault', group: 'Business', perm: 'evidence.read' },
    { id: 'audit', title: 'Audit log', icon: 'audit', group: 'Business', perm: 'audit.read' },
    { id: 'investor', title: 'Investor center', icon: 'investor', group: 'Business', perm: 'investor' },
    { id: 'apps', title: 'Apps & Integrations', icon: 'apps', group: 'System', perm: 'monitor.read' },
    { id: 'settings', title: 'Settings', icon: 'settings', group: 'System', perm: 'settings.view' }
  ];
  const hasPerm = p => {
    const ps = state.auth?.perms || [];
    if (p === 'investor') return state.auth?.role === 'investor';
    if (p === 'settings.view') return !!state.auth?.signedIn || ps.includes('monitor.read') || ps.includes('*');
    return ps.includes('*') || ps.includes(p);
  };
  const allowedRoutes = () => ROUTES.filter(r => hasPerm(r.perm));
  const MOBILE = [
    { id: 'overview', label: 'Home', icon: 'home' },
    { id: 'ponds', label: 'Ponds', icon: 'ponds' },
    { id: 'feeding', label: 'Feed', icon: 'feed' },
    { id: 'apps', label: 'Apps', icon: 'apps' },
    { id: 'more', label: 'More', icon: 'more' }
  ];
  const MORE_BASE = ['trends', 'water', 'cycle', 'controls', 'alerts', 'calibration', 'poc', 'finance', 'evidence', 'audit', 'investor', 'settings'];
  const moreIds = () => MORE_BASE.filter(id => hasPerm(ROUTES.find(r => r.id === id).perm));

  const PROVIDER_UI = {
    esp32: { icon: 'chip', desc: 'Sensor node on AQUA MQTT' },
    tuya: { icon: 'plug', desc: 'Tuya / Smart Life devices' },
    tapo: { icon: 'camera', desc: 'Tapo cameras and plugs' },
    vson: { icon: 'box', desc: 'VSON Smart devices' },
    mqtt: { icon: 'mqtt', desc: 'Any device speaking MQTT' },
    onvif: { icon: 'camera', desc: 'ONVIF / RTSP camera' },
    rest: { icon: 'code', desc: 'HTTP API you control' },
    external: { icon: 'external', desc: 'Open a manufacturer app' },
    custom: { icon: 'apps', desc: 'Anything else' }
  };
  const MODE_TEXT = {
    external: 'External app: AQUA opens the manufacturer app. Control and confirmation happen there.',
    mqtt: 'MQTT: AQUA publishes commands to a topic on its own broker. Confirmed only if the device acknowledges.',
    rest: 'REST: an HTTP API address is stored now; AQUA will call it in a later version.',
    onvif: 'ONVIF / RTSP: the stream address is stored now; live preview arrives in v2.3.0.',
    native: 'Native: a built-in AQUA driver. Not available for this provider in v2.0.0.'
  };

  const route = () => {
    const id = (location.hash.replace(/^#\/?/, '') || 'overview').split('?')[0];
    const ok = allowedRoutes();
    return ok.some(r => r.id === id) ? id : (ok[0]?.id || 'settings');
  };
  const pondList = () => Object.values(state.ponds).sort((a, b) => a.id.localeCompare(b.id, undefined, { numeric: true }));
  function selectedPond() {
    const list = pondList();
    if (!list.length) return null;
    return state.ponds[state.selected] || list[0];
  }
  function setSelected(id) {
    state.selected = id;
    try { localStorage.setItem('aqua.pond', id); } catch (_) {}
  }
  const rule = id => state.alerts.rules.find(r => r.id === id);
  const activeAlerts = () => state.alerts.alerts.filter(a => !a.resolvedAt);

  // ------------------------------------------------------------ API
  async function api(path, opts = {}) {
    const res = await fetch('/api' + path, {
      method: opts.method || 'GET',
      headers: opts.body ? { 'Content-Type': 'application/json', 'X-AQUA': '1' } : { 'X-AQUA': '1' },
      body: opts.body ? JSON.stringify(opts.body) : undefined,
      cache: 'no-store'
    });
    let data = null;
    try { data = await res.json(); } catch (_) {}
    if (res.status === 401 && !path.startsWith('/auth/') && (state.auth?.required || state.auth?.signedIn)) showLogin('Please sign in again.');
    if (!res.ok) { const err = new Error((data && data.error) || 'Request failed (' + res.status + ')'); err.status = res.status; err.data = data; throw err; }
    return data;
  }
  const load = {
    async ponds() { const list = await api('/ponds'); state.ponds = {}; for (const p of list) state.ponds[p.id] = p; },
    async info() { state.info = await api('/info'); },
    async integrations() { state.integrations = await api('/integrations'); if (!state.catalog) state.catalog = await api('/integrations/catalog'); },
    async feeding() { state.feeding = await api('/feeding'); },
    async alerts() { state.alerts = await api('/alerts'); },
    async calibrations() { state.calibrations = await api('/calibrations'); },
    async controls() { state.controls = await api('/controls'); },
    async water() { state.water = await api('/water'); },
    async cycles() { state.cycles = await api('/cycles'); },
    async full() { state.full = await api('/settings/full'); },
    async history(pondId, range) {
      const h = await api(`/ponds/${encodeURIComponent(pondId)}/readings?range=${range}`);
      state.history[pondId + '|' + range] = h;
      return h;
    }
  };
  async function loadAll() {
    if (hasPerm('monitor.read')) {
      await Promise.allSettled([load.ponds(), load.info(), load.integrations(), load.feeding(), load.alerts(), load.calibrations(), load.controls(), load.water(), load.cycles(), hasPerm('config.write') ? load.full() : Promise.resolve()]);
    }
    state.loaded = true;
  }

  // ------------------------------------------------------------ toasts & modal
  function toast(msg, kind = '') {
    const el = document.createElement('div');
    el.className = 'toast ' + kind;
    el.textContent = msg;
    $('#toasts').appendChild(el);
    setTimeout(() => el.remove(), kind === 'err' ? 6500 : 4200);
  }
  let modalOnClose = null;
  function openModal(html, { wide = false, onClose = null } = {}) {
    closeModal();
    modalOnClose = onClose;
    const root = $('#modalRoot');
    root.innerHTML = `<div class="modal-wrap" data-close><div class="modal ${wide ? 'wide' : ''}" role="dialog" aria-modal="true">${html}</div></div>`;
    root.querySelector('.modal-wrap').addEventListener('click', e => { if (e.target.hasAttribute('data-close')) closeModal(); });
    const first = root.querySelector('input, select, textarea, button.primary, button');
    if (first) setTimeout(() => first.focus(), 30);
    return root.querySelector('.modal');
  }
  function closeModal() {
    const root = $('#modalRoot');
    if (!root.innerHTML) return;
    root.innerHTML = '';
    const fn = modalOnClose; modalOnClose = null;
    if (fn) fn();
  }
  document.addEventListener('keydown', e => { if (e.key === 'Escape') closeModal(); });
  function confirmDialog(title, text, okLabel = 'Delete', danger = true) {
    return new Promise(resolve => {
      let done = false;
      const m = openModal(`<h3>${esc(title)}</h3><p class="muted">${esc(text)}</p>
        <div class="modal-actions"><button class="btn" data-a="no">Cancel</button><button class="btn ${danger ? 'danger' : 'primary'}" data-a="yes">${esc(okLabel)}</button></div>`,
        { onClose: () => { if (!done) resolve(false); } });
      m.addEventListener('click', e => {
        const a = e.target.closest('[data-a]')?.dataset.a;
        if (!a) return;
        done = true; closeModal(); resolve(a === 'yes');
      });
    });
  }

  // ------------------------------------------------------------ chips
  function onlineChip(p) {
    if (!p) return `<span class="chip off"><span class="dot"></span>Waiting for real hardware</span>`;
    return p.online
      ? `<span class="chip ok"><span class="dot"></span>Online</span>`
      : `<span class="chip crit"><span class="dot"></span>Offline</span>`;
  }
  function feedChip(status) {
    const k = { 'Confirmed': 'ok', 'Failed': 'crit', 'Command Sent': 'info', 'External App Opened': 'warn', 'Skipped': 'warn' }[status] || 'off';
    return `<span class="chip ${k}">${esc(status)}</span>`;
  }
  function intChip(status) {
    const k = { 'Online': 'ok', 'Offline': 'crit', 'External App': 'info', 'Configured': 'info', 'Disabled': 'off' }[status] || 'off';
    return `<span class="chip ${k}">${esc(status)}</span>`;
  }
  const sevChip = s => `<span class="chip ${s === 'critical' ? 'crit' : 'warn'}">${s === 'critical' ? 'Critical' : 'Warning'}</span>`;

  // ------------------------------------------------------------ charts (dependency-free SVG)
  const charts = new Map();
  let chartSeq = 0;
  const RANGE_MS = { '24h': 86400000, '7d': 7 * 86400000, '30d': 30 * 86400000 };

  function chartSlot(spec) {
    const id = 'c' + (++chartSeq);
    charts.set(id, spec);
    return `<div class="chart" data-chart="${id}"></div>`;
  }
  function mountCharts() {
    for (const el of $$('[data-chart]')) {
      const spec = charts.get(el.dataset.chart);
      if (spec) drawChart(el, spec);
    }
  }
  function drawChart(el, spec) {
    const pts = (spec.points || []).filter(p => isNum(p[spec.key]));
    const H = spec.fill && el.clientHeight > 60 ? Math.floor(el.clientHeight) : (spec.height || 180);
    if (!pts.length) {
      el.innerHTML = `<div class="chart-empty" style="height:${H}px">${esc(spec.empty || 'No real history yet')}</div>`;
      return;
    }
    const W = Math.max(260, el.clientWidth || 600);
    const pad = { l: 40, r: 12, t: 12, b: 24 };
    const iw = W - pad.l - pad.r, ih = H - pad.t - pad.b;
    const to = spec.to || Date.now(), from = spec.from || to - RANGE_MS['24h'];
    let lo = Math.min(...pts.map(p => p[spec.key])), hi = Math.max(...pts.map(p => p[spec.key]));
    const minSpan = spec.minSpan || 1;
    if (hi - lo < minSpan) { const mid = (hi + lo) / 2; lo = mid - minSpan / 2; hi = mid + minSpan / 2; }
    const padV = (hi - lo) * 0.12; lo -= padV; hi += padV;
    const x = t => pad.l + ((t - from) / (to - from)) * iw;
    const y = v => pad.t + (1 - (v - lo) / (hi - lo)) * ih;
    const gapMs = Math.max((spec.bucketSec || 60) * 3000, 5 * 60000);

    let d = '', area = '', segStart = null, prev = null;
    const closeArea = () => { if (segStart !== null && prev) area += `L${x(prev.t).toFixed(1)},${(pad.t + ih).toFixed(1)}L${x(segStart).toFixed(1)},${(pad.t + ih).toFixed(1)}Z`; };
    for (const p of pts) {
      const px = x(p.t).toFixed(1), py = y(p[spec.key]).toFixed(1);
      if (!prev || p.t - prev.t > gapMs) { closeArea(); d += `M${px},${py}`; area += `M${px},${py}`; segStart = p.t; }
      else { d += `L${px},${py}`; area += `L${px},${py}`; }
      prev = p;
    }
    closeArea();

    const gid = 'g' + el.dataset.chart;
    let grid = '';
    for (let i = 0; i <= 3; i++) {
      const v = lo + ((hi - lo) * i) / 3, yy = y(v).toFixed(1);
      grid += `<line class="grid-line" x1="${pad.l}" x2="${W - pad.r}" y1="${yy}" y2="${yy}"/><text class="axis" x="${pad.l - 6}" y="${(+yy + 3).toFixed(1)}" text-anchor="end">${v.toFixed(spec.decimals ?? 1)}</text>`;
    }
    const span = to - from, xt = [];
    const narrow = W < 560;
    const step = span <= RANGE_MS['24h'] ? (narrow ? 8 : 4) * 3600000 : span <= RANGE_MS['7d'] ? (narrow ? 2 : 1) * 86400000 : (narrow ? 10 : 5) * 86400000;
    const first = Math.ceil(from / step) * step;
    for (let t = first; t <= to; t += step) xt.push(t);
    for (const t of xt) {
      const label = span <= RANGE_MS['24h']
        ? new Date(t).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
        : new Date(t).toLocaleDateString([], { day: '2-digit', month: 'short' });
      grid += `<text class="axis" x="${x(t).toFixed(1)}" y="${H - 6}" text-anchor="middle">${label}</text>`;
    }
    let band = '';
    if (spec.band && isNum(spec.band[0]) && isNum(spec.band[1])) {
      const b0 = Math.max(lo, spec.band[0]), b1 = Math.min(hi, spec.band[1]);
      if (b1 > b0) band = `<rect x="${pad.l}" width="${iw}" y="${y(b1).toFixed(1)}" height="${(y(b0) - y(b1)).toFixed(1)}" fill="${spec.color}" opacity="0.05"/>`;
    }
    el.innerHTML = `<svg viewBox="0 0 ${W} ${H}" height="${H}" role="img" aria-label="${esc(spec.label || spec.key)} chart">
      <defs><linearGradient id="${gid}" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="${spec.color}" stop-opacity="0.28"/><stop offset="1" stop-color="${spec.color}" stop-opacity="0"/></linearGradient></defs>
      ${band}${grid}
      <path d="${area}" fill="url(#${gid})"/>
      <path d="${d}" fill="none" stroke="${spec.color}" stroke-width="2" stroke-linejoin="round" stroke-linecap="round" style="filter:drop-shadow(0 0 6px ${spec.color}66)"/>
      <line class="hover-line" x1="0" x2="0" y1="${pad.t}" y2="${pad.t + ih}" stroke="rgba(228,242,247,.35)" stroke-dasharray="3 3" opacity="0"/>
      <circle class="hover-dot" r="4.5" fill="${spec.color}" stroke="#050B11" stroke-width="2" opacity="0"/>
      <rect class="hit" x="${pad.l}" y="${pad.t}" width="${iw}" height="${ih}" fill="transparent"/>
    </svg><div class="tip"></div>`;

    const svg = el.querySelector('svg'), tip = el.querySelector('.tip');
    const hl = el.querySelector('.hover-line'), dot = el.querySelector('.hover-dot');
    const move = ev => {
      const r = svg.getBoundingClientRect();
      const cx = ((ev.touches ? ev.touches[0].clientX : ev.clientX) - r.left) * (W / r.width);
      const t = from + ((cx - pad.l) / iw) * (to - from);
      let best = pts[0];
      for (const p of pts) if (Math.abs(p.t - t) < Math.abs(best.t - t)) best = p;
      const px = x(best.t), py = y(best[spec.key]);
      hl.setAttribute('x1', px); hl.setAttribute('x2', px); hl.setAttribute('opacity', 1);
      dot.setAttribute('cx', px); dot.setAttribute('cy', py); dot.setAttribute('opacity', 1);
      tip.style.left = (px / W * 100) + '%'; tip.style.top = (py / H * r.height) + 'px'; tip.style.opacity = 1;
      tip.innerHTML = `<b>${fmt(best[spec.key], spec.decimals ?? 2)}${esc(spec.unit || '')}</b> <span class="muted">${dateTime(best.t)}</span>`;
    };
    const leave = () => { tip.style.opacity = 0; hl.setAttribute('opacity', 0); dot.setAttribute('opacity', 0); };
    const hit = el.querySelector('.hit');
    hit.addEventListener('mousemove', move); hit.addEventListener('touchmove', move, { passive: true });
    hit.addEventListener('mouseleave', leave); hit.addEventListener('touchend', leave);
  }
  let resizeT;
  window.addEventListener('resize', () => { clearTimeout(resizeT); resizeT = setTimeout(mountCharts, 150); });

  // ------------------------------------------------------------ scales
  function scale(value, min, max, band, ticks, cls = '') {
    const pos = v => Math.min(100, Math.max(0, ((v - min) / (max - min)) * 100));
    const safe = band && isNum(band[0]) && isNum(band[1])
      ? `<div class="safe" style="left:${pos(band[0])}%;width:${pos(band[1]) - pos(band[0])}%" title="Alert thresholds"></div>` : '';
    const needle = isNum(value) ? `<div class="needle" style="left:${pos(value)}%"></div>` : '';
    return `<div class="ph-scale ${cls}" aria-hidden="true"><div class="bar"></div>${safe}${needle}<div class="ticks">${ticks.map(t => `<span>${t}</span>`).join('')}</div></div>`;
  }
  const phBand = () => [rule('rule-ph-low')?.threshold, rule('rule-ph-high')?.threshold];
  const tempBand = () => [rule('rule-temp-low')?.threshold, rule('rule-temp-high')?.threshold];
  function levelOf(v, band) {
    if (!isNum(v) || !isNum(band[0]) || !isNum(band[1])) return '';
    return v < band[0] || v > band[1] ? 'out' : '';
  }

  // ------------------------------------------------------------ shell
  function renderNav() {
    const r = route(), n = activeAlerts().length;
    let lastGroup = '';
    $('#sideNav').innerHTML = allowedRoutes().map(x => {
      const head = x.group !== lastGroup ? `<div class="nav-group">${esc(x.group)}</div>` : '';
      lastGroup = x.group;
      return head + `<a href="#/${x.id}" class="${x.id === r ? 'active' : ''}" ${x.id === r ? 'aria-current="page"' : ''}>${I(x.icon)}<span>${esc(x.title)}</span>${x.id === 'alerts' && n ? `<span class="badge">${n}</span>` : ''}</a>`;
    }).join('');
    const a = state.auth || {};
    $('#sideUser').innerHTML = a.signedIn
      ? `<div class="side-user">${I('users')}<div class="side-user-text"><b>${esc(a.username)}</b><span>${esc(a.roleLabel || a.role)}</span></div></div><button class="btn sm ghost side-out" id="sideSignOut">Sign out</button>`
      : (a.mode === 'local' ? `<button class="btn sm" id="sideSignIn">${I('lock')}Sign in for business data</button>` : '');
    $('#sideSignOut')?.addEventListener('click', signOut);
    $('#sideSignIn')?.addEventListener('click', () => showLogin('Sign in to open POC research, finance, evidence and audit records.'));
    $('#bottomNav').innerHTML = MOBILE.filter(x => x.id === 'more' || hasPerm('monitor.read')).map(x => {
      const active = x.id === r || (x.id === 'more' && moreIds().includes(r));
      const href = x.id === 'more' ? '#more' : '#/' + x.id;
      return `<a href="${href}" data-id="${x.id}" class="${active ? 'active' : ''}">${I(x.icon)}<span>${x.label}</span>${x.id === 'more' && n ? `<span class="badge">${n}</span>` : ''}</a>`;
    }).join('');
    $('#sideConn').innerHTML = state.wsOk
      ? `<span class="chip ok"><span class="dot"></span>Server connected</span>`
      : `<span class="chip warn"><span class="dot"></span>Reconnecting</span>`;
    $('#connBanner').classList.toggle('show', state.loaded && !state.wsOk);
  }
  $('#bottomNav').addEventListener('click', e => {
    const a = e.target.closest('a[data-id="more"]');
    if (!a) return;
    e.preventDefault();
    const n = activeAlerts().length;
    const m = openModal(`<h3>More</h3><div class="list more-sheet">${moreIds().map(id => {
      const r = ROUTES.find(x => x.id === id);
      return `<a class="list-item" href="#/${id}">${I(r.icon)}<span class="grow">${esc(r.title)}</span>${id === 'alerts' && n ? `<span class="badge">${n}</span>` : ''}</a>`;
    }).join('')}</div>`);
    m.addEventListener('click', ev => { if (ev.target.closest('a')) closeModal(); });
  });

  function renderPondPicker() {
    const list = pondList(), r = route();
    const show = list.length > 1 && ['overview', 'trends', 'calibration', 'water', 'cycle'].includes(r);
    $('#pondPicker').innerHTML = show
      ? `<select id="pondSelect" aria-label="Pond">${list.map(p => `<option value="${esc(p.id)}" ${p.id === selectedPond()?.id ? 'selected' : ''}>${esc(p.name)} (${esc(p.id)})</option>`).join('')}</select>`
      : '';
    const sel = $('#pondSelect');
    if (sel) sel.addEventListener('change', () => { setSelected(sel.value); render(); });
  }

  // ------------------------------------------------------------ views
  const VIEWS = {};

  // ===== Overview
  VIEWS.overview = () => {
    const p = selectedPond();
    const L = p?.latest || null;
    const offline = p && !p.online;
    const tb = tempBand(), pb = phBand();
    const hist = p ? state.history[p.id + '|24h'] : null;
    const tStat = hist?.stats?.temperatureC, pStat = hist?.stats?.ph;
    const tLevel = levelOf(L?.temperatureC, tb), pLevel = levelOf(L?.ph, pb);
    const lastKnown = offline ? `<span class="chip crit">Last known value</span>` : '';

    const hero = `<section class="hero">
      <div>
        <div class="pond-id">${p ? esc(p.id) + (p.deviceId ? ' / ' + esc(p.deviceId) : '') : 'No pond registered yet'}</div>
        <h2 class="pond-title">${p ? esc(p.name) : 'Waiting for your first pond'}</h2>
      </div>
      ${onlineChip(p)}
      <div class="spacer"></div>
      <div class="muted small">${p ? 'Last update <b style="color:var(--text)" data-rel="' + esc(p.lastUpdate) + '">' + rel(p.lastUpdate) + '</b>' : ''}</div>
    </section>`;

    const waiting = !p ? `<div class="waiting"><div class="radar"></div><div><b>Waiting for real ESP32 telemetry</b><br>
      <span class="small">${state.info?.mode === 'cloud'
        ? `Flash the ESP32 with <code>MQTT_HOST</code> = <code>${esc(state.info.publicHost || location.hostname)}</code>, port <code>8883</code>, <code>USE_TLS 1</code> and its device login (Settings).`
        : `Flash the ESP32 with <code>MQTT_HOST</code> set to this computer's LAN IP (${esc(state.info?.lan?.[0]?.address || 'see Settings')}) and port ${esc(state.info?.mqttPort || 1883)}.`} The pond appears here on its first message to <code>aqua/site/${esc(state.info?.site?.id || 'SITE-01')}/pond/POND-A/telemetry</code>.</span></div></div>` : '';

    const metrics = `<section class="metrics">
      <article class="panel metric ${L && isNum(L.temperatureC) && !offline ? 'live' : ''} ${tLevel ? 'state-warn' : ''}">
        <div class="label">${I('thermo')}Water temperature ${lastKnown}</div>
        <div class="value ${L && isNum(L.temperatureC) ? '' : 'dash'}" id="vTemp">${L && isNum(L.temperatureC) ? fmt(L.temperatureC) + '<span class="unit">°C</span>' : DASH}</div>
        ${scale(L?.temperatureC, 20, 36, tb, [20, 24, 28, 32, 36], 'temp-scale')}
        <div class="foot">${L && !isNum(L.temperatureC) ? '<span>Probe not reporting a valid value</span>' : tStat ? `<span>24 h low ${fmt(tStat.min)}</span><span>high ${fmt(tStat.max)} °C</span>` : '<span>No real history yet</span>'}</div>
      </article>
      <article class="panel metric ${L && isNum(L.ph) && !offline ? 'live' : ''} ${pLevel ? 'state-crit' : ''}">
        <div class="label">${I('drop')}pH ${lastKnown}</div>
        <div class="value ${L && isNum(L.ph) ? '' : 'dash'}" id="vPh">${L && isNum(L.ph) ? fmt(L.ph) : DASH}</div>
        ${scale(L?.ph, 0, 14, pb, [0, 2, 4, 6, 7, 8, 10, 12, 14].filter(v => v !== 7))}
        <div class="foot">${L ? `<span>24 h swing ${isNum(p.derived?.phSwing24h) ? fmt(p.derived.phSwing24h) : 'needs 12 h of data'}</span><span>RAW ${esc(L.phRaw ?? DASH)}</span><span>${p.calibration ? 'Probe ' + esc(p.calibration.probeId) : 'Device calibration'}</span>` : '<span>No real reading yet</span>'}</div>
      </article>
      <article class="panel metric secondary">
        <div class="label">${I('chip')}Device</div>
        <div class="small-value">${p ? (p.online ? 'Online' : 'Offline') : DASH}</div>
        <dl class="kv">
          <dt>Device</dt><dd>${esc(p?.deviceId || DASH)}</dd>
          <dt>Wi-Fi</dt><dd>${rssiLabel(L?.rssi)}</dd>
          <dt>Firmware</dt><dd>${esc(L?.firmwareVersion || DASH)}</dd>
          <dt>Uptime</dt><dd>${uptime(L?.uptimeSec)}</dd>
        </dl>
      </article>
      <article class="panel metric secondary">
        <div class="label">${I('clock')}Last update</div>
        <div class="small-value" data-rel="${esc(p?.lastUpdate || '')}">${p ? rel(p.lastUpdate) : DASH}</div>
        <dl class="kv">
          <dt>Telemetry</dt><dd>${clock(p?.lastUpdate)}</dd>
          <dt>Last seen</dt><dd>${clock(p?.lastSeen)}</dd>
          <dt>Interval</dt><dd>${p ? '60 s' : DASH}</dd>
          <dt>Offline after</dt><dd>${Math.round((state.info?.settings?.offlineAfterSec || 300) / 60)} min silence</dd>
        </dl>
      </article>
    </section>`;

    // quick actions
    const feeders = feedersFor(p?.id);
    const cams = state.integrations.filter(i => i.enabled && i.category === 'camera' && (!i.pondId || i.pondId === p?.id));
    const cam = cams.find(c => c.mode === 'external' && c.launchUrl);
    const qa = `<section class="panel o-qa">
      <div class="panel-head"><h2>Quick actions</h2></div>
      <div class="qa">
        <button class="qa-btn ${p && feeders.length ? '' : 'disabled'}" data-act="feed" ${p && feeders.length ? '' : 'disabled aria-disabled="true"'}>${I('feed')}Feed<small>${p && feeders.length ? (feeders[0].mode === 'external' ? 'External app' : 'MQTT') : 'Not set up'}</small></button>
        <button class="qa-btn disabled" disabled aria-disabled="true">${I('aerator')}Aerator<small>v2.2.0</small></button>
        <button class="qa-btn disabled" disabled aria-disabled="true">${I('pump')}<span class="hide-mobile">Water pump</span><span class="show-mobile">Pump</span><small>v2.2.0</small></button>
        ${cam ? `<a class="qa-btn" href="${esc(cam.launchUrl)}" target="_blank" rel="noopener" data-opened="${esc(cam.id)}">${I('camera')}Camera<small>Open app</small></a>`
              : `<button class="qa-btn disabled" disabled aria-disabled="true">${I('camera')}Camera<small>Not set up</small></button>`}
      </div>
    </section>`;

    const chart = `<section class="panel o-chart">
      <div class="panel-head"><h2>Last 24 hours</h2><span class="hint">${hist ? hist.sampleCount + ' real samples' : ''}</span><div class="spacer"></div><a class="btn sm ghost" href="#/trends">Open trends</a></div>
      <div class="chart-label"><span class="sw" style="background:var(--sky)"></span>Temperature °C</div>
      ${chartSlot({ points: hist?.points, key: 'temperatureC', color: '#34B8FF', unit: ' °C', from: hist?.from, to: hist?.to, bucketSec: hist?.bucketSec, height: 150, fill: true, minSpan: 1, decimals: 1, band: tb, label: 'Temperature', empty: p ? 'No real history yet' : 'Waiting for real ESP32 telemetry' })}
      <div class="chart-label"><span class="sw" style="background:var(--aqua)"></span>pH</div>
      ${chartSlot({ points: hist?.points, key: 'ph', color: '#35E1C1', unit: '', from: hist?.from, to: hist?.to, bucketSec: hist?.bucketSec, height: 150, fill: true, minSpan: 0.4, decimals: 2, band: pb, label: 'pH', empty: p ? 'No real history yet' : 'Waiting for real ESP32 telemetry' })}
    </section>`;

    const act = activeAlerts().filter(a => !p || a.pondId === p.id);
    const alertsPanel = `<section class="panel o-alerts">
      <div class="panel-head"><h2>Alerts</h2><div class="spacer"></div><a class="btn sm ghost" href="#/alerts">All alerts</a></div>
      ${act.length ? `<div class="list">${act.slice(0, 4).map(a => `<div class="list-item">${sevChip(a.severity)}<div class="grow"><div class="title">${esc(a.message)}</div><div class="meta">since ${dateTime(a.startedAt)}</div></div></div>`).join('')}</div>`
        : `<div class="empty">${p ? 'No active alerts. Rules need a condition to hold for several minutes before alerting.' : 'Alerts start once real telemetry arrives.'}</div>`}
    </section>`;

    const lastFeed = state.feeding.events.find(e => !p || e.pondId === p.id);
    const nextSch = nextSchedule(p?.id);
    const feedPanel = `<section class="panel o-feed">
      <div class="panel-head"><h2>Feeding</h2><div class="spacer"></div><a class="btn sm ghost" href="#/feeding">Feeding</a></div>
      <div class="list">
        <div class="list-item"><div class="grow"><div class="meta">Last feeding command</div><div class="title">${lastFeed ? dateTime(lastFeed.createdAt) + ', ' + lastFeed.durationSec + ' s' : DASH}</div></div>${lastFeed ? feedChip(lastFeed.status) : ''}</div>
        <div class="list-item"><div class="grow"><div class="meta">Next schedule</div><div class="title">${nextSch ? esc(nextSch.time) + ', ' + nextSch.durationSec + ' s' : 'No schedule'}</div></div></div>
      </div>
    </section>`;

    const equip = `<section class="panel o-equip">
      <div class="panel-head"><h2>Equipment</h2><div class="spacer"></div><a class="btn sm ghost" href="#/controls">Controls</a></div>
      <div class="list">
        ${['Aerator', 'Water pump', 'Feeder relay'].map(n => `<div class="list-item"><div class="grow title">${n}</div><span class="chip off">Not configured</span></div>`).join('')}
        <div class="list-item"><div class="grow title">Integrations</div><span class="chip ${state.integrations.length ? 'info' : 'off'}">${state.integrations.length || 'None'}</span></div>
      </div>
    </section>`;

    const pushOff = p && state.info?.notifications && !state.info.notifications.pushover.enabled
      ? '<a class="notice warn" href="#/settings" style="display:block;text-decoration:none">Phone alerts are off. Nobody will be woken if a pump stops at night. Set up Pushover in Settings.</a>' : '';
    return `<div class="ov">
      <div class="ov-head">${hero}${waiting}${pushOff}</div>
      ${metrics}
      <div class="ov-body">
        <div class="ov-main">${chart}</div>
        <div class="ov-side">${lifeSupport(p)}${qa}${alertsPanel}${feedPanel}${equip}</div>
      </div>
    </div>`;
  };
  VIEWS.overview.after = async () => {
    const p = selectedPond();
    $$('[data-act="feed"]').forEach(b => b.addEventListener('click', () => openFeedModal(p?.id)));
    $$('[data-opened]').forEach(a => a.addEventListener('click', () => api(`/integrations/${a.dataset.opened}/opened`, { method: 'POST' }).catch(() => {})));
    if (p && !state.history[p.id + '|24h']) {
      try { await load.history(p.id, '24h'); if (route() === 'overview') render(); } catch (_) {}
    }
  };

  function lifeSupport(p) {
    const seen = new Set(p?.sensorsSeen || []);
    const L = p?.latest || {};
    const off = p && !p.online;
    const tile = (icon, title, field, r) => {
      if (!seen.has(field)) return `<div class="ls-tile"><div class="ls-top">${I(icon)}${title}</div><div class="ls-val off">Not installed</div><div class="ls-sub">No sensor has reported</div></div>`;
      const v = r();
      return `<div class="ls-tile ${off ? '' : v.cls}"><div class="ls-top">${I(icon)}${title}</div><div class="ls-val">${v.text}</div><div class="ls-sub">${off ? 'Last known, device offline' : v.sub || ''}</div></div>`;
    };
    const tiles = [
      tile('pump', 'Circulation pump', 'flowLpm', () => L.pumpRunning === true ? { cls: 'ok', text: 'Running', sub: fmt(L.flowLpm, 1) + ' L/min' } : L.pumpRunning === false ? { cls: 'crit', text: 'Stopped', sub: fmt(L.flowLpm, 1) + ' L/min' } : { cls: 'warn', text: 'No reading', sub: 'Check the flow sensor' }),
      tile('aerator', 'Air pump', 'airPumpCurrentA', () => L.airPumpRunning === true ? { cls: 'ok', text: 'Running', sub: fmt(L.airPumpCurrentA, 2) + ' A' } : L.airPumpRunning === false ? { cls: 'crit', text: 'Stopped', sub: fmt(L.airPumpCurrentA, 2) + ' A' } : { cls: 'warn', text: 'No reading', sub: 'Check the current clamp' }),
      tile('level', 'Sump water level', 'waterLevel', () => L.waterLevel === 'ok' ? { cls: 'ok', text: 'Normal' } : L.waterLevel === 'low' ? { cls: 'crit', text: 'Low', sub: 'Pump may run dry' } : L.waterLevel === 'high' ? { cls: 'warn', text: 'High', sub: 'Overflow risk' } : { cls: 'warn', text: 'No reading' }),
      tile('o2', 'Dissolved oxygen', 'doMgL', () => isNum(L.doMgL) ? { cls: L.doMgL < 3 ? 'crit' : L.doMgL < 4 ? 'warn' : 'ok', text: fmt(L.doMgL, 1) + ' mg/L' } : { cls: 'warn', text: 'No reading', sub: 'Check the DO sensor' })
    ].join('');
    const none = !['flowLpm', 'airPumpCurrentA', 'waterLevel', 'doMgL'].some(f => seen.has(f));
    return `<section class="panel o-ls"><div class="panel-head"><h2>Life support</h2><span class="hint">Pumps, aeration, water level, oxygen</span></div><div class="ls-grid">${tiles}</div>
      ${none ? '<p class="muted small ls-note" style="margin-bottom:0">No life-support sensors installed yet. In a RAS a stopped pump is the fastest way to lose a tank. See docs/HARDWARE_ZH.md for the flow sensor, float switches and air pump clamp.</p>' : ''}</section>`;
  }

  function feedersFor(pondId) {
    return state.integrations.filter(i => i.enabled && i.category === 'feeder' && ['mqtt', 'external'].includes(i.mode) && (!i.pondId || i.pondId === pondId));
  }
  function nextSchedule(pondId) {
    const list = state.feeding.schedules.filter(s => s.enabled && (!pondId || s.pondId === pondId));
    if (!list.length) return null;
    const now = new Date(), cur = String(now.getHours()).padStart(2, '0') + ':' + String(now.getMinutes()).padStart(2, '0');
    return list.find(s => s.time > cur) || list[0];
  }

  // ===== Ponds
  VIEWS.ponds = () => {
    const list = pondList();
    if (!list.length) {
      return `<section class="panel"><div class="empty big"><b>No ponds yet</b>
        A pond appears automatically when a real ESP32 publishes to <code>aqua/site/${esc(state.info?.site?.id || 'SITE-01')}/pond/&lt;POND_ID&gt;/telemetry</code>.<br>
        Ponds are never created from sample data.</div></section>`;
    }
    return `<section class="cards">${list.map(p => {
      const L = p.latest || {};
      return `<article class="panel pond-card">
        <div class="row"><div><div class="muted small">${esc(p.siteId || '')} / ${esc(p.id)}${p.topicStyle === 'legacy' ? ' <span class="chip warn" title="Firmware older than 2.0.3">old topic format</span>' : ''}</div><h3 style="margin:2px 0 0;font-size:20px;font-weight:600">${esc(p.name)}</h3></div><div class="spacer" style="flex:1"></div>${onlineChip(p)}</div>
        <div class="vals">
          <div><span>Water temperature</span><b>${fmt(L.temperatureC)}</b> <span style="display:inline">°C</span></div>
          <div><span>pH</span><b>${fmt(L.ph)}</b></div>
        </div>
        <div class="muted small">Last seen <span data-rel="${esc(p.lastSeen || '')}">${rel(p.lastSeen)}</span>${p.deviceId ? ', device ' + esc(p.deviceId) : ''}</div>
        <div class="row" style="margin-top:12px">
          <button class="btn sm" data-open="${esc(p.id)}">Open overview</button>
          <button class="btn sm ghost" data-trend="${esc(p.id)}">Trends</button>
          <button class="btn sm ghost" data-rename="${esc(p.id)}">${I('edit')}Rename</button>
        </div>
      </article>`;
    }).join('')}</section>
    <p class="muted small">New ponds register themselves from real telemetry. Pond history is kept when a device goes offline.</p>`;
  };
  VIEWS.ponds.after = () => {
    $$('[data-open]').forEach(b => b.addEventListener('click', () => { setSelected(b.dataset.open); location.hash = '#/overview'; }));
    $$('[data-trend]').forEach(b => b.addEventListener('click', () => { setSelected(b.dataset.trend); location.hash = '#/trends'; }));
    $$('[data-rename]').forEach(b => b.addEventListener('click', () => {
      const p = state.ponds[b.dataset.rename];
      const m = openModal(`<h3>Rename pond</h3><p class="muted small">${esc(p.id)} keeps its ID; only the display name changes.</p>
        <label class="field">Pond name<input type="text" id="pName" maxlength="60" value="${esc(p.name)}"></label>
        <div class="modal-actions"><button class="btn" data-close-btn>Cancel</button><button class="btn primary" id="pSave">Save name</button></div>`);
      m.querySelector('[data-close-btn]').onclick = closeModal;
      m.querySelector('#pSave').onclick = async () => {
        try { const up = await api('/ponds/' + encodeURIComponent(p.id), { method: 'PATCH', body: { name: $('#pName').value } }); state.ponds[up.id] = up; closeModal(); toast('Pond renamed', 'ok'); render(); }
        catch (e) { toast(e.message, 'err'); }
      };
    }));
  };

  // ===== Trends
  VIEWS.trends = () => {
    const p = selectedPond();
    if (!p) return `<section class="panel"><div class="empty big"><b>No real history yet</b>Trends appear after a real ESP32 starts sending telemetry.</div></section>`;
    const r = state.trendsRange, h = state.history[p.id + '|' + r];
    const statRow = (s, unit, d) => s ? `<div class="stats"><span>Low<b>${fmt(s.min, d)}${unit}</b></span><span>Average<b>${fmt(s.avg, d)}${unit}</b></span><span>High<b>${fmt(s.max, d)}${unit}</b></span><span>Samples<b>${s.count}</b></span></div>` : '';
    return `<section class="row">
        <div class="seg" role="tablist">${['24h', '7d', '30d'].map(k => `<button role="tab" data-range="${k}" class="${k === r ? 'on' : ''}" aria-selected="${k === r}">${{ '24h': '24 hours', '7d': '7 days', '30d': '30 days' }[k]}</button>`).join('')}</div>
        <span class="muted small">${esc(p.name)}${h ? ', ' + (h.bucketSec > 60 ? 'averaged per ' + (h.bucketSec >= 3600 ? 'hour' : h.bucketSec / 60 + ' min') : 'every stored sample') : ''}</span>
        <div style="flex:1"></div>
        <a class="btn sm" href="/api/ponds/${encodeURIComponent(p.id)}/export.csv?range=${r}">${I('download')}Export CSV</a>
      </section>
      <section class="panel">
        <div class="panel-head"><h2>Water temperature</h2><span class="hint">°C</span></div>
        ${h ? statRow(h.stats.temperatureC, ' °C', 2) : ''}
        ${h ? chartSlot({ points: h.points, key: 'temperatureC', color: '#34B8FF', unit: ' °C', from: h.from, to: h.to, bucketSec: h.bucketSec, height: 240, minSpan: 1, decimals: 1, band: tempBand(), label: 'Temperature' }) : '<div class="chart-empty" style="height:240px">Loading real history…</div>'}
      </section>
      <section class="panel">
        <div class="panel-head"><h2>pH</h2></div>
        ${h ? statRow(h.stats.ph, '', 2) : ''}
        ${h ? chartSlot({ points: h.points, key: 'ph', color: '#35E1C1', unit: '', from: h.from, to: h.to, bucketSec: h.bucketSec, height: 240, minSpan: 0.4, decimals: 2, band: phBand(), label: 'pH' }) : '<div class="chart-empty" style="height:240px">Loading real history…</div>'}
      </section>${extraTrend(h)}`;
  };
  function extraTrend(h) {
    if (!h) return '';
    const defs = [['doMgL', 'Dissolved oxygen', ' mg/L', '#8FA8FF', 1], ['flowLpm', 'Circulation flow', ' L/min', '#F4C34F', 5], ['airPumpCurrentA', 'Air pump current', ' A', '#C58BFF', 0.1]];
    return defs.filter(([k]) => h.stats[k]).map(([k, label, unit, color, span]) => `<section class="panel"><div class="panel-head"><h2>${label}</h2><span class="hint">${unit.trim()}</span></div>
      <div class="stats"><span>Low<b>${fmt(h.stats[k].min, 2)}</b></span><span>Average<b>${fmt(h.stats[k].avg, 2)}</b></span><span>High<b>${fmt(h.stats[k].max, 2)}</b></span></div>
      ${chartSlot({ points: h.points, key: k, color, unit, from: h.from, to: h.to, bucketSec: h.bucketSec, height: 200, minSpan: span, decimals: 1, label })}</section>`).join('');
  }
  VIEWS.trends.after = async () => {
    $$('[data-range]').forEach(b => b.addEventListener('click', () => { state.trendsRange = b.dataset.range; render(); }));
    const p = selectedPond();
    if (p && !state.history[p.id + '|' + state.trendsRange]) {
      try { await load.history(p.id, state.trendsRange); if (route() === 'trends') render(); } catch (e) { toast(e.message, 'err'); }
    }
  };

  // ===== Feeding
  VIEWS.feeding = () => {
    const feeders = state.integrations.filter(i => i.category === 'feeder');
    const ev = state.feeding.events;
    const intName = id => state.integrations.find(i => i.id === id)?.name || 'Removed integration';
    const intMode = id => state.integrations.find(i => i.id === id)?.mode;
    return `<div class="notice">AQUA only shows <b>Confirmed</b> when a feeder acknowledges the command. Without an acknowledgement a feeding stays <b>Command Sent</b>, and feeders controlled in their own app show <b>External App Opened</b>.</div>
    <div class="split">
      <section class="panel">
        <div class="panel-head"><h2>Feeder integration</h2><div class="spacer"></div><button class="btn sm" id="addFeeder">${I('plus')}Add feeder</button></div>
        ${feeders.length ? `<div class="list">${feeders.map(f => `<div class="list-item"><div class="int-icon">${I('feed')}</div><div class="grow"><div class="title">${esc(f.name)}</div><div class="meta">${esc(state.catalog?.providers?.[f.provider]?.label || f.provider)}, ${esc(f.mode)}${f.pondId ? ', ' + esc(f.pondId) : ''}</div></div>${intChip(f.status)}
          <button class="btn sm primary" data-feed="${esc(f.id)}" ${f.enabled && ['mqtt', 'external'].includes(f.mode) ? '' : 'disabled'}>Feed now</button></div>`).join('')}</div>`
          : `<div class="empty">No feeder connected. Add your Wi-Fi feeder under Apps &amp; Integrations. If its protocol is unknown, add it as an external app.</div>`}
      </section>
      <section class="panel">
        <div class="panel-head"><h2>Last feeding</h2></div>
        ${ev[0] ? `<div class="row" style="align-items:flex-end"><div><div class="muted small">${esc(state.ponds[ev[0].pondId]?.name || ev[0].pondId)}, ${esc(ev[0].integrationName)}</div><div style="font-size:30px;font-weight:500">${dateTime(ev[0].createdAt)}</div><div class="muted small">${ev[0].durationSec} s, ${ev[0].source === 'schedule' ? 'scheduled' : 'manual'}</div></div><div style="flex:1"></div>${feedChip(ev[0].status)}</div>
          <p class="muted small" style="margin-bottom:0">${esc(ev[0].detail || '')}</p>` : `<div class="empty">No feeding has been sent from AQUA yet.</div>`}
      </section>
    </div>
    <section class="panel">
      <div class="panel-head"><h2>Schedules</h2><span class="hint">Server local time</span><div class="spacer"></div><button class="btn sm" id="addSch" ${feeders.length ? '' : 'disabled'}>${I('plus')}Add schedule</button></div>
      ${state.feeding.schedules.length ? `<div class="scroll-x"><table class="tbl"><thead><tr><th>Time</th><th>Pond</th><th>Feeder</th><th>Duration</th><th>Runs</th><th>Enabled</th><th></th></tr></thead><tbody>
        ${state.feeding.schedules.map(s => `<tr><td style="font-size:18px">${esc(s.time)}</td><td>${esc(s.pondId)}</td><td>${esc(intName(s.integrationId))}</td><td>${s.durationSec} s</td>
          <td class="small wrap">${intMode(s.integrationId) === 'mqtt' ? 'Sent by AQUA' : '<span class="muted">Reference only, set it in the feeder app</span>'}</td>
          <td><label class="switch"><input type="checkbox" data-sch-toggle="${esc(s.id)}" ${s.enabled ? 'checked' : ''} aria-label="Enable schedule ${esc(s.time)}"><span></span></label></td>
          <td><button class="btn sm ghost" data-sch-del="${esc(s.id)}" aria-label="Delete schedule">${I('trash')}</button></td></tr>`).join('')}
      </tbody></table></div>` : `<div class="empty">No schedules. Typical plan: 08:00, 13:00, 18:00 and 22:00.</div>`}
    </section>
    <section class="panel">
      <div class="panel-head"><h2>Feed history</h2></div>
      ${ev.length ? `<div class="scroll-x"><table class="tbl"><thead><tr><th>Time</th><th>Pond</th><th>Feeder</th><th>Duration</th><th>Source</th><th>Status</th><th>Detail</th></tr></thead><tbody>
        ${ev.slice(0, 50).map(e => `<tr><td>${dateTime(e.createdAt)}</td><td>${esc(e.pondId)}</td><td>${esc(e.integrationName)}</td><td>${e.durationSec} s</td><td>${e.source === 'schedule' ? 'Schedule' : 'Manual'}</td><td>${feedChip(e.status)}</td><td class="muted small wrap">${esc(e.detail || '')}</td></tr>`).join('')}
      </tbody></table></div>` : `<div class="empty">No feed history yet.</div>`}
    </section>`;
  };
  VIEWS.feeding.after = () => {
    $('#addFeeder')?.addEventListener('click', () => openIntegrationModal(null, { category: 'feeder' }));
    $('#addSch')?.addEventListener('click', openScheduleModal);
    $$('[data-feed]').forEach(b => b.addEventListener('click', () => {
      const f = state.integrations.find(i => i.id === b.dataset.feed);
      openFeedModal(f.pondId || selectedPond()?.id, f.id);
    }));
    $$('[data-sch-toggle]').forEach(c => c.addEventListener('change', async () => {
      const s = state.feeding.schedules.find(x => x.id === c.dataset.schToggle);
      try { await api('/feeding/schedules/' + s.id, { method: 'PUT', body: { ...s, enabled: c.checked } }); await load.feeding(); render(); }
      catch (e) { toast(e.message, 'err'); c.checked = !c.checked; }
    }));
    $$('[data-sch-del]').forEach(b => b.addEventListener('click', async () => {
      if (!await confirmDialog('Delete schedule?', 'The schedule is removed. Feed history is kept.')) return;
      try { await api('/feeding/schedules/' + b.dataset.schDel, { method: 'DELETE' }); await load.feeding(); render(); toast('Schedule deleted'); }
      catch (e) { toast(e.message, 'err'); }
    }));
  };

  function pondOptions(selected, allowFree = true) {
    const ids = new Set(pondList().map(p => p.id));
    for (const i of state.integrations) if (i.pondId) ids.add(i.pondId);
    for (const c of state.calibrations) if (c.pondId) ids.add(c.pondId);
    if (selected) ids.add(selected);
    const list = [...ids].sort();
    return `<input type="text" list="pondIds" value="${esc(selected || '')}" placeholder="POND-A" maxlength="40" ${allowFree ? '' : 'readonly'}><datalist id="pondIds">${list.map(id => `<option value="${esc(id)}">${esc(state.ponds[id]?.name || '')}</option>`).join('')}</datalist>`;
  }

  function openScheduleModal() {
    const feeders = state.integrations.filter(i => i.category === 'feeder');
    const p = selectedPond();
    const m = openModal(`<h3>Add feeding schedule</h3>
      <p class="muted small">Schedules on an MQTT feeder are sent by AQUA. For external-app feeders, set the same times inside the feeder app; AQUA keeps them as reference.</p>
      <div class="form-grid" style="margin-top:14px">
        <label class="field">Time<input type="time" id="sTime" value="08:00" required></label>
        <label class="field">Feed duration (seconds)<input type="number" id="sDur" min="1" max="300" value="10"></label>
        <label class="field">Pond<span id="sPondWrap">${pondOptions(p?.id || '')}</span></label>
        <label class="field">Feeder<select id="sInt">${feeders.map(f => `<option value="${esc(f.id)}">${esc(f.name)} (${esc(f.mode)})</option>`).join('')}</select></label>
      </div>
      <div class="modal-actions"><button class="btn" data-x>Cancel</button><button class="btn primary" id="sSave">Save schedule</button></div>`);
    m.querySelector('[data-x]').onclick = closeModal;
    m.querySelector('#sSave').onclick = async () => {
      try {
        await api('/feeding/schedules', { method: 'POST', body: {
          time: $('#sTime').value, durationSec: Number($('#sDur').value),
          pondId: $('#sPondWrap input').value.trim(), integrationId: $('#sInt').value, enabled: true } });
        closeModal(); await load.feeding(); render(); toast('Schedule saved', 'ok');
      } catch (e) { toast(e.message, 'err'); }
    };
  }

  async function openFeedModal(pondId, integrationId) {
    const pond = state.ponds[pondId];
    const feeders = feedersFor(pondId);
    if (!pondId || !feeders.length) { toast('No enabled feeder is configured for this pond', 'err'); return; }
    let reasons = null, override = false;
    const draw = () => {
      const f = feeders.find(x => x.id === ($('#fInt')?.value || integrationId)) || feeders[0];
      const dur = Number($('#fDur')?.value || 10);
      $('#fSummary').innerHTML = `<div class="muted small">Pond</div><div class="big">${esc(pond?.name || pondId)}</div>
        <div class="muted small">Feed duration</div><div class="big">${isNum(dur) && dur > 0 ? dur : DASH} seconds</div>
        <div class="muted small">${f.mode === 'external'
          ? 'This feeder is controlled in its own app. AQUA opens the app and records "External App Opened". Feed and check the result in the app.'
          : 'AQUA sends an MQTT command. It shows "Confirmed" only if the feeder acknowledges; otherwise it stays "Command Sent".'}</div>`;
      const lock = $('#fLock');
      if (reasons === null) lock.innerHTML = '<div class="muted small">Checking feeding safety…</div>';
      else if (!reasons.length) lock.innerHTML = '<span class="chip ok">Safety check passed</span>';
      else lock.innerHTML = `<div class="notice warn"><b>Feeding is paused for safety</b><ul class="reasons">${reasons.map(r => `<li>${esc(r.en)}<br><span class="muted small">${esc(r.zh)}</span></li>`).join('')}</ul>
        <label class="row" style="margin-top:10px;flex-wrap:nowrap;align-items:flex-start"><input type="checkbox" id="fOverride" ${override ? 'checked' : ''} style="margin-top:3px"><span>I have checked the pond in person and want to feed anyway</span></label></div>`;
      const go = $('#fGo');
      go.textContent = f.mode === 'external' ? 'Open feeder app' : 'Send Feed Command';
      go.disabled = reasons === null || (reasons.length > 0 && !override);
      return f;
    };
    const m = openModal(`<h3>Feed now</h3>
      <div class="form-grid" style="margin-top:12px">
        <label class="field ${feeders.length > 1 ? '' : 'full'}">Feeder<select id="fInt">${feeders.map(f => `<option value="${esc(f.id)}" ${f.id === integrationId ? 'selected' : ''}>${esc(f.name)}</option>`).join('')}</select></label>
        <label class="field">Feed duration (seconds)<input type="number" id="fDur" min="1" max="300" value="10"></label>
      </div>
      <div class="confirm-box" id="fSummary"></div>
      <div id="fLock" style="margin-top:12px"></div>
      <p style="margin:14px 0 0;font-size:16px">Confirm feeding?</p>
      <div class="modal-actions"><button class="btn" data-x>Cancel</button><button class="btn primary" id="fGo" disabled>Send Feed Command</button></div>`);
    draw();
    m.querySelector('#fInt').onchange = draw;
    m.querySelector('#fDur').oninput = draw;
    m.addEventListener('change', e => { if (e.target.id === 'fOverride') { override = e.target.checked; draw(); } });
    m.querySelector('[data-x]').onclick = closeModal;
    m.querySelector('#fGo').onclick = async () => {
      const f = draw();
      const dur = Number($('#fDur').value);
      if (!Number.isInteger(dur) || dur < 1 || dur > 300) { toast('Duration must be 1 to 300 seconds', 'err'); return; }
      if (f.mode === 'external') {
        if (!f.launchUrl) { toast('Add a launch URL to this integration first', 'err'); return; }
        window.open(f.launchUrl, '_blank', 'noopener');
      }
      try {
        const ev = await api('/feeding/feed', { method: 'POST', body: { pondId, integrationId: f.id, durationSec: dur, override: reasons.length > 0 && override } });
        closeModal();
        toast(ev.status === 'Command Sent' ? 'Command Sent. Not confirmed until the feeder acknowledges.' : ev.status === 'Failed' ? 'Failed: ' + ev.detail : ev.status, ev.status === 'Failed' ? 'err' : '');
        await load.feeding(); render();
      } catch (e) {
        if (e.status === 409 && e.data?.reasons) { reasons = e.data.reasons; override = false; draw(); toast('Feeding paused by the safety interlock', 'err'); }
        else toast(e.message, 'err');
      }
    };
    try { reasons = (await api('/feeding/interlock?pondId=' + encodeURIComponent(pondId))).reasons; }
    catch (e) { reasons = [{ en: 'Could not check feeding safety: ' + e.message, zh: '无法检查投喂安全状态' }]; }
    if ($('#fLock')) draw();
  }

  // ===== Controls
  VIEWS.controls = () => {
    const c = state.controls?.channels || [];
    return `<div class="notice warn">Relay control arrives in v2.2.0. In v2.0.0 no channel can switch equipment, so every control below is disabled. Mains-voltage wiring must be done by a licensed electrician.</div>
    <section class="cards" style="grid-template-columns:repeat(auto-fill,minmax(220px,1fr))">${c.map(ch => `<article class="panel channel">
        <div class="ch">CH${ch.channel}</div>
        <div class="row">${I(['aerator', 'pump', 'feed', 'plug'][ch.channel - 1], '')}<h3>${esc(ch.name)}</h3></div>
        <span class="chip off" style="align-self:flex-start">Not configured</span>
        <div class="toggle-mock" aria-disabled="true">Control disabled</div>
      </article>`).join('')}</section>
    <section class="panel"><div class="panel-head"><h2>Planned path</h2></div>
      <p class="muted" style="margin:0">ESP32 relay output, then a contactor, then the aerator, pump or feeder. Each channel will report its real state back before AQUA shows it as on.</p></section>`;
  };

  // ===== Apps & Integrations
  VIEWS.apps = () => {
    const list = state.integrations;
    const P = state.catalog?.providers || {};
    return `<section class="row"><p class="muted" style="margin:0;max-width:70ch">Connect any brand. Devices without an open protocol work as an external app now and can be upgraded to MQTT, REST or native control later without changing the rest of AQUA.</p><div style="flex:1"></div><button class="btn primary" id="addInt">${I('plus')}Add integration</button></section>
    ${list.length ? `<section class="cards">${list.map(it => `<article class="panel int-card">
        <div class="top"><div class="int-icon">${I(PROVIDER_UI[it.provider]?.icon || 'apps')}</div>
          <div style="flex:1;min-width:0"><h3>${esc(it.name)}</h3><div class="meta">${esc(P[it.provider]?.label || it.provider)}, ${esc(it.category)}</div></div>
          ${intChip(it.status)}</div>
        <div class="meta small">Mode <b style="color:var(--text-2)">${esc(it.mode)}</b>${it.pondId ? ', pond ' + esc(it.pondId) : ', all ponds'}${it.mqttCommandTopic ? '<br>Topic <code>' + esc(it.mqttCommandTopic) + '</code>' : ''}</div>
        ${it.notes ? `<div class="muted small">${esc(it.notes)}</div>` : ''}
        <div class="actions">
          ${it.mode === 'external' && it.launchUrl && it.enabled ? `<a class="btn sm primary" href="${esc(it.launchUrl)}" target="_blank" rel="noopener" data-opened="${esc(it.id)}">${I('external')}Open app</a>` : ''}
          <button class="btn sm" data-edit="${esc(it.id)}">${I('edit')}Edit</button>
          <button class="btn sm ghost danger" data-del="${esc(it.id)}">${I('trash')}Delete</button>
        </div>
      </article>`).join('')}</section>`
      : `<section class="panel"><div class="empty big"><b>No integrations yet</b>Add your ESP32, a Wi-Fi feeder, a Tapo camera, VSON Smart or any other app. Nothing is pre-filled or simulated.</div></section>`}`;
  };
  VIEWS.apps.after = () => {
    $('#addInt')?.addEventListener('click', () => openIntegrationModal(null));
    $$('[data-edit]').forEach(b => b.addEventListener('click', () => openIntegrationModal(state.integrations.find(i => i.id === b.dataset.edit))));
    $$('[data-opened]').forEach(a => a.addEventListener('click', () => api(`/integrations/${a.dataset.opened}/opened`, { method: 'POST' }).catch(() => {})));
    $$('[data-del]').forEach(b => b.addEventListener('click', async () => {
      const it = state.integrations.find(i => i.id === b.dataset.del);
      if (!await confirmDialog(`Delete ${it.name}?`, 'The integration is removed from AQUA. The device itself is not changed.')) return;
      try { await api('/integrations/' + it.id, { method: 'DELETE' }); await load.integrations(); render(); toast('Integration deleted'); }
      catch (e) { toast(e.message, 'err'); }
    }));
  };

  function openIntegrationModal(existing, preset = {}) {
    const P = state.catalog?.providers || {};
    if (!existing && !preset.provider) {
      const m = openModal(`<h3>Add integration</h3><p class="muted small">Choose what you are connecting.</p>
        <div class="provider-grid" style="margin-top:14px">${Object.entries(P).map(([k, v]) => `<button data-prov="${k}">${I(PROVIDER_UI[k]?.icon || 'apps')}<b>${esc(v.label)}</b><span>${esc(PROVIDER_UI[k]?.desc || '')}</span></button>`).join('')}</div>
        <div class="modal-actions"><button class="btn" data-x>Cancel</button></div>`, { wide: true });
      m.querySelector('[data-x]').onclick = closeModal;
      m.querySelectorAll('[data-prov]').forEach(b => b.onclick = () => openIntegrationModal(null, { ...preset, provider: b.dataset.prov }));
      return;
    }
    const it = existing || {
      provider: preset.provider, name: P[preset.provider]?.label || '', category: preset.category || P[preset.provider]?.category,
      mode: P[preset.provider]?.defaultMode, pondId: selectedPond()?.id || '', launchUrl: '', apiBaseUrl: '', mqttCommandTopic: '', notes: '', enabled: true
    };
    const prov = P[it.provider];
    const m = openModal(`<h3>${existing ? 'Edit' : 'Add'} ${esc(prov.label)} integration</h3>
      <div class="form-grid" style="margin-top:14px">
        <label class="field full">Name<input type="text" id="iName" maxlength="80" value="${esc(it.name)}"></label>
        <label class="field">Category<select id="iCat">${state.catalog.categories.map(c => `<option ${c === it.category ? 'selected' : ''}>${c}</option>`).join('')}</select></label>
        <label class="field">Mode<select id="iMode">${prov.modes.map(md => `<option ${md === it.mode ? 'selected' : ''}>${md}</option>`).join('')}</select></label>
        <p class="full muted small" id="iModeText" style="margin:-4px 0 0"></p>
        <label class="field">Pond<small>Leave empty to use it for all ponds</small><span id="iPondWrap">${pondOptions(it.pondId)}</span></label>
        <label class="field" data-show="external">Launch URL<small>Web or app link, e.g. https://… or an app link from the maker</small><input type="url" id="iLaunch" value="${esc(it.launchUrl)}" placeholder="https://"></label>
        <label class="field" data-show="rest onvif">API base URL / stream address<small>http://… or rtsp://…</small><input type="url" id="iApi" value="${esc(it.apiBaseUrl)}" placeholder="rtsp:// or http://"></label>
        <label class="field" data-show="mqtt">MQTT command topic<small>Leave empty to use the pond's own topic. Acknowledgements go to …/pond/&lt;POND_ID&gt;/ack</small><input type="text" id="iTopic" value="${esc(it.mqttCommandTopic)}" placeholder="aqua/site/SITE-01/pond/POND-A/command/feed"></label>
        <label class="field full">Notes<textarea id="iNotes" maxlength="1000">${esc(it.notes)}</textarea></label>
        <div class="row full"><label class="switch"><input type="checkbox" id="iEnabled" ${it.enabled ? 'checked' : ''}><span></span></label><span>Enabled</span></div>
      </div>
      <div class="modal-actions"><button class="btn" data-x>Cancel</button><button class="btn primary" id="iSave">${existing ? 'Save changes' : 'Add integration'}</button></div>`, { wide: true });
    const sync = () => {
      const md = $('#iMode').value;
      $('#iModeText').textContent = MODE_TEXT[md] || '';
      m.querySelectorAll('[data-show]').forEach(el => { el.style.display = el.dataset.show.split(' ').includes(md) ? '' : 'none'; });
    };
    sync();
    $('#iMode').onchange = sync;
    m.querySelector('[data-x]').onclick = closeModal;
    $('#iSave').onclick = async () => {
      const body = {
        provider: it.provider, name: $('#iName').value, category: $('#iCat').value, mode: $('#iMode').value,
        pondId: $('#iPondWrap input').value.trim(), launchUrl: $('#iLaunch').value.trim(), apiBaseUrl: $('#iApi').value.trim(),
        mqttCommandTopic: $('#iTopic').value.trim(), notes: $('#iNotes').value, enabled: $('#iEnabled').checked
      };
      try {
        await api(existing ? '/integrations/' + existing.id : '/integrations', { method: existing ? 'PUT' : 'POST', body });
        closeModal(); await load.integrations(); render(); toast(existing ? 'Integration saved' : 'Integration added', 'ok');
      } catch (e) { toast(e.message, 'err'); }
    };
  }

  // ===== Alerts
  const COND_EQ = { pumpRunning: 'Flow below running level (pump stopped)', airPumpRunning: 'Current below running level (air pump stopped)', sensorMissing: 'An installed sensor sends no valid value' };
  function condCell(r) {
    const unit = { temperatureC: ' °C', doMgL: ' mg/L' }[r.metric] || '';
    if (r.metric === 'offline') return `No telemetry for ${Math.round((state.info?.settings?.offlineAfterSec || 300) / 60)} min`;
    if (r.metric === 'waterLevel') return r.threshold === 'low' ? 'Low float switch triggered' : 'High float switch triggered';
    if (r.op === 'eq') return COND_EQ[r.metric] || DASH;
    const label = r.metric === 'phSwing24h' ? '24 h swing above' : r.op === 'lt' ? 'Below' : 'Above';
    return `<div class="row" style="flex-wrap:nowrap">${label} <input type="number" step="0.1" style="width:90px" data-rule-th="${esc(r.id)}" value="${esc(r.threshold)}">${unit}</div>`;
  }
  VIEWS.alerts = () => {
    const act = activeAlerts();
    const unit = m => (m === 'temperatureC' ? ' °C' : '');
    return `<section class="panel">
      <div class="panel-head"><h2>Active alerts</h2></div>
      ${act.length ? `<div class="list">${act.map(a => `<div class="list-item">${sevChip(a.severity)}<div class="grow"><div class="title">${esc(a.message)}</div><div class="meta">${esc(a.pondName)}, condition since ${dateTime(a.startedAt)}</div></div>
        ${a.acknowledged ? '<span class="chip off">Acknowledged</span>' : `<button class="btn sm" data-ack="${esc(a.id)}">Acknowledge</button>`}</div>`).join('')}</div>`
        : `<div class="empty">No active alerts.</div>`}
    </section>
    <section class="panel">
      <div class="panel-head"><h2>Rules</h2><span class="hint">A condition must hold continuously for the whole duration. One bad sample never alerts.</span></div>
      <div class="scroll-x"><table class="tbl"><thead><tr><th>Rule</th><th>Condition</th><th>Sustained for</th><th>Severity</th><th>Enabled</th></tr></thead><tbody>
      ${state.alerts.rules.map(r => `<tr>
        <td>${esc(r.name)}<div class="muted small">${esc(r.nameZh || '')}</div></td>
        <td>${condCell(r)}</td>
        <td>${r.metric === 'offline' ? DASH : `<div class="row" style="flex-wrap:nowrap"><input type="number" min="0" max="60" step="0.5" style="width:76px" data-rule-sus="${esc(r.id)}" value="${r.sustainSec / 60}"> min</div>`}</td>
        <td>${sevChip(r.severity)}</td>
        <td><label class="switch"><input type="checkbox" data-rule-en="${esc(r.id)}" ${r.enabled ? 'checked' : ''} aria-label="Enable ${esc(r.name)}"><span></span></label></td>
      </tr>`).join('')}</tbody></table></div>
    </section>
    <section class="panel">
      <div class="panel-head"><h2>Notification channels</h2></div>
      <div class="row"><span class="chip ok">In-app: active</span>${state.info?.notifications?.pushover?.enabled ? '<span class="chip ok">Phone push (Pushover): active</span>' : '<a class="chip warn" href="#/settings">Phone push: not set up</a>'}<span class="chip off">WhatsApp: planned</span><span class="chip off">Email: planned</span></div>
    </section>
    <section class="panel">
      <div class="panel-head"><h2>History</h2></div>
      ${state.alerts.alerts.length ? `<div class="scroll-x"><table class="tbl"><thead><tr><th>Started</th><th>Pond</th><th>Alert</th><th>Severity</th><th>Resolved</th></tr></thead><tbody>
        ${state.alerts.alerts.slice(0, 60).map(a => `<tr><td>${dateTime(a.startedAt)}</td><td>${esc(a.pondName)}</td><td class="wrap">${esc(a.message)}</td><td>${sevChip(a.severity)}</td><td>${a.resolvedAt ? dateTime(a.resolvedAt) : '<span class="chip crit">Active</span>'}</td></tr>`).join('')}
      </tbody></table></div>` : `<div class="empty">No alerts have been raised.</div>`}
    </section>`;
  };
  VIEWS.alerts.after = () => {
    const save = async (id, body) => {
      try { await api('/alerts/rules/' + id, { method: 'PUT', body }); await load.alerts(); toast('Rule saved', 'ok'); render(); }
      catch (e) { toast(e.message, 'err'); render(); }
    };
    $$('[data-rule-th]').forEach(i => i.addEventListener('change', () => save(i.dataset.ruleTh, { threshold: Number(i.value) })));
    $$('[data-rule-sus]').forEach(i => i.addEventListener('change', () => save(i.dataset.ruleSus, { sustainSec: Math.round(Number(i.value) * 60) })));
    $$('[data-rule-en]').forEach(i => i.addEventListener('change', () => save(i.dataset.ruleEn, { enabled: i.checked })));
    $$('[data-ack]').forEach(b => b.addEventListener('click', async () => {
      try { await api('/alerts/' + b.dataset.ack + '/ack', { method: 'POST' }); await load.alerts(); render(); } catch (e) { toast(e.message, 'err'); }
    }));
  };

  // ===== Calibration
  function phFromRaw(raw, points) {
    const pts = (points || []).map(p => ({ ph: Number(p.ph), raw: Number(p.raw) })).filter(p => isNum(p.ph) && isNum(p.raw) && p.raw > 0 && p.raw < 4095).sort((a, b) => b.raw - a.raw);
    if (!isNum(raw) || raw <= 10 || raw >= 4090 || pts.length < 2) return null;
    let a, b;
    if (raw >= pts[0].raw) { a = pts[0]; b = pts[1]; }
    else if (raw <= pts[pts.length - 1].raw) { a = pts[pts.length - 2]; b = pts[pts.length - 1]; }
    else for (let i = 0; i < pts.length - 1; i++) if (raw <= pts[i].raw && raw >= pts[i + 1].raw) { a = pts[i]; b = pts[i + 1]; break; }
    if (!a || a.raw === b.raw) return null;
    return Math.min(14, Math.max(0, a.ph + (raw - a.raw) * (b.ph - a.ph) / (b.raw - a.raw)));
  }
  const rawAt = (c, phv) => c.points.find(p => Math.abs(p.ph - phv) < 0.05)?.raw ?? DASH;

  VIEWS.calibration = () => {
    const p = selectedPond();
    const L = p?.latest;
    const active = state.calibrations.find(c => c.active && c.pondId === p?.id) || state.calibrations.find(c => c.active);
    const vPin = L?.phVoltage;
    const vMod = isNum(vPin) && active ? vPin * (active.dividerTopOhm + active.dividerBottomOhm) / active.dividerBottomOhm : null;
    return `<div class="split">
      <section class="panel">
        <div class="panel-head"><h2>Active probe ${active ? esc(active.probeId) : ''}</h2><div class="spacer"></div>${active ? `<span class="chip ok">Active for ${esc(active.pondId)}</span>` : ''}</div>
        ${active ? `<div class="metric" style="min-height:0;padding:0;gap:14px">
          <dl class="kv" style="grid-template-columns:auto 1fr;font-size:14px">
            <dt>Probe ID</dt><dd>${esc(active.probeId)}</dd>
            <dt>Pond / device</dt><dd>${esc(active.pondId)}${active.deviceId ? ' / ' + esc(active.deviceId) : ''}</dd>
            <dt>Calibration date</dt><dd>${esc(active.calibrationDate)}</dd>
            <dt>ADC pin</dt><dd>${esc(active.adcPin)}</dd>
            <dt>Voltage divider</dt><dd>${active.dividerTopOhm / 1000}k top, ${active.dividerBottomOhm / 1000}k bottom</dd>
            <dt>Temperature compensation</dt><dd>${isNum(active.calTempC) ? 'On, buffers at ' + active.calTempC + ' °C' : 'Off: add the buffer temperature'}</dd>
          </dl>
          <table class="tbl"><thead><tr><th>Buffer</th><th>RAW</th><th>Pin voltage</th></tr></thead><tbody>
            ${active.points.map(pt => `<tr><td>pH ${fmt(pt.ph)}</td><td>${pt.raw}</td><td>${fmt(pt.raw / 4095 * 3.3, 3)} V</td></tr>`).join('')}
          </tbody></table>
          <div class="muted small">Piecewise linear between buffers. Slopes: ${(active.analysis?.segments || []).map(s => `pH ${s.from}–${s.to}: ${s.phPer100Raw} pH per 100 RAW`).join('; ') || DASH}</div>
        </div>` : `<div class="empty">No calibration stored.</div>`}
      </section>
      <section class="panel">
        <div class="panel-head"><h2>Live probe reading</h2><span class="hint">${p ? esc(p.name) : ''}</span></div>
        ${L ? `<div class="metric" style="min-height:0;padding:0">
          <div class="value" style="font-size:46px" id="calLivePh">${fmt(L.ph)}</div>
          <dl class="kv" style="font-size:14px">
            <dt>RAW (averaged)</dt><dd id="calLiveRaw">${esc(L.phRaw ?? DASH)}</dd>
            <dt>Voltage at GPIO34</dt><dd>${fmt(vPin, 3)} V</dd>
            <dt>Module PO voltage</dt><dd>${fmt(vMod, 3)} V</dd>
            <dt>Computed by</dt><dd>${L.phSource?.startsWith('server') ? 'AQUA, probe ' + esc(L.phSource.split(':')[1]) : 'ESP32 firmware'}</dd>
            <dt>Reading time</dt><dd>${clock(L.ts)}</dd>
          </dl></div>
          <p class="muted small">To calibrate: rinse the probe, put it in a buffer, wait for RAW to settle over 2 to 3 readings, then record it in a new calibration.</p>`
          : `<div class="empty">Waiting for real ESP32 telemetry. Live RAW appears here for calibrating.</div>`}
      </section>
    </div>
    <section class="panel">
      <div class="panel-head"><h2>Calibration records</h2><span class="hint">Each record is tied to a physical probe and pond</span><div class="spacer"></div><button class="btn sm primary" id="newCal">${I('plus')}New calibration</button></div>
      <div class="scroll-x"><table class="tbl"><thead><tr><th>Probe</th><th>Pond</th><th>Date</th><th>pH 4.01 RAW</th><th>pH 6.86 RAW</th><th>pH 9.18 RAW</th><th>Status</th><th></th></tr></thead><tbody>
        ${state.calibrations.map(c => `<tr><td>${esc(c.probeId)}</td><td>${esc(c.pondId)}</td><td>${esc(c.calibrationDate)}</td><td>${rawAt(c, 4.01)}</td><td>${rawAt(c, 6.86)}</td><td>${rawAt(c, 9.18)}</td>
          <td>${c.active ? '<span class="chip ok">Active</span>' : `<button class="btn sm" data-act-cal="${esc(c.id)}">Make active</button>`}</td>
          <td class="row" style="flex-wrap:nowrap"><button class="btn sm ghost" data-edit-cal="${esc(c.id)}" aria-label="Edit">${I('edit')}</button>${c.active ? '' : `<button class="btn sm ghost" data-del-cal="${esc(c.id)}" aria-label="Delete">${I('trash')}</button>`}</td></tr>`).join('')}
      </tbody></table></div>
      <p class="muted small" style="margin-bottom:0">AQUA recalculates pH from the ESP32's RAW value using the active record for that pond, so a replacement probe only needs a new record, not new firmware.</p>
    </section>`;
  };
  VIEWS.calibration.after = () => {
    $('#newCal')?.addEventListener('click', () => openCalModal(null));
    $$('[data-edit-cal]').forEach(b => b.addEventListener('click', () => openCalModal(state.calibrations.find(c => c.id === b.dataset.editCal))));
    $$('[data-act-cal]').forEach(b => b.addEventListener('click', async () => {
      try { await api('/calibrations/' + b.dataset.actCal + '/activate', { method: 'POST' }); await load.calibrations(); await load.ponds(); render(); toast('Calibration activated', 'ok'); } catch (e) { toast(e.message, 'err'); }
    }));
    $$('[data-del-cal]').forEach(b => b.addEventListener('click', async () => {
      if (!await confirmDialog('Delete calibration?', 'This calibration record will be removed.')) return;
      try { await api('/calibrations/' + b.dataset.delCal, { method: 'DELETE' }); await load.calibrations(); render(); } catch (e) { toast(e.message, 'err'); }
    }));
  };

  function openCalModal(existing) {
    const p = selectedPond();
    const c = existing || { probeId: '', pondId: p?.id || '', deviceId: p?.deviceId || '', calibrationDate: new Date().toISOString().slice(0, 10),
      points: [{ ph: 4.01, raw: '' }, { ph: 6.86, raw: '' }, { ph: 9.18, raw: '' }], adcPin: 'GPIO34', dividerTopOhm: 20000, dividerBottomOhm: 10000, notes: '' };
    const pts = [0, 1, 2].map(i => c.points[i] || { ph: '', raw: '' });
    const m = openModal(`<h3>${existing ? 'Edit calibration' : 'New calibration'}</h3>
      <div class="form-grid" style="margin-top:14px">
        <label class="field">Probe ID<input type="text" id="cProbe" maxlength="40" value="${esc(c.probeId)}" placeholder="PH-02"></label>
        <label class="field">Calibration date<input type="date" id="cDate" value="${esc(c.calibrationDate)}"></label>
        <label class="field">Buffer temperature (°C)<small>Turns on temperature compensation</small><input type="number" step="0.1" id="cTemp" value="${esc(c.calTempC ?? '')}"></label>
        <label class="field">Pond<span id="cPondWrap">${pondOptions(c.pondId)}</span></label>
        <label class="field">Device ID<input type="text" id="cDev" maxlength="40" value="${esc(c.deviceId)}"></label>
      </div>
      <div class="panel" style="margin-top:14px;padding:12px 14px;background:rgba(3,9,14,.4)">
        <div class="row" style="justify-content:space-between"><b>Buffer points</b><span class="muted small">Live RAW: <b id="cLive" style="color:var(--aqua)">${esc(p?.latest?.phRaw ?? DASH)}</b></span></div>
        ${pts.map((pt, i) => `<div class="row" style="margin-top:10px;flex-wrap:nowrap">
          <label class="field" style="flex:1">Buffer pH<input type="number" step="0.01" data-cph="${i}" value="${esc(pt.ph)}"></label>
          <label class="field" style="flex:1">RAW<input type="number" step="1" data-craw="${i}" value="${esc(pt.raw)}"></label>
          <button class="btn sm" data-uselive="${i}" style="align-self:flex-end;height:40px" ${isNum(p?.latest?.phRaw) ? '' : 'disabled'}>Use live</button></div>`).join('')}
        <div class="muted small" id="cPreview" style="margin-top:10px"></div>
      </div>
      <div class="form-grid" style="margin-top:14px">
        <label class="field">ADC pin<input type="text" id="cPin" value="${esc(c.adcPin)}"></label>
        <div class="row" style="gap:10px;flex-wrap:nowrap"><label class="field" style="flex:1">Divider top Ω<input type="number" id="cTop" value="${esc(c.dividerTopOhm)}"></label><label class="field" style="flex:1">Divider bottom Ω<input type="number" id="cBot" value="${esc(c.dividerBottomOhm)}"></label></div>
        <label class="field full">Notes<textarea id="cNotes" maxlength="1000">${esc(c.notes)}</textarea></label>
        ${existing ? '' : '<div class="row full"><label class="switch"><input type="checkbox" id="cActivate" checked><span></span></label><span>Make this the active calibration for the pond</span></div>'}
      </div>
      <div class="modal-actions"><button class="btn" data-x>Cancel</button><button class="btn primary" id="cSave">Save calibration</button></div>`, { wide: true });
    const readPts = () => [0, 1, 2].map(i => ({ ph: Number(m.querySelector(`[data-cph="${i}"]`).value), raw: Number(m.querySelector(`[data-craw="${i}"]`).value) })).filter(x => m && x.raw > 0 && x.ph > 0);
    const preview = () => {
      const live = selectedPond()?.latest?.phRaw;
      const v = phFromRaw(live, readPts());
      $('#cPreview').textContent = isNum(v) ? `With these points, the live RAW ${live} reads pH ${v.toFixed(2)}.` : 'Enter at least two buffer points to preview.';
    };
    m.addEventListener('input', preview);
    m.querySelectorAll('[data-uselive]').forEach(b => b.onclick = () => {
      const raw = selectedPond()?.latest?.phRaw;
      if (isNum(raw)) { m.querySelector(`[data-craw="${b.dataset.uselive}"]`).value = raw; preview(); }
    });
    preview();
    m.querySelector('[data-x]').onclick = closeModal;
    $('#cSave').onclick = async () => {
      const body = { probeId: $('#cProbe').value, calibrationDate: $('#cDate').value, calTempC: $('#cTemp').value === '' ? null : Number($('#cTemp').value), pondId: $('#cPondWrap input').value.trim(), deviceId: $('#cDev').value,
        points: readPts(), adcPin: $('#cPin').value, dividerTopOhm: Number($('#cTop').value), dividerBottomOhm: Number($('#cBot').value), notes: $('#cNotes').value,
        activate: existing ? undefined : $('#cActivate').checked };
      try {
        await api(existing ? '/calibrations/' + existing.id : '/calibrations', { method: existing ? 'PUT' : 'POST', body });
        closeModal(); await load.calibrations(); await load.ponds(); render(); toast('Calibration saved', 'ok');
      } catch (e) { toast(e.message, 'err'); }
    };
  }

  // ===== Water quality (manual test-kit log)
  const WQ = [
    ['tanMgL', 'Total ammonia N', 'mg/L', 2],
    ['nh3nMgL', 'Un-ionised NH₃-N', 'mg/L', 3],
    ['no2nMgL', 'Nitrite N', 'mg/L', 2],
    ['no3nMgL', 'Nitrate N', 'mg/L', 1],
    ['alkalinityMgL', 'Alkalinity', 'mg/L', 0],
    ['salinityPpt', 'Salinity', 'ppt', 1]
  ];
  const flagChip = (f, text) => `<span class="chip ${f === 'crit' ? 'crit' : f === 'warn' ? 'warn' : f === 'ok' ? 'ok' : 'off'}">${text}</span>`;
  const pondIdForLogs = () => selectedPond()?.id || state.water.entries[0]?.pondId || state.cycles[0]?.pondId || null;
  const today = () => { const d = new Date(); d.setMinutes(d.getMinutes() - d.getTimezoneOffset()); return d.toISOString().slice(0, 10); };
  const profileOf = id => state.full?.pondProfiles?.[id] || {};

  VIEWS.water = () => {
    const pid = pondIdForLogs();
    const list = state.water.entries.filter(w => !pid || w.pondId === pid);
    const lim = state.water.limits || {};
    const prof = profileOf(pid);
    const vol = prof.systemVolumeM3 ?? prof.volumeM3;
    const latestOf = k => list.find(w => isNum(w[k]));
    const cards = WQ.map(([k, label, unit, d]) => {
      const e = latestOf(k), l = lim[k] || {};
      const range = [isNum(l.warnLow) ? 'at least ' + l.warnLow : '', isNum(l.warnHigh) ? 'at most ' + l.warnHigh : ''].filter(Boolean).join(', ');
      return `<article class="panel wq-card ${e ? 'wq-' + (e.flags?.[k] || 'ok') : ''}"><div class="muted small">${label}${k === 'nh3nMgL' ? ' (calculated)' : ''}</div>
        <div class="wq-val">${e ? fmt(e[k], d) : DASH}<span class="unit"> ${unit}</span></div>
        <div class="muted small">${e ? dateTime(e.ts) : 'No test yet'}${range ? '<br>Target ' + range : ''}</div></article>`;
    }).join('');
    const lastAlk = latestOf('alkalinityMgL');
    const target = lim.alkalinityMgL?.target;
    let dose = '';
    if (lastAlk && isNum(target) && lastAlk.alkalinityMgL < target) {
      dose = isNum(lastAlk.bicarbDoseG)
        ? `<div class="notice warn"><b>Alkalinity ${fmt(lastAlk.alkalinityMgL, 0)} mg/L is below the ${target} mg/L target.</b> For the ${vol} m³ system that is about <b>${lastAlk.bicarbDoseG} g of sodium bicarbonate</b> (baking soda). Dissolve it in system water, add it in 2 to 3 portions a few hours apart, then test again.</div>`
        : `<div class="notice">Alkalinity is below target. Enter this pond's system water volume in Settings to get a sodium bicarbonate dose.</div>`;
    }
    return `<section class="row"><p class="muted" style="margin:0;max-width:72ch">Results from your test kits${pid ? ' for ' + esc(state.ponds[pid]?.name || pid) : ''}. AQUA works out the toxic un-ionised ammonia from total ammonia using the pH and temperature at the time of the test.</p><div style="flex:1"></div>
        <button class="btn" id="wqLimits">Limits</button><button class="btn primary" id="wqAdd">${I('plus')}Add test result</button></section>
      ${dose}
      <section class="wq-grid">${cards}</section>
      <section class="panel"><div class="panel-head"><h2>Test history</h2></div>
      ${list.length ? `<div class="scroll-x"><table class="tbl"><thead><tr><th>Time</th>${WQ.map(([, l]) => `<th>${l}</th>`).join('')}<th>pH / °C used</th><th>By</th><th></th></tr></thead><tbody>
        ${list.slice(0, 60).map(e => `<tr><td>${dateTime(e.ts)}</td>${WQ.map(([k, , , d]) => `<td>${isNum(e[k]) ? flagChip(e.flags?.[k], fmt(e[k], d)) : '<span class="muted">—</span>'}</td>`).join('')}
          <td class="small muted">${isNum(e.phAtTest) && isNum(e.tempAtTest) ? fmt(e.phAtTest) + ' / ' + fmt(e.tempAtTest, 1) + (e.phTempSource === 'live sensor' ? ' (live)' : '') : DASH}</td><td>${esc(e.by || '')}</td>
          <td><button class="btn sm ghost" data-wq-del="${esc(e.id)}" aria-label="Delete">${I('trash')}</button></td></tr>`).join('')}
      </tbody></table></div>` : `<div class="empty">No test results yet. While the biofilter is new, test ammonia and nitrite every day; once it is stable, 2 to 3 times a week.</div>`}
      </section>`;
  };
  VIEWS.water.after = () => {
    $('#wqAdd')?.addEventListener('click', openWaterModal);
    $('#wqLimits')?.addEventListener('click', openLimitsModal);
    $$('[data-wq-del]').forEach(b => b.addEventListener('click', async () => {
      if (!await confirmDialog('Delete test result?', 'This result will be removed from the log.')) return;
      try { await api('/water/' + b.dataset.wqDel, { method: 'DELETE' }); await load.water(); render(); } catch (e) { toast(e.message, 'err'); }
    }));
  };
  function openWaterModal() {
    const pid = pondIdForLogs() || '';
    const live = state.ponds[pid]?.latest;
    const now = new Date(); now.setMinutes(now.getMinutes() - now.getTimezoneOffset());
    const m = openModal(`<h3>Add test result</h3><p class="muted small">Leave a box empty if you did not test it.</p>
      <div class="form-grid" style="margin-top:12px">
        <label class="field">Pond<span id="wPond">${pondOptions(pid)}</span></label>
        <label class="field">Tested at<input type="datetime-local" id="wTs" value="${now.toISOString().slice(0, 16)}"></label>
        <label class="field">Total ammonia N (TAN), mg/L<input type="number" step="0.01" min="0" data-w="tanMgL"></label>
        <label class="field">Nitrite N (NO₂-N), mg/L<input type="number" step="0.01" min="0" data-w="no2nMgL"></label>
        <label class="field">Nitrate N (NO₃-N), mg/L<input type="number" step="0.1" min="0" data-w="no3nMgL"></label>
        <label class="field">Alkalinity, mg/L as CaCO₃<input type="number" step="1" min="0" data-w="alkalinityMgL"></label>
        <label class="field">Salinity, ppt<input type="number" step="0.1" min="0" data-w="salinityPpt"></label>
        <label class="field">Tested by<input type="text" id="wBy" maxlength="40"></label>
        <label class="field">pH at test<small>Empty = live sensor${live && isNum(live.ph) ? ' (' + fmt(live.ph) + ')' : ''}</small><input type="number" step="0.01" id="wPh"></label>
        <label class="field">Water temperature at test, °C<small>Empty = live sensor${live && isNum(live.temperatureC) ? ' (' + fmt(live.temperatureC, 1) + ')' : ''}</small><input type="number" step="0.1" id="wT"></label>
        <label class="field full">Notes<textarea id="wNotes" maxlength="500"></textarea></label>
      </div>
      <p class="muted small">Kit shows the ion instead of nitrogen? Divide NH₄⁺ by 1.29, NO₂⁻ by 3.29 and NO₃⁻ by 4.43 to get the N value.</p>
      <div class="modal-actions"><button class="btn" data-x>Cancel</button><button class="btn primary" id="wSave">Save result</button></div>`, { wide: true });
    m.querySelector('[data-x]').onclick = closeModal;
    $('#wSave').onclick = async () => {
      const body = {
        pondId: $('#wPond input').value.trim(), ts: $('#wTs').value ? new Date($('#wTs').value).toISOString() : undefined,
        by: $('#wBy').value, notes: $('#wNotes').value,
        phAtTest: $('#wPh').value === '' ? null : Number($('#wPh').value), tempAtTest: $('#wT').value === '' ? null : Number($('#wT').value)
      };
      m.querySelectorAll('[data-w]').forEach(i => { body[i.dataset.w] = i.value === '' ? null : Number(i.value); });
      try {
        const e = await api('/water', { method: 'POST', body });
        closeModal(); await Promise.all([load.water(), load.alerts()]); render();
        const bad = Object.entries(e.flags || {}).filter(([, f]) => f !== 'ok');
        toast(bad.length ? 'Saved. Out of range: ' + bad.map(([k]) => (WQ.find(w => w[0] === k) || [k, k])[1]).join(', ') : 'Saved. All results within limits.', bad.length ? 'err' : 'ok');
      } catch (err) { toast(err.message, 'err'); }
    };
  }
  function openLimitsModal() {
    const lim = state.water.limits || {};
    const F = ['critLow', 'warnLow', 'warnHigh', 'critHigh'];
    const m = openModal(`<h3>Water quality limits</h3><p class="muted small">Defaults are for Pacific white shrimp in low-salinity RAS. Leave a box empty for no limit.</p>
      <div class="scroll-x"><table class="tbl"><thead><tr><th>Parameter</th><th>Critical below</th><th>Warning below</th><th>Warning above</th><th>Critical above</th></tr></thead><tbody>
      ${Object.entries(lim).map(([k, l]) => `<tr><td>${esc(l.name)}<div class="muted small">${esc(l.nameZh)}, ${esc(l.unit)}</div></td>${F.map(f => `<td><input type="number" step="0.01" style="width:90px" data-lim="${k}" data-f="${f}" value="${isNum(l[f]) ? l[f] : ''}"></td>`).join('')}</tr>`).join('')}
      </tbody></table></div>
      <label class="field" style="margin-top:12px;max-width:280px">Alkalinity target for dosing, mg/L<input type="number" id="limTarget" value="${lim.alkalinityMgL?.target ?? ''}"></label>
      <div class="modal-actions"><button class="btn" data-x>Cancel</button><button class="btn primary" id="limSave">Save limits</button></div>`, { wide: true });
    m.querySelector('[data-x]').onclick = closeModal;
    $('#limSave').onclick = async () => {
      const body = {};
      m.querySelectorAll('[data-lim]').forEach(i => { (body[i.dataset.lim] ||= {})[i.dataset.f] = i.value === '' ? null : Number(i.value); });
      (body.alkalinityMgL ||= {}).target = $('#limTarget').value === '' ? null : Number($('#limTarget').value);
      try { await api('/water/limits', { method: 'PUT', body }); closeModal(); await load.water(); render(); toast('Limits saved', 'ok'); } catch (e) { toast(e.message, 'err'); }
    };
  }

  // ===== Crop cycle
  const REC_LABEL = { sample: 'Weight sample', mortality: 'Dead shrimp', feed: 'Feed', harvest: 'Harvest' };
  function recValue(r) {
    if (r.type === 'sample') return fmt(r.avgWeightG) + ' g average' + (isNum(r.sampleCount) ? ` (${r.sampleCount} weighed)` : '');
    if (r.type === 'mortality') return r.count.toLocaleString() + ' dead';
    if (r.type === 'feed') return fmt(r.kg, 2) + ' kg';
    if (r.type === 'harvest') return fmt(r.kg, 1) + ' kg' + (isNum(r.count) ? ', ' + r.count.toLocaleString() + ' shrimp' : '');
    return DASH;
  }
  VIEWS.cycle = () => {
    const pid = pondIdForLogs();
    const mine = state.cycles.filter(c => !pid || c.pondId === pid);
    const active = mine.find(c => c.status === 'active');
    const closed = mine.filter(c => c.status !== 'active');
    const prof = profileOf(pid);
    let body;
    if (!active) {
      body = `<section class="panel"><div class="empty big"><b>No active production cycle${pid ? ' for ' + esc(state.ponds[pid]?.name || pid) : ''}</b>Start a cycle on stocking day. Record weekly weight samples, feed in kg and any dead shrimp found. AQUA then estimates survival, biomass, growth and FCR: the numbers that show whether the POC worked.
        <div style="margin-top:16px"><button class="btn primary" id="cyStart">${I('plus')}Start cycle</button></div></div></section>`;
    } else {
      const s = active.summary;
      const st = (label, v, sub = '') => `<div class="stat"><div class="muted small">${label}</div><div class="stat-v">${v}</div>${sub ? `<div class="muted small">${sub}</div>` : ''}</div>`;
      body = `<section class="panel"><div class="panel-head"><h2>Cycle started ${esc(active.startDate)}</h2><span class="hint">${esc(active.plSource || '')}</span><div class="spacer"></div><button class="btn sm primary" id="cyRec">${I('plus')}Add record</button><button class="btn sm ghost" id="cyClose">Close cycle</button></div>
        <div class="stat-grid">
          ${st('Day of culture', s.doc)}
          ${st('Stocked', s.stocked?.toLocaleString() ?? DASH, active.initialWeightG ? active.initialWeightG + ' g each' : '')}
          ${st('Estimated alive', s.aliveEst?.toLocaleString() ?? DASH, s.mortality ? s.mortality.toLocaleString() + ' counted dead' : 'no deaths recorded')}
          ${st('Estimated survival', isNum(s.survivalEstPct) ? s.survivalEstPct + ' %' : DASH, 'from counted deaths only')}
          ${st('Average weight', isNum(s.abwG) ? fmt(s.abwG) + ' g' : DASH, s.lastSampleDate ? 'sampled ' + s.lastSampleDate : 'no sample yet')}
          ${st('Growth', isNum(s.weeklyGainG) ? fmt(s.weeklyGainG) + ' g/week' : isNum(s.adgG) ? fmt(s.adgG, 3) + ' g/day' : DASH, isNum(s.weeklyGainG) ? 'between the last two samples' : 'since stocking')}
          ${st('Estimated biomass', isNum(s.biomassEstKg) ? fmt(s.biomassEstKg, 1) + ' kg' : DASH, isNum(s.biomassKgPerM3) ? fmt(s.biomassKgPerM3) + ' kg/m³' : (prof.volumeM3 ? '' : 'set tank volume in Settings'))}
          ${st('Feed used', fmt(s.feedKg, 1) + ' kg')}
          ${st('Estimated FCR', isNum(s.fcrEst) ? fmt(s.fcrEst) : DASH, 'feed ÷ weight gained')}
          ${st('Density', isNum(s.densityPerM3) ? s.densityPerM3.toLocaleString() + ' /m³' : DASH)}
        </div>
        <p class="muted small" style="margin-bottom:0">Before harvest these are estimates. Dead shrimp are often eaten or never found, so real survival is usually lower and real FCR higher than shown. The harvest record gives the true numbers.</p></section>
        <section class="panel"><div class="panel-head"><h2>Records</h2></div>
        ${active.records.length ? `<div class="scroll-x"><table class="tbl"><thead><tr><th>Date</th><th>Type</th><th>Value</th><th>Notes</th><th></th></tr></thead><tbody>
          ${[...active.records].sort((a, b) => b.date.localeCompare(a.date)).map(r => `<tr><td>${esc(r.date)}</td><td>${REC_LABEL[r.type] || esc(r.type)}</td><td>${recValue(r)}</td><td class="muted small wrap">${esc(r.notes || '')}</td><td><button class="btn sm ghost" data-rec-del="${esc(r.id)}" aria-label="Delete">${I('trash')}</button></td></tr>`).join('')}
        </tbody></table></div>` : '<div class="empty">No records yet.</div>'}</section>`;
    }
    const hist = closed.length ? `<section class="panel"><div class="panel-head"><h2>Finished cycles</h2></div><div class="scroll-x"><table class="tbl"><thead><tr><th>Pond</th><th>Stocked</th><th>Closed</th><th>Days</th><th>Survival</th><th>FCR</th><th>Harvest</th></tr></thead><tbody>
      ${closed.map(c => `<tr><td>${esc(c.pondId)}</td><td>${esc(c.startDate)}</td><td>${esc(c.endDate || '')}</td><td>${c.summary.doc}</td><td>${isNum(c.summary.survivalPct) ? c.summary.survivalPct + ' %' : DASH}</td><td>${isNum(c.summary.fcr) ? fmt(c.summary.fcr) : DASH}</td><td>${isNum(c.summary.harvestKg) ? fmt(c.summary.harvestKg, 1) + ' kg' : DASH}</td></tr>`).join('')}</tbody></table></div></section>` : '';
    return body + hist;
  };
  VIEWS.cycle.after = () => {
    const pid = pondIdForLogs();
    const active = state.cycles.find(c => c.status === 'active' && (!pid || c.pondId === pid));
    $('#cyStart')?.addEventListener('click', () => openCycleStart(pid));
    $('#cyRec')?.addEventListener('click', () => openRecordModal(active));
    $('#cyClose')?.addEventListener('click', async () => {
      if (!await confirmDialog('Close this cycle?', 'Do this after harvest. Add the harvest record first so survival and FCR are real numbers.', 'Close cycle', false)) return;
      try { await api('/cycles/' + active.id, { method: 'PUT', body: { close: true } }); await load.cycles(); render(); } catch (e) { toast(e.message, 'err'); }
    });
    $$('[data-rec-del]').forEach(b => b.addEventListener('click', async () => {
      if (!await confirmDialog('Delete record?', 'This record will be removed from the cycle.')) return;
      try { await api(`/cycles/${active.id}/records/${b.dataset.recDel}`, { method: 'DELETE' }); await load.cycles(); render(); } catch (e) { toast(e.message, 'err'); }
    }));
  };
  function openCycleStart(pid) {
    const m = openModal(`<h3>Start production cycle</h3><div class="form-grid" style="margin-top:12px">
      <label class="field">Pond<span id="cyPond">${pondOptions(pid || '')}</span></label>
      <label class="field">Stocking date<input type="date" id="cyDate" value="${today()}"></label>
      <label class="field">Post-larvae stocked<input type="number" id="cyCount" min="1" step="1"></label>
      <label class="field">Average weight at stocking, g<small>Optional</small><input type="number" id="cyW0" step="0.001" min="0"></label>
      <label class="field full">Hatchery / PL source<input type="text" id="cySrc" maxlength="100"></label>
      <label class="field full">Notes<textarea id="cyNotes" maxlength="1000"></textarea></label></div>
      <div class="modal-actions"><button class="btn" data-x>Cancel</button><button class="btn primary" id="cySave">Start cycle</button></div>`);
    m.querySelector('[data-x]').onclick = closeModal;
    $('#cySave').onclick = async () => {
      try {
        await api('/cycles', { method: 'POST', body: { pondId: $('#cyPond input').value.trim(), startDate: $('#cyDate').value, stockedCount: Number($('#cyCount').value),
          initialWeightG: $('#cyW0').value === '' ? null : Number($('#cyW0').value), plSource: $('#cySrc').value, notes: $('#cyNotes').value } });
        closeModal(); await load.cycles(); render(); toast('Cycle started', 'ok');
      } catch (e) { toast(e.message, 'err'); }
    };
  }
  function openRecordModal(c) {
    const m = openModal(`<h3>Add record</h3><div class="form-grid" style="margin-top:12px">
      <label class="field">Type<select id="rType"><option value="sample">Weight sample</option><option value="feed">Feed (kg)</option><option value="mortality">Dead shrimp</option><option value="harvest">Harvest</option></select></label>
      <label class="field">Date<input type="date" id="rDate" value="${today()}"></label>
      <label class="field" data-rt="sample">Average weight, g<input type="number" step="0.01" min="0" id="rW"></label>
      <label class="field" data-rt="sample">Shrimp weighed<small>Weigh at least 30 from different spots</small><input type="number" step="1" min="1" id="rN"></label>
      <label class="field" data-rt="feed harvest">Weight, kg<input type="number" step="0.01" min="0" id="rKg"></label>
      <label class="field" data-rt="mortality harvest">Number of shrimp<input type="number" step="1" min="0" id="rC"></label>
      <label class="field full">Notes<input type="text" id="rNotes" maxlength="300"></label></div>
      <div class="modal-actions"><button class="btn" data-x>Cancel</button><button class="btn primary" id="rSave">Save record</button></div>`);
    const sync = () => { const t = $('#rType').value; m.querySelectorAll('[data-rt]').forEach(el => { el.style.display = el.dataset.rt.split(' ').includes(t) ? '' : 'none'; }); };
    sync(); $('#rType').onchange = sync;
    m.querySelector('[data-x]').onclick = closeModal;
    $('#rSave').onclick = async () => {
      const v = id => ($(id).value === '' ? null : Number($(id).value));
      try {
        await api(`/cycles/${c.id}/records`, { method: 'POST', body: { type: $('#rType').value, date: $('#rDate').value, avgWeightG: v('#rW'), sampleCount: v('#rN'), kg: v('#rKg'), count: v('#rC'), notes: $('#rNotes').value } });
        closeModal(); await load.cycles(); render(); toast('Record saved', 'ok');
      } catch (e) { toast(e.message, 'err'); }
    };
  }

  // ===== Settings
  VIEWS.settings = () => {
    const i = state.info || {}, f = state.full || {};
    const lan = i.lan || [], st = i.storage || {};
    const n = f.notifications || { pushover: {} }, po = n.pushover || {}, wd = f.watchdog || {}, il = f.interlock || {};
    const mb = b => (b / 1048576).toFixed(2) + ' MB';
    const pondIds = [...new Set([...pondList().map(p => p.id), ...Object.keys(f.pondProfiles || {})])].sort();
    if (!hasPerm('monitor.read')) return state.auth?.signedIn ? localAccountPanel() : '';
    return `${accountPanels()}${usersPanel()}<section class="panel ${po.enabled ? '' : 'attention'}">
      <div class="panel-head"><h2>Phone alerts (Pushover)</h2><div class="spacer"></div>${po.enabled ? '<span class="chip ok">On</span>' : '<span class="chip crit">Off: nobody is woken at night</span>'}</div>
      <div class="help small" style="display:grid;gap:6px;margin-bottom:14px">
        <div>1. Install <b>Pushover</b> on every phone that should ring (iPhone and Android) and sign in.</div>
        <div>2. At pushover.net create an <b>Application</b> (gives the API token) and a <b>Delivery group</b> containing everyone (gives the group key).</div>
        <div>3. Paste both below, switch on, then press <b>Test emergency</b>. iPhone: allow Critical Alerts for Pushover. Android: allow Pushover to override Do Not Disturb.</div>
      </div>
      <div class="form-grid">
        <label class="field">API token<small>${po.appTokenSet ? 'Saved (' + esc(po.appTokenHint) + '). Leave empty to keep it.' : 'Not set'}</small><input type="password" id="poToken" autocomplete="off" placeholder="30 letters and numbers"></label>
        <label class="field">User or delivery-group key<small>${po.userKeySet ? 'Saved (' + esc(po.userKeyHint) + '). Leave empty to keep it.' : 'Not set'}</small><input type="password" id="poUser" autocomplete="off" placeholder="30 letters and numbers"></label>
        <label class="field full">Dashboard link in alerts<small>Optional: the https address from Tailscale or Cloudflare, so tapping an alert opens AQUA.</small><input type="url" id="pubUrl" value="${esc(i.settings?.publicUrl || '')}" placeholder="https://"></label>
        <div class="row full"><label class="switch"><input type="checkbox" id="poOn" ${po.enabled ? 'checked' : ''}><span></span></label><span>Send phone alerts</span></div>
      </div>
      <div class="modal-actions" style="justify-content:flex-start"><button class="btn primary" id="poSave">Save phone alerts</button><button class="btn" id="poTest">Test normal</button><button class="btn" id="poTestE">Test emergency</button></div>
      <p class="muted small">Critical alerts ring every 30 seconds until someone taps Acknowledge in Pushover (up to 30 minutes). Warnings arrive as high-priority notifications. Alert text is in Chinese. A failed send is retried after 1, 2 and 3 minutes.</p>
      ${(f.notifyLog || []).length ? `<div class="scroll-x"><table class="tbl"><thead><tr><th>Sent</th><th>Message</th><th>Result</th></tr></thead><tbody>${f.notifyLog.slice(0, 8).map(l => `<tr><td>${dateTime(l.ts)}</td><td class="wrap">${esc(l.title)}${l.priority === 2 ? ' <span class="chip crit">emergency</span>' : ''}</td><td class="wrap">${l.ok ? '<span class="chip ok">Delivered to Pushover</span>' : `<span class="chip crit">Failed</span> <span class="muted small">${esc(l.error || '')}${l.attempt > 1 ? ', attempt ' + l.attempt : ''}</span>`}</td></tr>`).join('')}</tbody></table></div>` : ''}
    </section>
    <div class="split">
      <section class="panel">
        <div class="panel-head"><h2>Watchdog</h2><div class="spacer"></div>${n.watchdogSet ? (wd.ok ? '<span class="chip ok">Reporting</span>' : wd.ok === false ? '<span class="chip crit">Ping failing</span>' : '<span class="chip warn">Waiting</span>') : '<span class="chip warn">Not set</span>'}</div>
        <p class="muted small" style="margin-top:0">If this PC loses power or internet, AQUA cannot send alerts itself. A free check at healthchecks.io notices when AQUA stops reporting and alerts you through its own Pushover integration. Use period 1 minute, grace 5 minutes.</p>
        <label class="field">Ping URL<small>${n.watchdogSet ? 'Saved: ' + esc(n.watchdogHost) + (wd.lastAt ? ', last ping ' + rel(wd.lastAt) + (wd.error ? ' (' + esc(wd.error) + ')' : '') : '') : 'Not set'}</small><input type="url" id="wdUrl" placeholder="https://hc-ping.com/…"></label>
        <div class="modal-actions" style="justify-content:flex-start"><button class="btn primary" id="wdSave">Save watchdog</button>${n.watchdogSet ? '<button class="btn ghost danger" id="wdClear">Remove</button>' : ''}</div>
      </section>
      <section class="panel">
        <div class="panel-head"><h2>Feeding safety</h2></div>
        <div style="display:grid;gap:12px">
          <div class="row" style="flex-wrap:nowrap"><label class="switch"><input type="checkbox" id="ilOff" ${il.blockWhenOffline ? 'checked' : ''}><span></span></label><span>Pause feeding when the pond monitor is offline</span></div>
          <div class="row" style="flex-wrap:nowrap"><label class="switch"><input type="checkbox" id="ilCrit" ${il.blockOnCritical ? 'checked' : ''}><span></span></label><span>Pause feeding while a critical alert is active (pump stopped, low oxygen, high nitrite)</span></div>
          <div class="form-grid"><label class="field">Pause window start<small>Optional</small><input type="time" id="ilQs" value="${esc(il.quietStart || '')}"></label><label class="field">Pause window end<small>Optional</small><input type="time" id="ilQe" value="${esc(il.quietEnd || '')}"></label></div>
          <p class="muted small" style="margin:0">Scheduled feeds are skipped and logged as Skipped. Feed now asks for an in-person check before overriding.</p>
        </div>
        <div class="modal-actions" style="justify-content:flex-start"><button class="btn primary" id="ilSave">Save feeding safety</button></div>
      </section>
    </div>
    <section class="panel">
      <div class="panel-head"><h2>Water volume</h2><span class="hint">Tank volume is used for stocking density; system volume (tanks + sump + filters) for chemical dosing</span></div>
      ${pondIds.length ? `<div class="scroll-x"><table class="tbl"><thead><tr><th>Pond</th><th>Culture tank, m³</th><th>Whole system, m³</th><th></th></tr></thead><tbody>${pondIds.map(id => `<tr><td>${esc(state.ponds[id]?.name || id)} <span class="muted small">${esc(id)}</span></td>
        <td><input type="number" step="0.1" min="0" style="width:120px" data-vol="${esc(id)}" value="${esc(f.pondProfiles?.[id]?.volumeM3 ?? '')}"></td>
        <td><input type="number" step="0.1" min="0" style="width:120px" data-svol="${esc(id)}" value="${esc(f.pondProfiles?.[id]?.systemVolumeM3 ?? '')}"></td>
        <td><button class="btn sm" data-vol-save="${esc(id)}">Save</button></td></tr>`).join('')}</tbody></table></div>`
        : '<div class="empty">Ponds appear here after their ESP32 reports.</div>'}
    </section>
    ${i.mode === 'cloud' ? '' : `    <div class="split">
      <section class="panel">
        <div class="panel-head"><h2>Connect an ESP32</h2></div>
        <div class="help small" style="display:grid;gap:8px">
          <div>In the firmware set <code>MQTT_HOST</code> to ${lan.length ? lan.map(a => `<code>${esc(a.address)}</code>`).join(' or ') : 'this computer\'s LAN IP'} and <code>MQTT_PORT</code> to <code>${esc(i.mqttPort || 1883)}</code>.</div>
          <div>Firmware <code>SITE_ID "${esc(i.site?.id || 'SITE-01')}"</code>. Topics: <code>aqua/site/${esc(i.site?.id || 'SITE-01')}/pond/&lt;POND_ID&gt;/telemetry</code> and <code>/status</code>. Firmware older than 2.0.3 (topics <code>aqua/pond/…</code>) still works.</div>
          <div class="muted">MQTT stays on your local network. Never forward port 1883 on the router.</div>
          <div>MQTT clients connected now: <b>${esc(i.mqttClients ?? DASH)}</b></div>
        </div>
      </section>
      <section class="panel">
        <div class="panel-head"><h2>Open on your phone</h2></div>
        <div class="help small" style="display:grid;gap:8px">
          <div>Same Wi-Fi as this computer: ${lan.length ? lan.map(a => `<code>http://${esc(a.address)}:${esc(i.httpPort)}</code>`).join(' ') : DASH}</div>
          <div>Add to Home Screen: Safari share menu on iPhone, or the browser menu on Android.</div>
          <div class="muted">Away from the shop, use Tailscale or Cloudflare Tunnel (see README).</div>
        </div>
      </section>
    </div>`}
    <section class="panel">
      <div class="panel-head"><h2>General</h2></div>
      <div class="form-grid">
        <label class="field">Farm / site name<input type="text" id="setSite" maxlength="60" value="${esc(i.site?.name || '')}"></label>
        <label class="field">Mark device offline after (minutes)<input type="number" id="setOff" min="2" max="60" value="${Math.round((i.settings?.offlineAfterSec || 300) / 60)}"></label>
      </div>
      <div class="modal-actions" style="justify-content:flex-start"><button class="btn primary" id="setSave">Save settings</button></div>
    </section>
    <section class="panel">
      <div class="panel-head"><h2>Data and backup</h2></div>
      <div class="stats" style="margin-bottom:14px"><span>History files<b>${esc(st.files ?? DASH)}</b></span><span>History size<b>${st.bytes != null ? mb(st.bytes) : DASH}</b></span><span>Ponds with history<b>${Object.keys(st.ponds || {}).length}</b></span></div>
      <div class="row">
        <a class="btn" href="/api/backup">${I('download')}Download configuration backup</a>
        ${pondList().map(p => `<a class="btn" href="/api/ponds/${encodeURIComponent(p.id)}/export.csv?range=30d">${I('download')}${esc(p.name)} 30-day CSV</a>`).join('')}
      </div>
      <p class="muted small" style="margin-bottom:0">The configuration backup contains your Pushover keys: keep it private. Full backup: run <code>BACKUP_DATA.bat</code> or copy the <code>data</code> folder.</p>
    </section>
    <section class="panel">
      <div class="panel-head"><h2>About</h2></div>
      <div class="small muted">SMARTFUZE AQUA ${esc(i.version || '')}, server ${esc(i.hostname || '')}, dashboard port ${esc(i.httpPort || '')}, MQTT port ${esc(i.mqttPort || '')}. Site ID <code>${esc(i.site?.id || '')}</code>${(i.sites || []).length > 1 ? ', other sites seen: ' + i.sites.filter(x => !x.default).map(x => '<code>' + esc(x.id) + '</code>').join(' ') : ''}. This system shows real hardware data only.</div>
    </section>
    <section class="panel">
      <div class="panel-head"><h2>System modules</h2><span class="hint">How the parts of AQUA pass events to each other</span></div>
      <div id="busInfo"><div class="empty">Loading…</div></div>
    </section>`;
  };
  function accountPanels() {
    const i = state.info || {};
    if (i.mode !== 'cloud') return state.auth?.signedIn ? localAccountPanel() : '';
    const creds = state.creds || [];
    const host = i.publicHost || location.hostname;
    return `<div class="split">
      <section class="panel"><div class="panel-head"><h2>Account</h2><div class="spacer"></div><span class="chip ok">Signed in as ${esc(state.auth?.username || 'admin')}</span></div>
        <div class="form-grid"><label class="field">Current password<input type="password" id="pwCur" autocomplete="current-password"></label>
        <label class="field">New password<small>At least 10 characters</small><input type="password" id="pwNew" autocomplete="new-password"></label></div>
        <div class="modal-actions" style="justify-content:flex-start"><button class="btn primary" id="pwSave">Change password</button><button class="btn ghost" id="logout">Sign out</button></div>
        <p class="muted small" style="margin-bottom:0">Changing the password signs out every other phone. Forgot it? Run <code>sudo aqua-reset-password</code> in the server console.</p></section>
      <section class="panel"><div class="panel-head"><h2>Device logins</h2><div class="spacer"></div><button class="btn sm" id="credAdd">${I('plus')}New device login</button></div>
        <div class="help small" style="display:grid;gap:6px;margin-bottom:10px">
          <div>ESP32 firmware: <code>USE_TLS 1</code>, <code>MQTT_HOST "${esc(host)}"</code>, <code>MQTT_PORT 8883</code>, <code>SITE_ID "${esc(i.site?.id || 'SITE-01')}"</code>, plus the login below. Each ESP32 gets its own login and can only report for its own pond.</div>
          <div>Encrypted device connection: ${i.tls?.enabled ? `<span class="chip ok">ready</span>${i.tls.expires ? ' <span class="muted">certificate renews automatically, current one valid to ' + esc(i.tls.expires.slice(0, 10)) + '</span>' : ''}` : `<span class="chip warn">${esc(i.tls?.error || 'not ready')}</span>`}</div>
        </div>
        ${creds.length ? `<div class="scroll-x"><table class="tbl"><thead><tr><th>Username</th><th>Site / pond</th><th>Last connected</th><th></th></tr></thead><tbody>${creds.map(c => `<tr><td><code>${esc(c.username)}</code></td><td>${esc(c.siteId || 'any site')} / ${esc(c.pondId)}</td><td>${c.lastLoginAt ? rel(c.lastLoginAt) : 'never'}</td><td><button class="btn sm ghost" data-cred-del="${esc(c.username)}" aria-label="Delete">${I('trash')}</button></td></tr>`).join('')}</tbody></table></div>`
          : '<div class="empty">No device logins yet.</div>'}
      </section></div>`;
  }

  VIEWS.settings.after = () => {
    localAccountAfter(); usersAfter();
    if (!hasPerm('monitor.read')) return;
    if (state.info?.mode === 'cloud') {
      if (state.creds === null) { api('/devices/credentials').then(c => { state.creds = c; if (route() === 'settings') render(); }).catch(() => {}); }
      $('#pwSave')?.addEventListener('click', async () => {
        try { await api('/auth/password', { method: 'POST', body: { current: $('#pwCur').value, password: $('#pwNew').value } }); toast('Password changed. Other phones are signed out.', 'ok'); $('#pwCur').value = ''; $('#pwNew').value = ''; }
        catch (e) { toast(e.message, 'err'); }
      });
      $('#logout')?.addEventListener('click', async () => { try { await api('/auth/logout', { method: 'POST' }); } catch (_) {} state.auth.loggedIn = false; showLogin('Signed out.'); });
      $('#credAdd')?.addEventListener('click', () => {
        const m = openModal(`<h3>New device login</h3><p class="muted small">One login per ESP32. It can only send data for this pond.</p>
          <div class="form-grid" style="margin-top:12px"><label class="field">Pond ID<small>Must match POND_ID in the firmware</small><span id="cdPond">${pondOptions(selectedPond()?.id || '')}</span></label>
          <label class="field">Username<small>Optional</small><input type="text" id="cdUser" maxlength="40" placeholder="dev-pond-b"></label></div>
          <div class="modal-actions"><button class="btn" data-x>Cancel</button><button class="btn primary" id="cdSave">Create login</button></div>`);
        m.querySelector('[data-x]').onclick = closeModal;
        $('#cdSave').onclick = async () => {
          try {
            const r = await api('/devices/credentials', { method: 'POST', body: { pondId: $('#cdPond input').value.trim(), username: $('#cdUser').value.trim() } });
            state.creds = null;
            const host = state.info.publicHost || location.hostname;
            const code = `#define USE_TLS 1\nconst char* MQTT_HOST = "${host}";\nconst uint16_t MQTT_PORT = 8883;\nconst char* MQTT_USER = "${r.username}";\nconst char* MQTT_PASS = "${r.password}";\nconst char* SITE_ID = "${r.siteId}";\nconst char* POND_ID = "${r.pondId}";`;
            const mm = openModal(`<h3>Device login created</h3><p class="notice warn" style="margin:12px 0">Copy this now. The password is shown only once.</p>
              <pre class="code-box">${esc(code)}</pre>
              <div class="modal-actions"><button class="btn" id="cdCopy">Copy</button><button class="btn primary" data-x>Done</button></div>`, { onClose: () => render() });
            mm.querySelector('[data-x]').onclick = closeModal;
            $('#cdCopy').onclick = async () => { try { await navigator.clipboard.writeText(code); toast('Copied', 'ok'); } catch (_) { toast('Select the text and copy it by hand', 'err'); } };
          } catch (e) { toast(e.message, 'err'); }
        };
      });
      $$('[data-cred-del]').forEach(b => b.addEventListener('click', async () => {
        if (!await confirmDialog('Delete device login?', `The ESP32 using "${b.dataset.credDel}" will be disconnected and can no longer send data.`)) return;
        try { await api('/devices/credentials/' + encodeURIComponent(b.dataset.credDel), { method: 'DELETE' }); state.creds = null; render(); } catch (e) { toast(e.message, 'err'); }
      }));
    }
    const put = async (body, msg) => {
      try { await api('/settings', { method: 'PUT', body }); await Promise.all([load.info(), load.full()]); toast(msg, 'ok'); render(); }
      catch (e) { toast(e.message, 'err'); }
    };
    $('#poSave')?.addEventListener('click', () => put({ pushover: { appToken: $('#poToken').value, userKey: $('#poUser').value, enabled: $('#poOn').checked }, publicUrl: $('#pubUrl').value.trim() }, 'Phone alert settings saved'));
    const test = async emergency => {
      try { await api('/notify/test', { method: 'POST', body: { emergency } }); toast(emergency ? 'Emergency test sent. Phones ring every 30 s for 1 minute or until acknowledged.' : 'Test sent. Check your phones.', 'ok'); }
      catch (e) { toast(e.message, 'err'); }
      await load.full(); render();
    };
    $('#poTest')?.addEventListener('click', () => test(false));
    $('#poTestE')?.addEventListener('click', () => test(true));
    $('#wdSave')?.addEventListener('click', () => { const u = $('#wdUrl').value.trim(); if (!u) { toast('Paste the ping URL from healthchecks.io first', 'err'); return; } put({ watchdogUrl: u }, 'Watchdog saved'); });
    $('#wdClear')?.addEventListener('click', () => put({ watchdogUrl: '' }, 'Watchdog removed'));
    $('#ilSave')?.addEventListener('click', () => put({ interlock: { blockWhenOffline: $('#ilOff').checked, blockOnCritical: $('#ilCrit').checked, quietStart: $('#ilQs').value, quietEnd: $('#ilQe').value } }, 'Feeding safety saved'));
    $$('[data-vol-save]').forEach(b => b.addEventListener('click', async () => {
      const id = b.dataset.volSave;
      const v = sel => { const el = $(`[${sel}="${id}"]`); return el.value === '' ? null : Number(el.value); };
      try { await api('/ponds/' + encodeURIComponent(id) + '/profile', { method: 'PUT', body: { volumeM3: v('data-vol'), systemVolumeM3: v('data-svol') } }); await load.full(); toast('Water volume saved', 'ok'); render(); }
      catch (e) { toast(e.message, 'err'); }
    }));
    api('/system/events').then(d => {
      const el = $('#busInfo'); if (!el) return;
      const errs = d.events.reduce((a, e) => a + e.errors, 0);
      el.innerHTML = `<div class="row" style="margin-bottom:10px">${errs ? `<span class="chip crit">${errs} module errors since start</span>` : '<span class="chip ok">All modules healthy</span>'}</div>
        <div class="scroll-x"><table class="tbl"><thead><tr><th>Event</th><th>Handled by</th><th>Count</th><th>Errors</th><th>Last</th></tr></thead><tbody>
        ${d.events.filter(e => e.subscribers.length).map(e => `<tr><td><code>${esc(e.name)}</code></td><td class="wrap">${esc(e.subscribers.join(', '))}</td><td>${e.count}</td><td>${e.errors ? `<span class="chip crit">${e.errors}</span>` : '0'}</td><td>${e.last ? rel(e.last) : DASH}</td></tr>`).join('')}
        </tbody></table></div>
        ${d.recentErrors.length ? `<p class="muted small">Latest error: ${esc(d.recentErrors[0].module)} on ${esc(d.recentErrors[0].event)}: ${esc(d.recentErrors[0].error)}</p>` : ''}`;
    }).catch(() => {});
    $('#setSave')?.addEventListener('click', async () => put({ siteName: $('#setSite').value, offlineAfterSec: Math.round(Number($('#setOff').value) * 60) }, 'Settings saved'));
  };

  // ================================================================== v2.1.0 business modules
  const B = state.biz;
  const myr = v => (isNum(v) ? 'RM ' + v.toLocaleString('en-MY', { minimumFractionDigits: 2, maximumFractionDigits: 2 }) : DASH);
  const pend = (v, f, why) => (isNum(v) ? f(v) : `<span class="pending" title="${esc(why)}">${esc(why)}</span>`);
  const kpi = (label, value, sub = '') => `<div class="stat"><div class="muted small">${label}</div><div class="stat-v">${value}</div>${sub ? `<div class="muted small">${sub}</div>` : ''}</div>`;
  const STATUS_CLS = { Draft: 'off', Preparing: 'info', Running: 'ok', Harvesting: 'ok', Completed: 'ok', Failed: 'crit', Cancelled: 'off', pending: 'warn', approved: 'ok', rejected: 'crit', paid: 'ok', unpaid: 'warn', verified: 'ok', unverified: 'warn' };
  const chip = (txt, cls) => `<span class="chip ${cls || STATUS_CLS[txt] || 'off'}">${esc(txt)}</span>`;
  async function bizMeta() { if (!B.meta) B.meta = await api('/poc/meta'); return B.meta; }
  const opts = (list, sel, blank) => (blank !== undefined ? `<option value="">${esc(blank)}</option>` : '') + list.map(o => { const [v, l] = Array.isArray(o) ? o : [o, o]; return `<option value="${esc(v)}" ${v === sel ? 'selected' : ''}>${esc(l)}</option>`; }).join('');
  const val = id => $(id)?.value?.trim() ?? '';
  function needLoad(key, fn) { if (B[key] === null) { B[key] = 'loading'; fn().then(() => { if (!$('#modalRoot').innerHTML) render(); }).catch(e => { B[key] = null; toast(e.message, 'err'); }); return true; } return B[key] === 'loading'; }
  const loadingView = () => '<section class="panel"><div class="empty">Loading…</div></section>';

  // ------------------------------------------------------------------ POC research
  VIEWS.poc = () => {
    if (needLoad('pocs', async () => { await bizMeta(); B.pocs = await api('/poc'); })) return loadingView();
    if (B.pocSel) return pocDetailView();
    const list = B.pocs;
    return `<section class="row"><p class="muted" style="margin:0;max-width:78ch">Each POC is one planned trial with success criteria fixed before it starts. Failed and cancelled POCs stay on record. Numbers come only from linked crop cycles, approved expenses and uploaded evidence.</p><div style="flex:1"></div>
      ${hasPerm('poc.write') ? `<button class="btn primary" id="pocNew">${I('plus')}New POC</button>` : ''}</section>
      ${list.length ? `<section class="cards">${list.map(p => `<article class="panel poc-card" data-poc="${esc(p.id)}" tabindex="0" role="button">
        <div class="row" style="flex-wrap:nowrap"><div style="min-width:0"><div class="muted small">${esc(p.id)} · ${esc(p.siteId)} / ${esc(p.pondId)}</div><h3 class="ellipsis" style="margin:2px 0 0;font-size:17px">${esc(p.name)}</h3></div><div style="flex:1"></div>${chip(p.status)}</div>
        <div class="stat-grid mini" style="margin-top:12px">
          ${kpi('Stocked', isNum(p.summary.stocked) ? p.summary.stocked.toLocaleString() : DASH)}
          ${kpi('Survival', isNum(p.summary.verifiedSurvivalPct) ? p.summary.verifiedSurvivalPct + ' %' : isNum(p.summary.estimatedSurvivalPct) ? p.summary.estimatedSurvivalPct + ' % est.' : DASH)}
          ${kpi('FCR', isNum(p.summary.finalFcr) ? fmt(p.summary.finalFcr) : isNum(p.summary.estimatedFcr) ? fmt(p.summary.estimatedFcr) + ' est.' : DASH)}
        </div>
        <div class="muted small" style="margin-top:10px">${esc(p.startDate || 'Not started')}${p.endDate ? ' to ' + esc(p.endDate) : ''} · ${p.cycleIds.length} cycle(s)</div></article>`).join('')}</section>`
        : `<section class="panel"><div class="empty big"><b>No POC yet</b>Create the first trial, for example "POC-001 Low-salinity RAS density test". Write the success and failure criteria before stocking.</div></section>`}`;
  };
  VIEWS.poc.after = () => {
    $('#pocNew')?.addEventListener('click', () => pocForm(null));
    $$('[data-poc]').forEach(c => { const go = () => { B.pocSel = c.dataset.poc; B.pocDetail = null; render(); }; c.addEventListener('click', go); c.addEventListener('keydown', e => { if (e.key === 'Enter') go(); }); });
    pocDetailAfter();
  };
  function pocDetailView() {
    if (!B.pocDetail || B.pocDetail.id !== B.pocSel) { api('/poc/' + encodeURIComponent(B.pocSel)).then(d => { B.pocDetail = d; render(); }).catch(e => { toast(e.message, 'err'); B.pocSel = null; render(); }); return loadingView(); }
    const p = B.pocDetail, s = p.summary, f = s.finance, M = B.meta;
    const next = (M.pocFlow[p.status] || []);
    const closed = ['Completed', 'Failed', 'Cancelled'].includes(p.status);
    const cyclesHere = state.cycles.filter(c => c.pondId === p.pondId && !p.cycleIds.includes(c.id));
    const field = (label, v) => `<div class="kv-row"><span>${label}</span><div>${v ? esc(v).replace(/\n/g, '<br>') : '<span class="muted">Not written</span>'}</div></div>`;
    return `<section class="row"><button class="btn sm ghost" id="pocBack">← All POCs</button><div style="flex:1"></div>
        ${hasPerm('poc.write') && !closed ? `<button class="btn sm" id="pocEdit">${I('edit')}Edit</button>` : ''}
        ${hasPerm('poc.write') ? next.map(n => `<button class="btn sm ${n === 'Failed' || n === 'Cancelled' ? 'danger' : 'primary'}" data-pstatus="${n}">${n === 'Running' ? 'Start (lock criteria)' : 'Move to ' + n}</button>`).join('') : ''}</section>
      <section class="panel"><div class="row" style="flex-wrap:nowrap"><div style="min-width:0"><div class="muted small">${esc(p.id)} · site ${esc(p.siteId)} · pond ${esc(p.pondId)} · ${esc(p.species)}</div><h2 style="margin:4px 0 0;font-size:22px">${esc(p.name)}</h2></div><div style="flex:1"></div>${chip(p.status)}</div>
        <div class="muted small" style="margin-top:8px">Start ${esc(p.startDate || DASH)} · End ${esc(p.endDate || DASH)} · Responsible ${esc(p.responsible || DASH)} · Created by ${esc(p.createdBy)} ${dateTime(p.createdAt)}</div></section>
      <section class="stat-grid">
        ${kpi('Stocked (PL)', pend(s.stocked, v => v.toLocaleString(), 'No stocking recorded'))}
        ${kpi('Estimated survival', pend(s.estimatedSurvivalPct, v => v + ' %', s.allClosed ? 'Use verified' : 'No data'), 'counted deaths only')}
        ${kpi('Verified survival', pend(s.verifiedSurvivalPct, v => v + ' %', 'Pending validation'), 'counted harvest ÷ stocked')}
        ${kpi('Feed used', isNum(s.feedKg) ? fmt(s.feedKg, 1) + ' kg' : DASH)}
        ${kpi('FCR', isNum(s.finalFcr) ? fmt(s.finalFcr) : pend(s.estimatedFcr, v => fmt(v) + ' est.', 'Pending'), isNum(s.finalFcr) ? 'final, from harvest' : 'estimate until harvest')}
        ${kpi('Harvest', pend(s.harvestKg, v => fmt(v, 1) + ' kg', 'Not harvested'))}
        ${hasPerm('finance.read') && f ? kpi('Operating cost', myr(f.operatingCostMYR), 'approved OPEX') + kpi('Depreciation', myr(f.depreciationMYR), 'CAPEX share in period') + kpi('Cost per kg', pend(f.costPerKgMYR, myr, 'Needs verified harvest')) + kpi('Revenue', pend(f.revenueMYR, myr, 'No sales recorded')) : ''}
      </section>
      <div class="split">
        <section class="panel"><div class="panel-head"><h2>Plan</h2>${p.criteriaLockedAt ? `<span class="chip info">${I('lock')}Criteria locked ${dateTime(p.criteriaLockedAt)}</span>` : '<span class="chip warn">Criteria not locked yet</span>'}</div>
          <div class="kv-list">${field('Objectives', p.objectives)}${field('Hypothesis', p.hypothesis)}${field('Method', p.method)}${field('Success criteria', p.successCriteria)}${field('Failure criteria', p.failureCriteria)}${field('Expected results', p.expectedResults)}${field('Risks', p.risks)}
          ${field('Pond size / volume', [p.pondDimension, isNum(p.waterVolumeM3) ? p.waterVolumeM3 + ' m³' : ''].filter(Boolean).join(' · '))}${field('Stocking density', p.stockingDensity)}${field('PL supplier', p.plSupplier)}</div>
          ${p.criteriaChanges.length ? `<h4 style="margin:14px 0 6px">Changes after start</h4><div class="list">${p.criteriaChanges.map(c => `<div class="list-item"><div class="grow"><div class="title">${esc(c.field)} changed by ${esc(c.by)} · ${dateTime(c.at)}</div><div class="meta">Reason: ${esc(c.reason)}</div><div class="meta">Was: ${esc(c.old)}</div></div></div>`).join('')}</div>` : ''}
        </section>
        <section class="panel"><div class="panel-head"><h2>Data completeness</h2><span class="chip ${s.completeness.score >= 80 ? 'ok' : s.completeness.score >= 50 ? 'warn' : 'crit'}">${isNum(s.completeness.score) ? s.completeness.score + ' %' : DASH}</span></div>
          <div class="list">${s.completeness.items.map(i => `<div class="list-item"><span class="chip ${i.ok ? 'ok' : 'warn'}">${i.ok ? 'Done' : 'Missing'}</span><div class="grow title">${esc(i.label)}</div></div>`).join('')}</div>
          <div class="panel-head" style="margin-top:16px"><h2>Linked crop cycles</h2></div>
          ${s.cycleDetails.length ? `<div class="list">${s.cycleDetails.map(c => `<div class="list-item"><div class="grow"><div class="title">${esc(c.id)} · stocked ${esc(c.startDate)}</div><div class="meta">${c.status === 'closed' ? 'closed ' + esc(c.endDate || '') : 'running, day ' + c.summary.doc} · feed ${fmt(c.summary.feedKg, 1)} kg</div></div>${hasPerm('poc.write') && !['Completed', 'Failed'].includes(p.status) ? `<button class="btn sm ghost" data-unlink="${esc(c.id)}">Unlink</button>` : ''}</div>`).join('')}</div>` : '<div class="empty">No crop cycle linked. Start one on the Crop cycle page, then link it here.</div>'}
          ${hasPerm('poc.write') && !closed && cyclesHere.length ? `<div class="row" style="margin-top:10px;flex-wrap:nowrap"><select id="pocLinkSel">${opts(cyclesHere.map(c => [c.id, c.id + ' (' + c.startDate + ', ' + c.status + ')']))}</select><button class="btn sm" id="pocLink">Link cycle</button></div>` : ''}
          <p class="muted small">Evidence linked: ${s.evidenceCount} · <a href="#/evidence" data-evpoc="${esc(p.id)}">open in Evidence vault</a>${hasPerm('finance.read') ? ` · <a href="#/finance" data-finpoc="${esc(p.id)}">expenses</a>` : ''}</p>
        </section>
      </div>
      <section class="panel"><div class="panel-head"><h2>Reviews and status history</h2><div class="spacer"></div>${hasPerm('poc.review') ? '<button class="btn sm" id="pocReview">Add review</button>' : ''}</div>
        <div class="list">${[...p.reviews.map(r => ({ at: r.at, html: `${chip(r.decision.replace('_', ' '), r.decision === 'approved' ? 'ok' : r.decision === 'comment' ? 'info' : 'warn')}<div class="grow"><div class="title">${esc(r.note || 'Approved')}</div><div class="meta">${esc(r.by)} (${esc(r.role)}) · ${dateTime(r.at)} · while ${esc(r.statusAtReview)}</div></div>` })),
          ...p.statusHistory.map(h => ({ at: h.at, html: `${chip(h.to)}<div class="grow"><div class="title">${esc(h.from)} → ${esc(h.to)}${h.note ? ': ' + esc(h.note) : ''}</div><div class="meta">${esc(h.by)} · ${dateTime(h.at)}</div></div>` }))]
          .sort((a, b) => b.at.localeCompare(a.at)).map(x => `<div class="list-item">${x.html}</div>`).join('') || '<div class="empty">No reviews yet.</div>'}</div></section>`;
  }
  function pocDetailAfter() {
    if (!B.pocSel || !B.pocDetail) return;
    const p = B.pocDetail;
    const reload = async () => { B.pocDetail = await api('/poc/' + encodeURIComponent(p.id)); B.pocs = null; render(); };
    $('#pocBack')?.addEventListener('click', () => { B.pocSel = null; B.pocDetail = null; render(); });
    $('#pocEdit')?.addEventListener('click', () => pocForm(p));
    $$('[data-pstatus]').forEach(b => b.addEventListener('click', () => {
      const to = b.dataset.pstatus, needNote = to === 'Failed' || to === 'Cancelled';
      const m = openModal(`<h3>${to === 'Running' ? 'Start this POC' : 'Move to ' + esc(to)}</h3>
        <p class="muted small">${to === 'Running' ? 'Starting locks the hypothesis, expected results and success / failure criteria. Later changes need a written reason and stay visible.' : needNote ? 'The reason stays on the record. The POC is not hidden.' : ''}</p>
        <label class="field">Note${needNote ? ' (required)' : ''}<textarea id="psNote" maxlength="1000"></textarea></label>
        <div class="modal-actions"><button class="btn" data-x>Cancel</button><button class="btn primary" id="psGo">Confirm</button></div>`);
      m.querySelector('[data-x]').onclick = closeModal;
      $('#psGo').onclick = async () => { try { await api(`/poc/${p.id}/status`, { method: 'POST', body: { status: to, note: val('#psNote') } }); closeModal(); toast('Status updated', 'ok'); await reload(); } catch (e) { toast(e.message, 'err'); } };
    }));
    $('#pocLink')?.addEventListener('click', async () => { try { await api(`/poc/${p.id}/cycles`, { method: 'POST', body: { cycleId: val('#pocLinkSel') } }); toast('Cycle linked', 'ok'); await reload(); } catch (e) { toast(e.message, 'err'); } });
    $$('[data-unlink]').forEach(b => b.addEventListener('click', async () => { if (!await confirmDialog('Unlink this cycle?', 'Its data will no longer count in this POC.', 'Unlink')) return; try { await api(`/poc/${p.id}/cycles/${b.dataset.unlink}`, { method: 'DELETE' }); await reload(); } catch (e) { toast(e.message, 'err'); } }));
    $$('[data-evpoc]').forEach(a => a.addEventListener('click', () => { B.evFilter = { linkType: 'poc', linkId: a.dataset.evpoc }; B.evidence = null; }));
    $$('[data-finpoc]').forEach(a => a.addEventListener('click', () => { B.finFilter = { pocId: a.dataset.finpoc }; B.expenses = null; }));
    $('#pocReview')?.addEventListener('click', () => {
      const m = openModal(`<h3>Review ${esc(p.id)}</h3><div class="form-grid" style="margin-top:12px">
        <label class="field">Decision<select id="rvDec"><option value="comment">Comment</option><option value="approved">Approve plan / result</option><option value="changes_requested">Changes requested</option></select></label>
        <label class="field full">Comment<textarea id="rvNote" maxlength="2000"></textarea></label></div>
        <div class="modal-actions"><button class="btn" data-x>Cancel</button><button class="btn primary" id="rvGo">Save review</button></div>`);
      m.querySelector('[data-x]').onclick = closeModal;
      $('#rvGo').onclick = async () => { try { await api(`/poc/${p.id}/reviews`, { method: 'POST', body: { decision: val('#rvDec'), note: val('#rvNote') } }); closeModal(); await reload(); } catch (e) { toast(e.message, 'err'); } };
    });
  }
  function pocForm(p) {
    const locked = !!p?.criteriaLockedAt;
    const ta = (id, label, v, hint = '') => `<label class="field full">${label}${hint ? `<small>${hint}</small>` : ''}<textarea data-pf="${id}" maxlength="4000">${esc(v || '')}</textarea></label>`;
    const tx = (id, label, v, hint = '') => `<label class="field">${label}${hint ? `<small>${hint}</small>` : ''}<input type="text" data-pf="${id}" value="${esc(v || '')}" maxlength="${id === 'name' ? 120 : 400}"></label>`;
    const m = openModal(`<h3>${p ? 'Edit ' + esc(p.id) : 'New POC'}</h3>
      ${locked ? '<p class="notice warn">This POC has started. Changes to the hypothesis, expected results or criteria need a reason and stay in the history.</p>' : ''}
      <div class="form-grid" style="margin-top:12px">
        ${tx('name', 'Project name', p?.name)}
        <label class="field">Pond<span id="pfPond">${pondOptions(p?.pondId || selectedPond()?.id || '')}</span></label>
        <label class="field">Planned start<input type="date" data-pf="startDate" value="${esc(p?.startDate || '')}"></label>
        <label class="field">Planned end<input type="date" data-pf="endDate" value="${esc(p?.endDate || '')}"></label>
        ${tx('responsible', 'Responsible person', p?.responsible)}${tx('plSupplier', 'PL supplier', p?.plSupplier)}
        ${tx('pondDimension', 'Pond dimension', p?.pondDimension, 'e.g. 3 m × 2 m × 1.2 m')}
        <label class="field">Water volume (m³)<input type="number" step="0.1" min="0" data-pf="waterVolumeM3" value="${esc(p?.waterVolumeM3 ?? '')}"></label>
        ${tx('stockingDensity', 'Stocking density', p?.stockingDensity, 'e.g. 300 PL/m³')}${tx('species', 'Species', p?.species || 'Pacific white shrimp (Litopenaeus vannamei)')}
        ${ta('objectives', 'Objectives', p?.objectives)}${ta('hypothesis', 'Hypothesis', p?.hypothesis)}${ta('method', 'Experiment method', p?.method)}
        ${ta('successCriteria', 'Success criteria', p?.successCriteria, 'Measurable, e.g. "verified survival ≥ 70 % and FCR ≤ 1.4"')}
        ${ta('failureCriteria', 'Failure criteria', p?.failureCriteria, 'e.g. "verified survival < 50 % or two oxygen incidents"')}
        ${ta('expectedResults', 'Expected results', p?.expectedResults)}${ta('risks', 'Risks', p?.risks)}
        ${locked ? '<label class="field full">Reason for change<input type="text" id="pfReason" maxlength="500"></label>' : ''}
      </div>
      <div class="modal-actions"><button class="btn" data-x>Cancel</button><button class="btn primary" id="pfSave">${p ? 'Save changes' : 'Create POC'}</button></div>`, { wide: true });
    m.querySelector('[data-x]').onclick = closeModal;
    $('#pfSave').onclick = async () => {
      const body = { pondId: $('#pfPond input').value.trim() };
      m.querySelectorAll('[data-pf]').forEach(i => { body[i.dataset.pf] = i.value; });
      if (locked) body.reason = val('#pfReason');
      try {
        const r = await api(p ? '/poc/' + p.id : '/poc', { method: p ? 'PUT' : 'POST', body });
        closeModal(); toast(p ? 'Saved' : `${r.id} created`, 'ok'); B.pocs = null; B.pocSel = r.id; B.pocDetail = null; render();
      } catch (e) { toast(e.message, 'err'); }
    };
  }

  // ------------------------------------------------------------------ Finance
  const finQuery = () => new URLSearchParams(Object.entries(B.finFilter).filter(([, v]) => v)).toString();
  VIEWS.finance = () => {
    if (needLoad('expenses', async () => { await bizMeta(); if (!B.pocs) B.pocs = await api('/poc'); B.expenses = await api('/finance/expenses?' + finQuery()); B.fin = await api('/finance/summary?' + new URLSearchParams(Object.entries({ pocId: B.finFilter.pocId, from: B.finFilter.from, to: B.finFilter.to }).filter(([, v]) => v))); })) return loadingView();
    const M = B.meta, f = B.fin, F = B.finFilter, list = B.expenses;
    if (B.inbox === null) { B.inbox = 'loading'; api('/finance/inbox').then(x => { B.inbox = x; if (route() === 'finance' && !$('#modalRoot').innerHTML) render(); }).catch(() => { B.inbox = []; }); }
    const nat = { OPEX: 'OPEX', CAPEX: 'CAPEX', DEPOSIT: 'Deposit', LOAN: 'Loan', EQUITY: 'Equity' };
    return `${inboxPanel()}<section class="stat-grid">
        ${kpi('Operating cost', myr(f.operatingCostMYR), 'approved OPEX')}${kpi('CAPEX', myr(f.capexMYR), 'not expensed at once')}
        ${kpi('Depreciation', myr(f.depreciationMYR), f.capexWithoutUsefulLife.length ? f.capexWithoutUsefulLife.length + ' item(s) without useful life' : 'straight-line')}
        ${kpi('Deposits', myr(f.depositsMYR), 'refundable, not a cost')}${kpi('Funding received', myr(f.fundingReceivedMYR), 'loans + equity')}
        ${kpi('Unpaid', myr(f.unpaidMYR), 'approved, not paid')}${kpi('Awaiting approval', myr(f.pendingMYR), f.pendingCount + ' expense(s)')}
        ${kpi('Without receipt', f.approvedWithoutEvidence, 'approved expenses')}
        ${kpi('Cost per kg', pend(f.costPerKgMYR, myr, 'Needs verified harvest'))}${kpi('Revenue / profit', pend(f.revenueMYR, myr, 'Sales module v2.1.1'))}
      </section>
      <section class="panel"><div class="row filters">
        <select id="ffPoc" aria-label="POC">${opts((B.pocs || []).map(p => [p.id, p.id + ' ' + p.name]), F.pocId, 'All POCs')}</select>
        <select id="ffNature" aria-label="Type">${opts(Object.entries(nat), F.nature, 'All types')}</select>
        <select id="ffStatus" aria-label="Status">${opts([['pending', 'Awaiting approval'], ['approved', 'Approved'], ['rejected', 'Rejected'], ['void', 'Voided']], F.status, 'Any status')}</select>
        <input type="date" id="ffFrom" value="${esc(F.from || '')}" aria-label="From"><input type="date" id="ffTo" value="${esc(F.to || '')}" aria-label="To">
        <input type="text" id="ffQ" value="${esc(F.q || '')}" placeholder="Search vendor, description, invoice…">
        <button class="btn sm" id="ffGo">Apply</button><div style="flex:1"></div>
        <a class="btn sm" href="/api/finance/expenses.csv?${esc(finQuery())}">${I('download')}CSV</a>
        ${hasPerm('finance.write') ? `<button class="btn sm" data-scan>${I('camera')}Scan receipts</button><button class="btn sm primary" id="expNew">${I('plus')}New expense</button>` : ''}</div>
      ${list.length ? `<div class="scroll-x table-wrap"><table class="tbl"><thead><tr><th>Date</th><th>ID</th><th>Vendor / description</th><th>Category</th><th>Type</th><th style="text-align:right">Amount</th><th style="text-align:right">MYR</th><th>Status</th><th>Payment</th><th>Receipt</th></tr></thead><tbody>
        ${list.map(e => `<tr class="click ${e.voided ? 'voided' : ''}" data-exp="${esc(e.id)}"><td>${esc(e.transactionDate)}</td><td class="small">${esc(e.id)}</td><td class="wrap"><b>${esc(e.vendor)}</b><div class="muted small">${esc(e.description)}</div></td><td class="small">${esc(e.category || DASH)}</td><td>${esc(nat[e.nature])}</td>
          <td style="text-align:right">${e.currency !== 'MYR' ? esc(e.currency) + ' ' + fmt(e.amount, 2) : DASH}</td><td style="text-align:right"><b>${myr(e.amountMYR)}</b></td>
          <td>${e.voided ? chip('void', 'off') : chip(e.status)}${e.selfApproved ? ' <span class="muted small" title="Approved by the person who entered it">self</span>' : ''}</td><td>${chip(e.paymentStatus)}</td><td>${e.evidenceIds.length ? chip(e.evidenceIds.length + ' file', 'ok') : chip('none', 'warn')}</td></tr>`).join('')}
      </tbody></table></div>` : '<div class="empty big"><b>No expenses yet</b>Record every payment with its receipt. Deposits, loans and equity contributions have their own types so they are never counted as costs.</div>'}</section>
      <section class="panel"><div class="panel-head"><h2>How the numbers are calculated</h2></div><ul class="muted small notes">${f.notes.map(n => `<li>${esc(n)}</li>`).join('')}</ul></section>`;
  };
  VIEWS.finance.after = () => {
    if (B.expenses === 'loading' || B.expenses === null) return;
    $('#ffGo')?.addEventListener('click', () => { B.finFilter = { pocId: val('#ffPoc'), nature: val('#ffNature'), status: val('#ffStatus'), from: val('#ffFrom'), to: val('#ffTo'), q: val('#ffQ') }; B.expenses = null; render(); });
    $('#ffQ')?.addEventListener('keydown', e => { if (e.key === 'Enter') $('#ffGo').click(); });
    $('#expNew')?.addEventListener('click', () => expenseForm(null));
    inboxAfter();
    $$('[data-exp]').forEach(r => r.addEventListener('click', () => expenseDetail(B.expenses.find(e => e.id === r.dataset.exp))));
  };
  // ------------------------------------------------------------------ expense form (manual, edit, or from a scanned receipt)
  function expenseForm(e, seed) {
    const M = B.meta;
    const v = e || seed?.values || {};
    const cf = seed?.conf || {};
    const cls = k => (cf[k] === 'low' ? 'conf-low' : cf[k] === 'hint' ? 'conf-hint' : '');
    const tip = k => (cf[k] === 'low' ? ' title="Not sure: check against the receipt"' : cf[k] === 'hint' ? ' title="Filled from earlier expenses with this vendor"' : '');
    const amt = isNum(v.amount) ? v.amount.toFixed(2) : (v.amount || '');
    const preview = seed?.evidence ? receiptPreview(seed.evidence) : '';
    const banner = seed ? `${(seed.warnings || []).map(w => `<p class="notice warn" style="margin:0 0 8px">${esc(w)}</p>`).join('')}
        ${seed.hint ? `<p class="notice" style="margin:0 0 8px">Category, type and funding filled from ${seed.hint.matches} earlier expense(s) with <b>${esc(seed.hint.vendor)}</b> (blue fields).</p>` : ''}
        <p class="muted small" style="margin:0 0 10px">Yellow fields were hard to read. Check every amount against the receipt before saving: nothing is recorded until you press Record expense.</p>` : '';
    const form = `<div class="form-grid">
        <label class="field ${cls('transactionDate')}"${tip('transactionDate')}>Transaction date<input type="date" id="xDate" value="${esc(v.transactionDate || new Date().toISOString().slice(0, 10))}"></label>
        <label class="field ${cls('nature')}"${tip('nature')}>Type<select id="xNature">${opts(Object.entries(M.natures), v.nature || 'OPEX')}</select></label>
        <label class="field ${cls('category')}"${tip('category')}>Category<select id="xCat">${opts(M.categories, v.category || '', 'Choose…')}</select></label>
        <label class="field ${cls('vendor')}"${tip('vendor')}>Vendor<input type="text" id="xVendor" maxlength="120" value="${esc(v.vendor || '')}"></label>
        <label class="field full ${cls('description')}"${tip('description')}>Description<input type="text" id="xDesc" maxlength="1000" value="${esc(v.description || '')}"></label>
        <label class="field ${cls('amount')}"${tip('amount')}>Amount (total paid)<input type="text" inputmode="decimal" id="xAmt" value="${esc(amt)}" placeholder="0.00"></label>
        <label class="field ${cls('currency')}"${tip('currency')}>Currency<select id="xCur">${opts(M.currencies, v.currency || 'MYR')}</select></label>
        <label class="field fx">Exchange rate to MYR<small>Actual rate from the bank statement or receipt</small><input type="text" inputmode="decimal" id="xRate" value="${esc(v.currency && v.currency !== 'MYR' && v.exchangeRate !== '1' ? v.exchangeRate || '' : '')}"></label>
        <label class="field fx">Rate source<input type="text" id="xRateSrc" maxlength="200" value="${esc(v.currency && v.currency !== 'MYR' && v.rateSource !== 'MYR (no conversion)' ? v.rateSource || '' : '')}" placeholder="e.g. Maybank statement 12 Nov"></label>
        <label class="field ${cls('fundingSource')}"${tip('fundingSource')}>Funding source<select id="xFund">${opts(Object.entries(M.funding), v.fundingSource || 'founder_personal')}</select></label>
        <label class="field">Paid by<input type="text" id="xPaidBy" maxlength="80" value="${esc(v.paidBy || '')}"></label>
        <label class="field ${cls('paymentMethod')}"${tip('paymentMethod')}>Payment method<select id="xPay">${opts(M.paymentMethods.map(x => [x, x.replace('_', ' ')]), v.paymentMethod || 'bank_transfer')}</select></label>
        <label class="field ${cls('invoiceRef')}"${tip('invoiceRef')}>Invoice / receipt no.<input type="text" id="xInv" maxlength="80" value="${esc(v.invoiceRef || '')}"></label>
        <label class="field">POC<select id="xPoc">${opts((B.pocs || []).map(p => [p.id, p.id + ' ' + p.name]), v.pocId || B.finFilter.pocId || '', 'Not linked')}</select></label>
        <label class="field">Crop cycle<select id="xCyc">${opts(state.cycles.map(c => [c.id, c.id + ' (' + c.pondId + ')']), v.cycleId || '', 'Not linked')}</select></label>
        <label class="field capex">Useful life (months)<small>For depreciation. Leave empty if unknown.</small><input type="number" min="1" max="600" id="xLife" value="${esc(v.usefulLifeMonths ?? '')}"></label>
        <label class="field capex">In service from<input type="date" id="xInSvc" value="${esc(v.inServiceDate || '')}"></label>
        ${e ? '' : `<div class="row full"><label class="switch"><input type="checkbox" id="xPaid" ${v.paid === false ? '' : 'checked'}><span></span></label><span>Already paid</span></div>`}
        <label class="field full">Notes<textarea id="xNotes" maxlength="2000">${esc(v.notes || '')}</textarea></label>
        ${e && e.status !== 'pending' ? '<label class="field full">Reason for change (required)<input type="text" id="xReason" maxlength="500"></label>' : ''}
      </div>`;
    const m = openModal(`<h3>${e ? 'Edit ' + esc(e.id) : seed ? 'Check scanned receipt' : 'New expense'}</h3>
      ${e && e.status !== 'pending' ? '<p class="notice warn">This expense is already reviewed. Changing the amount withdraws the approval. A reason is required and kept in the audit trail.</p>' : ''}
      ${seed ? `<div class="rc-grid" style="margin-top:12px"><div class="rc-preview">${preview}</div><div>${banner}${form}</div></div>` : `<div style="margin-top:12px">${form}</div>`}
      <div class="modal-actions"><button class="btn" data-x>Cancel</button><button class="btn primary" id="xSave">${e ? 'Save changes' : 'Record expense'}</button></div>`, { wide: true });
    if (seed) m.classList.add('xwide');
    const sync = () => { const fx = val('#xCur') !== 'MYR', cap = val('#xNature') === 'CAPEX'; m.querySelectorAll('.fx').forEach(x => { x.style.display = fx ? '' : 'none'; }); m.querySelectorAll('.capex').forEach(x => { x.style.display = cap ? '' : 'none'; }); };
    sync(); $('#xCur').onchange = sync; $('#xNature').onchange = sync;
    m.querySelectorAll('.conf-low input, .conf-low select, .conf-hint input, .conf-hint select').forEach(i => i.addEventListener('input', () => i.closest('label').classList.remove('conf-low', 'conf-hint')));
    m.querySelector('[data-x]').onclick = closeModal;
    const send = async confirmDuplicate => {
      const body = { transactionDate: val('#xDate'), nature: val('#xNature'), category: val('#xCat'), vendor: val('#xVendor'), description: val('#xDesc'), amount: val('#xAmt'), currency: val('#xCur'),
        exchangeRate: val('#xRate'), rateSource: val('#xRateSrc'), fundingSource: val('#xFund'), paidBy: val('#xPaidBy'), paymentMethod: val('#xPay'), invoiceRef: val('#xInv'),
        pocId: val('#xPoc'), cycleId: val('#xCyc'), usefulLifeMonths: val('#xLife'), inServiceDate: val('#xInSvc'), notes: val('#xNotes'), confirmDuplicate };
      if (!e) body.paid = $('#xPaid').checked;
      if ($('#xReason')) body.reason = val('#xReason');
      if (seed?.evidence) body.fromEvidenceId = seed.evidence.id;
      try {
        const r = await api(e ? '/finance/expenses/' + e.id : '/finance/expenses', { method: e ? 'PUT' : 'POST', body });
        closeModal(); toast(e ? 'Saved' : seed ? `${r.id} recorded with its receipt attached` : `${r.id} recorded. Attach the receipt next.`, 'ok');
        B.expenses = null; B.inbox = null; render();
        if (seed && seed.next) setTimeout(seed.next, 300);
      } catch (err) {
        if (err.status === 409 && err.data?.duplicates) {
          const ok = await confirmDialog('Possible duplicate', 'Already recorded: ' + err.data.duplicates.map(d => `${d.id} ${d.transactionDate} ${d.vendor} ${d.currency} ${d.amount}${d.invoiceRef ? ' (' + d.invoiceRef + ')' : ''}`).join('; ') + '. Record this one anyway?', 'Record anyway', false);
          if (ok) { expenseForm(e, seed ? { ...seed, values: { ...v, ...collect() } } : null); setTimeout(() => send(true), 50); }
        } else toast(err.message, 'err');
      }
    };
    const collect = () => ({ transactionDate: val('#xDate'), nature: val('#xNature'), category: val('#xCat'), vendor: val('#xVendor'), description: val('#xDesc'), amount: val('#xAmt'), currency: val('#xCur'),
      exchangeRate: val('#xRate'), rateSource: val('#xRateSrc'), fundingSource: val('#xFund'), paidBy: val('#xPaidBy'), paymentMethod: val('#xPay'), invoiceRef: val('#xInv'), pocId: val('#xPoc'), cycleId: val('#xCyc'), notes: val('#xNotes') });
    $('#xSave').onclick = () => send(false);
  }

  // ------------------------------------------------------------------ receipt scanning (runs in this browser, free, nothing leaves the device)
  const OCR = { worker: null, langs: null };
  function loadScript(src) {
    if (document.querySelector(`script[src="${src}"]`)) return Promise.resolve();
    return new Promise((res, rej) => { const s = document.createElement('script'); s.src = src; s.onload = res; s.onerror = () => rej(new Error('Could not load the receipt reader')); document.head.appendChild(s); });
  }
  async function ocrWorker(langs, onProgress) {
    await loadScript('/vendor/ocr/tesseract.min.js');
    OCR.progress = onProgress;
    if (OCR.worker && OCR.langs === langs) return OCR.worker;
    if (OCR.worker) { try { await OCR.worker.terminate(); } catch (_) {} OCR.worker = null; }
    OCR.worker = await window.Tesseract.createWorker(langs.split('+'), 1, {
      workerPath: '/vendor/ocr/worker.min.js', corePath: '/vendor/ocr/core', langPath: '/vendor/ocr/lang', gzip: true, workerBlobURL: false,
      logger: m => OCR.progress && OCR.progress(m)
    });
    OCR.langs = langs;
    return OCR.worker;
  }
  async function imageToCanvas(source) {
    let bmp;
    try { bmp = await createImageBitmap(source); }
    catch (_) { throw new Error('This browser cannot open this image type (HEIC?). The file is saved; type the details by hand.'); }
    const longest = Math.max(bmp.width, bmp.height);
    // small text (desktop screenshots) reads better enlarged; very large photos are reduced
    const scale = Math.min(2, longest > 2600 ? 2600 / longest : 2600 / longest);
    const c = document.createElement('canvas');
    c.width = Math.round(bmp.width * scale); c.height = Math.round(bmp.height * scale);
    const g = c.getContext('2d', { willReadFrequently: true });
    g.drawImage(bmp, 0, 0, c.width, c.height);
    // grayscale + contrast stretch: helps faded thermal receipts
    const img = g.getImageData(0, 0, c.width, c.height), d = img.data, hist = new Uint32Array(256);
    for (let i = 0; i < d.length; i += 4) { const y = (d[i] * 299 + d[i + 1] * 587 + d[i + 2] * 114) / 1000 | 0; d[i] = d[i + 1] = d[i + 2] = y; hist[y]++; }
    const n = d.length / 4; let lo = 0, hi = 255, acc = 0;
    for (; lo < 255 && (acc += hist[lo]) < n * 0.01; lo++);
    acc = 0; for (; hi > 0 && (acc += hist[hi]) < n * 0.01; hi--);
    if (hi - lo > 20) for (let i = 0; i < d.length; i += 4) { const y = Math.max(0, Math.min(255, (d[i] - lo) * 255 / (hi - lo))); d[i] = d[i + 1] = d[i + 2] = y; }
    g.putImageData(img, 0, 0);
    return c;
  }
  async function pdfToText(file) {
    await loadScript('/vendor/pdf/pdf.min.js');
    window.pdfjsLib.GlobalWorkerOptions.workerSrc = '/vendor/pdf/pdf.worker.min.js';
    const doc = await window.pdfjsLib.getDocument({ data: new Uint8Array(await file.arrayBuffer()), isEvalSupported: false, disableFontFace: true }).promise;
    let text = '';
    for (let p = 1; p <= Math.min(doc.numPages, 5); p++) {
      const page = await doc.getPage(p);
      const tc = await page.getTextContent();
      const rows = [];
      for (const it of tc.items) {
        if (!it.str || !it.str.trim()) continue;
        const y = it.transform[5], x = it.transform[4];
        let row = rows.find(r => Math.abs(r.y - y) < 3);
        if (!row) rows.push(row = { y, parts: [] });
        row.parts.push({ x, s: it.str });
      }
      text += rows.sort((a, b) => b.y - a.y).map(r => r.parts.sort((a, b) => a.x - b.x).map(q => q.s).join(' ')).join('\n') + '\n';
    }
    return { text, doc };
  }
  async function readReceipt(file, langs, onProgress) {
    const t0 = performance.now();
    if (file.type === 'application/pdf' || /\.pdf$/i.test(file.name)) {
      const { text, doc } = await pdfToText(file);
      if (text.replace(/\s/g, '').length >= 30) return { engine: 'pdf-text', engineVersion: 'pdf.js ' + (window.pdfjsLib.version || ''), rawText: text, meanConfidence: 100, durationMs: Math.round(performance.now() - t0) };
      // scanned PDF: draw page 1 and read it like a photo
      const page = await doc.getPage(1), vp = page.getViewport({ scale: 2 });
      const c = document.createElement('canvas'); c.width = vp.width; c.height = vp.height;
      await page.render({ canvasContext: c.getContext('2d'), viewport: vp }).promise;
      const w = await ocrWorker(langs, onProgress);
      const r = await w.recognize(await imageToCanvas(c));
      return { engine: 'tesseract.js', engineVersion: '5', rawText: r.data.text, meanConfidence: r.data.confidence, durationMs: Math.round(performance.now() - t0) };
    }
    const canvas = await imageToCanvas(file);
    let w = await ocrWorker(langs, onProgress);
    let r = await w.recognize(canvas);
    let used = langs;
    // English-only reading of a Chinese screenshot (Taobao, Chinese shop receipts) gives low quality: read again with Chinese
    const looksChinese = /[\u4e00-\u9fff]/.test(r.data.text) || /(taobao|tmall|alipay)/i.test(r.data.text);
    if (langs === 'eng' && (r.data.confidence < 80 || looksChinese)) {
      onProgress && onProgress({ status: 'reading again with Chinese' });
      w = await ocrWorker('eng+chi_sim', onProgress);
      const r2 = await w.recognize(canvas);
      // keep the reading that found more amounts and receipt words, not just the higher confidence score
      const useful = t => (t.match(/(?:RM|MYR|[¥￥]|S\$|USD)\s?-?\d/gi) || []).length + 2 * (t.match(/(total|jumlah|order|pesanan|订单|訂單|实付|實付|合计|总额|總額|总价|小计|运费)/gi) || []).length;
      const score = x => useful(x.data.text) + x.data.confidence / 10;
      if (score(r2) >= score(r)) { r = r2; used = 'eng+chi_sim'; }
    }
    return { engine: 'tesseract.js', engineVersion: '5', rawText: r.data.text, meanConfidence: r.data.confidence, durationMs: Math.round(performance.now() - t0), languages: used };
  }
  async function uploadEvidenceFile(file, meta) {
    const bytes = new Uint8Array(await file.arrayBuffer());
    const metaB64 = btoa(String.fromCharCode(...new TextEncoder().encode(JSON.stringify(meta))));
    const res = await fetch('/api/evidence', { method: 'POST', headers: { 'X-AQUA': '1', 'Content-Type': 'application/octet-stream', 'X-Evidence-Meta': metaB64 }, body: bytes });
    const d = await res.json().catch(() => ({}));
    if (!res.ok) throw new Error(d.error || 'Upload failed');
    return d;
  }
  function scanReceipts() {
    const m = openModal(`<h3>Scan receipts</h3>
      <p class="muted small">Photos, screenshots (Shopee, Lazada) and PDF e-invoices. Reading happens in this browser: the receipt is stored in your Evidence vault and is not sent to any other service. The first scan downloads the reader (about 7 MB, once).</p>
      <div class="row" style="margin:12px 0;gap:10px">
        <label class="btn primary">${I('camera')}Take photo<input type="file" id="scCam" accept="image/*" capture="environment" hidden></label>
        <label class="btn">${I('plus')}Choose files<input type="file" id="scFiles" accept="image/*,.pdf,application/pdf" multiple hidden></label>
      </div>
      <div class="form-grid">
        <label class="field">Text on the receipts<small>Taobao and Chinese receipts: English + Chinese. If you forget, AQUA reads again with Chinese when needed.</small><select id="scLang"><option value="eng">English / Malay (Shopee, Lazada, local shops)</option><option value="eng+chi_sim">English + Chinese (Taobao, Chinese receipts)</option><option value="eng+msa">English + Malay (slower, more accurate for Malay)</option></select></label>
        <div class="row full"><label class="switch"><input type="checkbox" id="scOne"><span></span></label><span>All chosen files are <b>one</b> receipt (a long page in several screenshots)</span></div>
        <label class="field">Link to POC (optional)<select id="scPoc">${opts((B.pocs || []).map(p => [p.id, p.id + ' ' + p.name]), '', 'Not linked')}</select></label>
      </div>
      <div id="scList" class="list" style="margin-top:12px"></div>
      <div class="modal-actions"><button class="btn" data-x>Close</button><button class="btn primary" id="scGo" disabled>Read receipts</button></div>`, { wide: true });
    let files = [];
    const list = $('#scList');
    try { const last = localStorage.getItem('aqua.scanLang'); if (last) $('#scLang').value = last; } catch (_) {}
    $('#scLang').onchange = () => { try { localStorage.setItem('aqua.scanLang', val('#scLang')); } catch (_) {} };
    const addFiles = fl => { files = files.concat([...fl]); list.innerHTML = files.map((f, i) => `<div class="list-item" data-sc="${i}"><span class="chip off">waiting</span><div class="grow"><div class="title">${esc(f.name)}</div><div class="meta">${(f.size / 1024 / 1024).toFixed(1)} MB</div></div></div>`).join(''); $('#scGo').disabled = !files.length; };
    $('#scCam').onchange = e => addFiles(e.target.files);
    $('#scFiles').onchange = e => addFiles(e.target.files);
    m.querySelector('[data-x]').onclick = closeModal;
    $('#scGo').onclick = async () => {
      $('#scGo').disabled = true;
      const langs = val('#scLang'), poc = val('#scPoc'), one = $('#scOne').checked;
      let ok = 0; const doneIds = [];
      for (let i = 0; i < files.length; i++) {
        const row = list.querySelector(`[data-sc="${i}"]`), st = (t, c) => { row.querySelector('.chip').className = 'chip ' + c; row.querySelector('.chip').textContent = t; };
        const meta = row.querySelector('.meta');
        try {
          st('uploading', 'info');
          const ev = await uploadEvidenceFile(files[i], { type: 'receipt', title: files[i].name.replace(/\.[^.]+$/, ''), originalName: files[i].name, confidential: true, links: poc ? [{ type: 'poc', id: poc }] : [] });
          st('reading', 'info');
          try {
            const r = await readReceipt(files[i], langs, p => { if (p.status) meta.textContent = p.status + (p.progress ? ' ' + Math.round(p.progress * 100) + ' %' : ''); });
            const saved = await api(`/evidence/${ev.id}/extraction`, { method: 'PUT', body: { ...r, languages: r.languages || langs } });
            const f = saved.extraction.parsed.fields;
            doneIds.push(ev.id);
            meta.textContent = saved.mergedInto ? `${ev.id} · same order as ${saved.mergedInto}: combined into one receipt` : `${ev.id} · ${f.vendor || 'vendor ?'} · ${f.total !== undefined ? (f.currency || 'MYR') + ' ' + f.total.toFixed(2) : 'total ?'} · ${f.date || 'date ?'} · read ${Math.round(saved.extraction.meanConfidence ?? 0)} %`;
            st(saved.extraction.parsed.warnings.length ? 'check' : 'read', saved.extraction.parsed.warnings.length ? 'warn' : 'ok');
          } catch (err) { meta.textContent = `${ev.id} saved. ${err.message}`; st('saved, type by hand', 'warn'); }
          ok++;
        } catch (err) { meta.textContent = err.message; st('failed', 'crit'); }
      }
      if (one && doneIds.length > 1) {
        try { await api(`/finance/inbox/${doneIds[0]}/combine`, { method: 'POST', body: { ids: doneIds.slice(1) } }); toast(`${doneIds.length} screenshots combined into one receipt`, 'ok'); }
        catch (e) { if (!/at least one other/.test(e.message)) toast(e.message, 'err'); }
      }
      $('#scGo').textContent = 'Done';
      B.inbox = null; B.evidence = null;
      if (hasPerm('finance.read')) {
        const done = $('#scGo'); done.disabled = false; done.textContent = 'Open receipt inbox';
        done.onclick = () => { closeModal(); location.hash = '#/finance'; render(); };
      } else toast(`${ok} receipt(s) sent to the finance inbox`, 'ok');
    };
  }
  function receiptPreview(ev) {
    const files = [{ id: ev.id, mime: ev.current.mime }, ...(ev.partFiles || [])];
    const raw = ev.extraction?.rawText;
    const one = f => { const url = `/api/evidence/${encodeURIComponent(f.id)}/file`; return /^image\/(png|jpeg|webp)$/.test(f.mime) ? `<a href="${url}?inline=1" target="_blank" rel="noopener"><img src="${url}?inline=1" alt="Receipt ${esc(f.id)}"></a>` : `<div class="empty"><a class="btn" href="${url}?inline=1" target="_blank" rel="noopener">${I('external')}Open ${esc(f.id)}</a></div>`; };
    return `<div class="rc-stack">${files.map(one).join('')}</div>${files.length > 1 ? `<div class="muted small" style="margin-top:6px">${files.length} screenshots of one order, read together</div>` : ''}
      <div class="muted small" style="margin-top:6px">${esc(ev.id)} · uploaded by ${esc(ev.uploadedBy)} ${dateTime(ev.uploadedAt)}${ev.extraction ? ` · read by ${esc(ev.extraction.engine)}${isNum(ev.extraction.meanConfidence) ? ', quality ' + Math.round(ev.extraction.meanConfidence) + ' %' : ''}` : ' · not read automatically'}</div>
      ${raw ? `<details style="margin-top:8px"><summary class="small">Text the reader saw</summary><pre class="code-box raw">${esc(raw)}</pre></details>` : ''}`;
  }
  function reviewReceipt(ev, next) {
    const p = ev.extraction?.parsed || { fields: {}, confidence: {}, warnings: ['This receipt was not read automatically. Type the details from the image.'] };
    const f = p.fields, c = p.confidence, h = ev.hint;
    const conf = {};
    const map = { date: 'transactionDate', vendor: 'vendor', total: 'amount', currency: 'currency', invoiceRef: 'invoiceRef', paymentMethod: 'paymentMethod', description: 'description' };
    for (const [k, t] of Object.entries(map)) conf[t] = f[k] === undefined || f[k] === null ? 'low' : c[k] === 'low' ? 'low' : '';
    const notes = [];
    if (isNum(f.subtotal)) notes.push('Subtotal ' + f.subtotal.toFixed(2));
    if (isNum(f.tax)) notes.push('Tax ' + f.tax.toFixed(2));
    if (isNum(f.discount)) notes.push('Discount ' + f.discount.toFixed(2));
    if (isNum(f.shipping)) notes.push('Shipping ' + f.shipping.toFixed(2));
    if (f.vendorRegNo) notes.push('Vendor reg. ' + f.vendorRegNo);
    if (f.lineItems?.length) notes.push('Items: ' + f.lineItems.slice(0, 8).map(x => `${x.description} ${x.amount.toFixed(2)}`).join('; '));
    const values = {
      transactionDate: f.date, vendor: f.vendor || h?.vendor, description: f.description || (f.invoiceRef ? 'Receipt ' + f.invoiceRef : ''), amount: f.total, currency: f.currency || h?.currency || 'MYR',
      invoiceRef: f.invoiceRef, paymentMethod: f.paymentMethod || h?.paymentMethod, nature: h?.nature || 'OPEX', category: h?.category || '', fundingSource: h?.fundingSource || 'founder_personal',
      pocId: ev.links.find(l => l.type === 'poc')?.id || h?.pocId || '', notes: notes.join(' · ')
    };
    if (h) { for (const k of ['nature', 'category', 'fundingSource']) conf[k] = 'hint'; if (!f.paymentMethod && h.paymentMethod) conf.paymentMethod = 'hint'; }
    else conf.category = 'low';
    const warnings = [...(p.warnings || [])];
    if (p.checks?.totals === 'ok' || p.checks?.items === 'ok') warnings.unshift ? null : null;
    expenseForm(null, { evidence: ev, values, conf, hint: h, warnings, next });
  }
  async function dismissReceipt(ev) {
    const m = openModal(`<h3>Not an expense?</h3><p class="muted small">The file stays in the Evidence vault; it is only removed from the inbox.</p><label class="field">Reason (required)<input type="text" id="dsR" maxlength="500" placeholder="e.g. personal purchase, duplicate photo"></label><div class="modal-actions"><button class="btn" data-x>Cancel</button><button class="btn danger" id="dsG">Remove from inbox</button></div>`);
    m.querySelector('[data-x]').onclick = closeModal;
    $('#dsG').onclick = async () => { try { await api(`/finance/inbox/${ev.id}/dismiss`, { method: 'POST', body: { reason: val('#dsR') } }); closeModal(); B.inbox = null; render(); } catch (e) { toast(e.message, 'err'); } };
  }
  function inboxPanel() {
    if (!Array.isArray(B.inbox)) return '';
    const canW = hasPerm('finance.write');
    if (!B.inbox.length) return canW ? `<section class="panel inbox"><div class="panel-head"><h2>Receipt inbox</h2><div class="spacer"></div><button class="btn sm primary" data-scan>${I('camera')}Scan receipts</button></div><div class="empty">No receipts waiting. Scan a receipt and AQUA fills in the expense for you to check.</div></section>` : '';
    const row = ev => {
      const f = ev.extraction?.parsed?.fields || {}, w = ev.extraction?.parsed?.warnings?.length || 0;
      const thumb = /^image\//.test(ev.current.mime) && ev.current.mime !== 'image/heic' ? `<img class="thumb" src="/api/evidence/${encodeURIComponent(ev.id)}/file?inline=1" alt="" loading="lazy">` : `<div class="thumb doc">${esc(ev.current.ext.toUpperCase())}</div>`;
      const n = 1 + (ev.partFiles?.length || 0);
      return `<div class="list-item inbox-item">${canW ? `<input type="checkbox" class="ib-sel" data-sel="${esc(ev.id)}" aria-label="Select ${esc(ev.id)}">` : ''}${thumb}<div class="grow"><div class="title">${esc(f.vendor || ev.title)}${n > 1 ? ` <span class="chip info">${n} screenshots</span>` : ''}</div>
        <div class="meta">${f.total !== undefined ? '<b>' + esc(f.currency || 'MYR') + ' ' + f.total.toFixed(2) + '</b>' : '<span class="pending">total not read</span>'} · ${esc(f.date || 'date ?')}${f.invoiceRef ? ' · ' + esc(f.invoiceRef) : ''} · from ${esc(ev.uploadedBy)}</div></div>
        ${ev.extraction ? (w ? chip(w + ' to check', 'warn') : chip('read', 'ok')) : chip('not read', 'off')}${ev.hint ? chip('known vendor', 'info') : ''}
        ${canW ? `${n > 1 ? `<button class="btn sm ghost" data-split="${esc(ev.id)}" title="These screenshots are different receipts">Split</button>` : ''}<button class="btn sm primary" data-rv="${esc(ev.id)}">Review</button><button class="btn sm ghost" data-ds="${esc(ev.id)}" title="Not an expense">✕</button>` : ''}</div>`;
    };
    return `<section class="panel inbox"><div class="panel-head"><h2>Receipt inbox</h2><span class="chip warn">${B.inbox.length} waiting</span><div class="spacer"></div>${canW ? `<button class="btn sm" id="ibCombine" disabled title="Tick two or more screenshots of the same order">Combine selected</button><button class="btn sm primary" data-scan>${I('camera')}Scan receipts</button>` : ''}</div>
      <p class="muted small" style="margin:0 0 8px">Long order pages in two screenshots are combined automatically when they show the same order number. Otherwise tick them and press Combine selected.</p>
      <div class="list inbox-list">${B.inbox.map(row).join('')}</div></section>`;
  }
  function inboxAfter() {
    $$('[data-scan]').forEach(b => b.addEventListener('click', scanReceipts));
    const sel = () => $$('.ib-sel:checked').map(c => c.dataset.sel);
    $$('.ib-sel').forEach(c => c.addEventListener('change', () => { $('#ibCombine').disabled = sel().length < 2; }));
    $('#ibCombine')?.addEventListener('click', async () => {
      const ids = sel(); if (ids.length < 2) return;
      const order = B.inbox.filter(v => ids.includes(v.id)).sort((a, b) => a.uploadedAt.localeCompare(b.uploadedAt));
      try { await api(`/finance/inbox/${order[0].id}/combine`, { method: 'POST', body: { ids: order.slice(1).map(v => v.id) } }); toast(`${ids.length} screenshots combined into one receipt`, 'ok'); B.inbox = null; render(); } catch (e) { toast(e.message, 'err'); }
    });
    $$('[data-split]').forEach(b => b.addEventListener('click', async () => {
      if (!await confirmDialog('Split into separate receipts?', 'Each screenshot becomes its own receipt again and will not be combined automatically.', 'Split', false)) return;
      try { await api(`/finance/inbox/${b.dataset.split}/split`, { method: 'POST' }); B.inbox = null; render(); } catch (e) { toast(e.message, 'err'); }
    }));
    const open = i => { const list = B.inbox || []; if (!list[i]) return; reviewReceipt(list[i], () => { if (Array.isArray(B.inbox) && B.inbox.length) reviewReceipt(B.inbox[0], null); }); };
    $$('[data-rv]').forEach(b => b.addEventListener('click', () => open(B.inbox.findIndex(v => v.id === b.dataset.rv))));
    $$('[data-ds]').forEach(b => b.addEventListener('click', () => dismissReceipt(B.inbox.find(v => v.id === b.dataset.ds))));
  }

  function expenseDetail(e) {
    const canW = hasPerm('finance.write'), canA = hasPerm('finance.approve');
    const ev = (B.evidenceAll || []).filter(v => e.evidenceIds.includes(v.id));
    const m = openModal(`<h3>${esc(e.id)} ${e.voided ? chip('void', 'off') : chip(e.status)} ${chip(e.paymentStatus)}</h3>
      <div class="kv-list" style="margin-top:12px">
        <div class="kv-row"><span>Vendor</span><div>${esc(e.vendor)}</div></div><div class="kv-row"><span>Description</span><div>${esc(e.description)}</div></div>
        <div class="kv-row"><span>Amount</span><div>${esc(e.currency)} ${fmt(e.amount, 2)}${e.currency !== 'MYR' ? ` × ${esc(e.exchangeRate)} (${esc(e.rateSource)})` : ''} = <b>${myr(e.amountMYR)}</b></div></div>
        <div class="kv-row"><span>Type / category</span><div>${esc(B.meta.natures[e.nature])}${e.category ? ' · ' + esc(e.category) : ''}</div></div>
        <div class="kv-row"><span>Funding / paid by</span><div>${esc(B.meta.funding[e.fundingSource])}${e.paidBy ? ' · ' + esc(e.paidBy) : ''} · ${esc(e.paymentMethod.replace('_', ' '))}${e.paidDate ? ' · paid ' + esc(e.paidDate) : ''}</div></div>
        <div class="kv-row"><span>Linked to</span><div>${[e.pocId, e.cycleId, e.pondId].filter(Boolean).map(esc).join(' · ') || DASH}</div></div>
        <div class="kv-row"><span>Invoice no.</span><div>${esc(e.invoiceRef || DASH)}</div></div>
        ${e.nature === 'CAPEX' ? `<div class="kv-row"><span>Depreciation</span><div>${e.usefulLifeMonths ? e.usefulLifeMonths + ' months from ' + esc(e.inServiceDate) : '<span class="pending">No useful life set: not depreciated</span>'}</div></div>` : ''}
        <div class="kv-row"><span>Recorded</span><div>${esc(e.createdBy)} · ${dateTime(e.createdAt)}${e.approvedBy ? ` · ${e.status} by ${esc(e.approvedBy)}${e.selfApproved ? ' (self-approved)' : ''}` : ''}</div></div>
        ${e.voided ? `<div class="kv-row"><span>Voided</span><div>${esc(e.voidedBy)} · ${esc(e.voidReason)}</div></div>` : ''}
        <div class="kv-row"><span>Evidence</span><div>${e.evidenceIds.length ? e.evidenceIds.map(id => `<a href="/api/evidence/${encodeURIComponent(id)}/file">${esc(id)}</a>`).join(', ') : '<span class="pending">No receipt attached</span>'}</div></div>
      </div>
      <div class="modal-actions" style="justify-content:flex-start">
        ${!e.voided && hasPerm('evidence.write') ? `<button class="btn sm primary" id="edAttach">${I('plus')}Attach receipt</button>` : ''}
        ${!e.voided && canA && e.status === 'pending' ? '<button class="btn sm" id="edApprove">Approve</button><button class="btn sm danger" id="edReject">Reject</button>' : ''}
        ${!e.voided && canW ? `<button class="btn sm" id="edPay">${e.paymentStatus === 'paid' ? 'Mark unpaid' : 'Mark paid'}</button><button class="btn sm" id="edEdit">${I('edit')}Edit</button><button class="btn sm ghost danger" id="edVoid">Void</button>` : ''}
        <button class="btn sm ghost" id="edHist">History</button><div style="flex:1"></div><button class="btn sm" data-x>Close</button></div>`, { wide: true });
    m.querySelector('[data-x]').onclick = closeModal;
    const act = async (path, body, msg) => { try { await api(`/finance/expenses/${e.id}/${path}`, { method: 'POST', body: body || {} }); closeModal(); toast(msg, 'ok'); B.expenses = null; render(); } catch (err) { toast(err.message, 'err'); } };
    $('#edApprove')?.addEventListener('click', () => act('approve', {}, 'Approved'));
    $('#edReject')?.addEventListener('click', () => act('reject', {}, 'Rejected'));
    $('#edPay')?.addEventListener('click', () => act('payment', { paid: e.paymentStatus !== 'paid' }, 'Payment status updated'));
    $('#edEdit')?.addEventListener('click', () => expenseForm(e));
    $('#edAttach')?.addEventListener('click', () => evidenceUpload({ links: [{ type: 'expense', id: e.id }].concat(e.pocId ? [{ type: 'poc', id: e.pocId }] : []), type: 'receipt', title: `${e.vendor} ${e.invoiceRef || e.id}` }));
    $('#edVoid')?.addEventListener('click', () => {
      const mm = openModal(`<h3>Void ${esc(e.id)}</h3><p class="muted small">The record stays visible as voided. It no longer counts in totals.</p><label class="field">Reason (required)<input type="text" id="vdR" maxlength="500"></label><div class="modal-actions"><button class="btn" data-x>Cancel</button><button class="btn danger" id="vdGo">Void expense</button></div>`);
      mm.querySelector('[data-x]').onclick = closeModal;
      $('#vdGo').onclick = () => act('void', { reason: val('#vdR') }, 'Voided');
    });
    $('#edHist')?.addEventListener('click', () => auditModal('expense', e.id));
  }

  // ------------------------------------------------------------------ Evidence vault
  const evQuery = () => new URLSearchParams(Object.entries(B.evFilter).filter(([, v]) => v)).toString();
  const size = n => (n >= 1048576 ? (n / 1048576).toFixed(1) + ' MB' : Math.max(1, Math.round(n / 1024)) + ' KB');
  VIEWS.evidence = () => {
    if (needLoad('evidence', async () => { await bizMeta(); B.evidence = await api('/evidence?' + evQuery()); })) return loadingView();
    const T = B.meta.evidenceTypes, F = B.evFilter, list = B.evidence;
    return `<section class="row"><p class="muted" style="margin:0;max-width:80ch">Receipts, photos, test results and agreements for due diligence. Each file keeps its SHA-256 fingerprint: AQUA can show a stored file has not changed since upload, but a fingerprint alone does not prove the document itself is genuine.</p></section>
      <section class="panel"><div class="row filters">
        <select id="efType">${opts(Object.entries(T).map(([k, v]) => [k, v.label]), F.type, 'All types')}</select>
        <select id="efVer">${opts([['unverified', 'Unverified'], ['verified', 'Verified'], ['rejected', 'Rejected']], F.verification, 'Any verification')}</select>
        <input type="text" id="efQ" value="${esc(F.q || '')}" placeholder="Search title, file name, ID…">
        <label class="row" style="flex-wrap:nowrap;gap:6px"><input type="checkbox" id="efArch" ${F.archived ? 'checked' : ''}> <span class="small">Show archived</span></label>
        ${F.linkId ? `<span class="chip info">Linked to ${esc(F.linkType)} ${esc(F.linkId)}</span>` : ''}
        <button class="btn sm" id="efGo">Apply</button><div style="flex:1"></div>
        <a class="btn sm" href="/api/evidence/index.csv">${I('download')}Evidence index</a>
        ${hasPerm('evidence.write') ? `<button class="btn sm" data-scan>${I('camera')}Scan receipts</button><button class="btn sm primary" id="evNew">${I('plus')}Upload</button>` : ''}</div>
      ${list.length ? `<div class="scroll-x table-wrap"><table class="tbl"><thead><tr><th>ID</th><th>Title</th><th>Type</th><th>File</th><th>SHA-256</th><th>Verification</th><th>Uploaded</th><th>Links</th><th></th></tr></thead><tbody>
        ${list.map(v => `<tr class="${v.archived ? 'voided' : ''}"><td class="small">${esc(v.id)}${v.confidential ? ' ' + I('lock', 'ico-inline') : ''}</td><td class="wrap"><b>${esc(v.title)}</b>${v.description ? `<div class="muted small">${esc(v.description)}</div>` : ''}${v.sameContentAs ? `<div class="pending small">Same file as ${esc(v.sameContentAs)}</div>` : ''}</td>
          <td class="small">${esc(T[v.type]?.label || v.type)}</td><td class="small">v${v.current.v} · ${esc(v.current.mime.split('/')[1])} · ${size(v.current.size)}</td><td class="mono small" title="${esc(v.current.sha256)}">${esc(v.current.sha256.slice(0, 12))}…</td>
          <td>${chip(v.verification)}${v.reviewer ? `<div class="muted small">${esc(v.reviewer)}</div>` : ''}</td><td class="small">${esc(v.uploadedBy)}<div class="muted">${dateTime(v.uploadedAt)}</div></td>
          <td class="small">${v.links.map(l => esc(l.type + ' ' + l.id)).join('<br>') || DASH}</td>
          <td><div class="row" style="flex-wrap:nowrap;gap:6px"><a class="btn sm" href="/api/evidence/${encodeURIComponent(v.id)}/file" title="Download">${I('download')}</a><button class="btn sm ghost" data-evd="${esc(v.id)}">More</button></div></td></tr>`).join('')}
      </tbody></table></div>` : '<div class="empty big"><b>No evidence yet</b>Upload the PL purchase receipt, pond photos, water test sheets and calibration records as you go. Missing evidence lowers the POC completeness score.</div>'}</section>`;
  };
  VIEWS.evidence.after = () => {
    if (!Array.isArray(B.evidence)) return;
    B.evidenceAll = B.evidence;
    $('#efGo')?.addEventListener('click', () => { B.evFilter = { ...B.evFilter, type: val('#efType'), verification: val('#efVer'), q: val('#efQ'), archived: $('#efArch').checked ? '1' : '' }; B.evidence = null; render(); });
    $('#evNew')?.addEventListener('click', () => evidenceUpload({}));
    $$('[data-scan]').forEach(b => b.addEventListener('click', async () => { await bizMeta(); if (!B.pocs) B.pocs = await api('/poc').catch(() => []); scanReceipts(); }));
    $$('[data-evd]').forEach(b => b.addEventListener('click', () => evidenceDetail(B.evidence.find(v => v.id === b.dataset.evd))));
  };
  function evidenceUpload(pre, versionOf) {
    const T = B.meta?.evidenceTypes || {};
    const linkOpts = [...(B.pocs || []).map(p => ['poc:' + p.id, 'POC ' + p.id + ' ' + p.name]), ...state.cycles.map(c => ['cycle:' + c.id, 'Cycle ' + c.id]), ...(Array.isArray(B.expenses) ? B.expenses : []).slice(0, 200).map(e => ['expense:' + e.id, 'Expense ' + e.id + ' ' + e.vendor])];
    const preLinks = (pre.links || []).map(l => l.type + ':' + l.id);
    const m = openModal(`<h3>${versionOf ? 'New version of ' + esc(versionOf.id) : 'Upload evidence'}</h3>
      <p class="muted small">PDF, JPG, PNG, WEBP, HEIC, MP4, MOV, CSV, TXT, XLSX or DOCX, up to ${B.meta?.maxFileMB || 50} MB. The file type is checked from its content, not its name.</p>
      <div class="form-grid" style="margin-top:12px">
        <label class="field full">File<input type="file" id="upFile" accept=".pdf,.jpg,.jpeg,.png,.webp,.heic,.mp4,.mov,.csv,.txt,.xlsx,.docx"></label>
        ${versionOf ? '<label class="field full">What changed<input type="text" id="upNote" maxlength="500"></label>' : `
        <label class="field">Type<select id="upType">${opts(Object.entries(T).map(([k, v]) => [k, v.label]), pre.type || 'receipt')}</select></label>
        <label class="field">Title<input type="text" id="upTitle" maxlength="160" value="${esc(pre.title || '')}"></label>
        <label class="field">Original date / time<small>When the photo was taken or the document dated (as stated)</small><input type="datetime-local" id="upOrig"></label>
        <label class="field">Link to<select id="upLink" multiple size="4">${linkOpts.map(([v, l]) => `<option value="${esc(v)}" ${preLinks.includes(v) ? 'selected' : ''}>${esc(l)}</option>`).join('')}</select></label>
        <label class="field full">Description<textarea id="upDesc" maxlength="2000"></textarea></label>
        <div class="row full"><label class="switch"><input type="checkbox" id="upConf"><span></span></label><span>Confidential (finance and admin roles only)</span></div>`}
      </div>
      <div class="modal-actions"><button class="btn" data-x>Cancel</button><button class="btn primary" id="upGo">Upload</button></div>`, { wide: true });
    const typeSel = $('#upType');
    const syncConf = () => { if (typeSel) $('#upConf').checked = !!T[typeSel.value]?.confidential; };
    syncConf(); typeSel?.addEventListener('change', syncConf);
    m.querySelector('[data-x]').onclick = closeModal;
    $('#upGo').onclick = async () => {
      const file = $('#upFile').files[0];
      if (!file) { toast('Choose a file', 'err'); return; }
      if (file.size > (B.meta?.maxFileMB || 50) * 1048576) { toast('File is larger than 50 MB', 'err'); return; }
      const meta = versionOf ? { originalName: file.name, note: val('#upNote') } : {
        originalName: file.name, type: val('#upType'), title: val('#upTitle') || file.name, description: val('#upDesc'), confidential: $('#upConf').checked,
        originalTimestamp: val('#upOrig') ? new Date(val('#upOrig')).toISOString() : null,
        links: [...$('#upLink').selectedOptions].map(o => { const [type, id] = o.value.split(':'); return { type, id }; }) };
      $('#upGo').disabled = true; $('#upGo').textContent = 'Uploading…';
      try {
        const bytes = new Uint8Array(await file.arrayBuffer());
        const metaB64 = btoa(String.fromCharCode(...new TextEncoder().encode(JSON.stringify(meta))));
        const res = await fetch(versionOf ? `/api/evidence/${encodeURIComponent(versionOf.id)}/versions` : '/api/evidence', { method: 'POST', headers: { 'X-AQUA': '1', 'Content-Type': 'application/octet-stream', 'X-Evidence-Meta': metaB64 }, body: bytes });
        const d = await res.json().catch(() => ({}));
        if (!res.ok) throw new Error(d.error || 'Upload failed');
        closeModal(); toast(`${d.id} stored · SHA-256 ${d.current.sha256.slice(0, 12)}…`, 'ok');
        B.evidence = null; B.expenses = null; B.pocDetail = null; render();
      } catch (e) { toast(e.message, 'err'); $('#upGo').disabled = false; $('#upGo').textContent = 'Upload'; }
    };
  }
  function evidenceDetail(v) {
    const T = B.meta.evidenceTypes;
    const m = openModal(`<h3>${esc(v.id)} ${chip(v.verification)}${v.archived ? ' ' + chip('archived', 'off') : ''}</h3>
      <div class="kv-list" style="margin-top:12px">
        <div class="kv-row"><span>Title</span><div>${esc(v.title)}</div></div><div class="kv-row"><span>Type</span><div>${esc(T[v.type]?.label)}${v.confidential ? ' · confidential' : ''}</div></div>
        <div class="kv-row"><span>Original date (as stated)</span><div>${v.originalTimestamp ? dateTime(v.originalTimestamp) : DASH}</div></div>
        <div class="kv-row"><span>Review</span><div>${v.reviewer ? esc(v.reviewer) + ' · ' + dateTime(v.reviewedAt) + (v.reviewNote ? ' · ' + esc(v.reviewNote) : '') : 'Not reviewed'}</div></div>
      </div>
      <h4 style="margin:14px 0 6px">Versions</h4><div class="scroll-x"><table class="tbl"><thead><tr><th>v</th><th>File</th><th>SHA-256</th><th>Size</th><th>Uploaded</th><th></th></tr></thead><tbody>
      ${v.versions.slice().reverse().map(x => `<tr><td>${x.v}</td><td class="small wrap">${esc(x.originalName)}</td><td class="mono small wrap">${esc(x.sha256)}</td><td class="small">${size(x.size)}</td><td class="small">${esc(x.uploadedBy)}<div class="muted">${dateTime(x.uploadedAt)}</div></td><td><a class="btn sm" href="/api/evidence/${encodeURIComponent(v.id)}/file?v=${x.v}">${I('download')}</a></td></tr>`).join('')}
      </tbody></table></div><div id="evCheck" class="small" style="margin-top:8px"></div>
      <div class="modal-actions" style="justify-content:flex-start">
        <button class="btn sm" id="evChk">Check file integrity</button>
        ${hasPerm('evidence.write') && !v.archived ? '<button class="btn sm" id="evVer">New version</button>' : ''}
        ${hasPerm('evidence.verify') ? '<button class="btn sm primary" id="evOk">Mark verified</button><button class="btn sm danger" id="evBad">Reject</button>' : ''}
        ${hasPerm('evidence.verify') ? `<button class="btn sm ghost" id="evArch">${v.archived ? 'Restore' : 'Archive'}</button>` : ''}
        <button class="btn sm ghost" id="evHist">History</button><div style="flex:1"></div><button class="btn sm" data-x>Close</button></div>`, { wide: true });
    m.querySelector('[data-x]').onclick = closeModal;
    const done = msg => { closeModal(); toast(msg, 'ok'); B.evidence = null; render(); };
    $('#evChk').onclick = async () => { try { const r = await api(`/evidence/${v.id}/check`); $('#evCheck').innerHTML = r.map(x => `v${x.v}: ${x.ok ? '<span class="chip ok">unchanged since upload</span>' : '<span class="chip crit">' + esc(x.problem || 'content changed') + '</span>'}`).join(' '); } catch (e) { toast(e.message, 'err'); } };
    $('#evVer')?.addEventListener('click', () => evidenceUpload({}, v));
    const review = status => {
      const mm = openModal(`<h3>${status === 'verified' ? 'Mark verified' : 'Reject evidence'}</h3><p class="muted small">Say what you checked, for example "matches bank statement 12 Nov".</p><label class="field">Note<input type="text" id="rvN" maxlength="1000"></label><div class="modal-actions"><button class="btn" data-x>Cancel</button><button class="btn primary" id="rvG">Save</button></div>`);
      mm.querySelector('[data-x]').onclick = closeModal;
      $('#rvG').onclick = async () => { try { await api(`/evidence/${v.id}/verify`, { method: 'POST', body: { status, note: val('#rvN') } }); done('Saved'); } catch (e) { toast(e.message, 'err'); } };
    };
    $('#evOk')?.addEventListener('click', () => review('verified'));
    $('#evBad')?.addEventListener('click', () => review('rejected'));
    $('#evArch')?.addEventListener('click', async () => {
      if (v.archived) { try { await api(`/evidence/${v.id}/restore`, { method: 'POST', body: {} }); done('Restored'); } catch (e) { toast(e.message, 'err'); } return; }
      const mm = openModal(`<h3>Archive ${esc(v.id)}</h3><p class="muted small">Archived evidence is hidden from lists but never deleted.</p><label class="field">Reason (required)<input type="text" id="arR" maxlength="500"></label><div class="modal-actions"><button class="btn" data-x>Cancel</button><button class="btn danger" id="arG">Archive</button></div>`);
      mm.querySelector('[data-x]').onclick = closeModal;
      $('#arG').onclick = async () => { try { await api(`/evidence/${v.id}/archive`, { method: 'POST', body: { reason: val('#arR') } }); done('Archived'); } catch (e) { toast(e.message, 'err'); } };
    });
    $('#evHist')?.addEventListener('click', () => auditModal('evidence', v.id));
  }

  // ------------------------------------------------------------------ Audit log
  function diffText(b, a) {
    if (!b || !a || typeof b !== 'object' || typeof a !== 'object') return '';
    const keys = [...new Set([...Object.keys(b), ...Object.keys(a)])].filter(k => !['updatedAt', 'updatedBy'].includes(k) && JSON.stringify(b[k]) !== JSON.stringify(a[k]));
    return keys.slice(0, 6).map(k => `${k}: ${JSON.stringify(b[k] ?? null).slice(0, 60)} → ${JSON.stringify(a[k] ?? null).slice(0, 60)}`).join('; ');
  }
  const auditRows = list => list.map(r => `<tr><td class="small">${dateTime(r.ts)}<div class="muted">#${r.seq}</div></td><td class="small">${esc(r.actor)}<div class="muted">${esc(r.role || '')}</div></td><td class="small"><b>${esc(r.action)}</b></td>
    <td class="small">${esc([r.entity, r.entityId].filter(Boolean).join(' '))}</td><td class="small wrap">${esc(r.reason || '')}${r.before && r.after ? `<div class="muted mono">${esc(diffText(r.before, r.after))}</div>` : ''}</td></tr>`).join('');
  async function auditModal(entity, id) {
    if (!hasPerm('audit.read')) { toast('Your role cannot read the audit log', 'err'); return; }
    try {
      const list = await api(`/audit?entity=${entity}&entityId=${encodeURIComponent(id)}`);
      const m = openModal(`<h3>History of ${esc(id)}</h3><div class="scroll-x" style="margin-top:12px"><table class="tbl"><thead><tr><th>When</th><th>Who</th><th>Action</th><th>Record</th><th>Reason / change</th></tr></thead><tbody>${auditRows(list)}</tbody></table></div><div class="modal-actions"><button class="btn" data-x>Close</button></div>`, { wide: true });
      m.querySelector('[data-x]').onclick = closeModal;
    } catch (e) { toast(e.message, 'err'); }
  }
  VIEWS.audit = () => {
    const F = B.auditFilter;
    if (needLoad('audit', async () => { B.audit = await api('/audit?' + new URLSearchParams(Object.entries({ ...F, limit: 300 }).filter(([, v]) => v))); })) return loadingView();
    return `<section class="panel"><div class="row filters">
        <select id="afEnt">${opts([['expense', 'Expenses'], ['poc', 'POCs'], ['evidence', 'Evidence'], ['user', 'Users'], ['monitoring', 'Monitoring & settings']], F.entity, 'Everything')}</select>
        <input type="text" id="afActor" value="${esc(F.actor || '')}" placeholder="User"><input type="text" id="afAct" value="${esc(F.action || '')}" placeholder="Action, e.g. expense. or auth.">
        <button class="btn sm" id="afGo">Apply</button><div style="flex:1"></div><span id="afVer"></span><button class="btn sm" id="afCheck">Verify audit chain</button></div>
      <p class="muted small">Each entry stores the fingerprint of the previous one, so a changed or deleted line is detected. This shows tampering; it does not prevent someone with server access from rewriting the whole file, which is why off-site backups matter.</p>
      ${B.audit.length ? `<div class="scroll-x table-wrap"><table class="tbl"><thead><tr><th>When</th><th>Who</th><th>Action</th><th>Record</th><th>Reason / change</th></tr></thead><tbody>${auditRows(B.audit)}</tbody></table></div>` : '<div class="empty">No entries match.</div>'}</section>`;
  };
  VIEWS.audit.after = () => {
    $('#afGo')?.addEventListener('click', () => { B.auditFilter = { entity: val('#afEnt'), actor: val('#afActor'), action: val('#afAct') }; B.audit = null; render(); });
    $('#afCheck')?.addEventListener('click', async () => { try { const r = await api('/audit/verify'); $('#afVer').innerHTML = r.ok ? `<span class="chip ok">Chain intact · ${r.count} entries</span>` : `<span class="chip crit">${esc(r.problem)}</span>`; } catch (e) { toast(e.message, 'err'); } });
  };

  // ------------------------------------------------------------------ Investor center (placeholder until v2.1.2)
  VIEWS.investor = () => `<section class="panel"><div class="empty big"><b>Investor center</b>You are signed in as an investor viewer. Reports that the founder publishes for you will appear here. Publishing, reports and PDF export arrive in version 2.1.2. Until then this account cannot see farm, finance or evidence data.</div></section>`;

  // ------------------------------------------------------------------ users (founder) + account panel
  function usersPanel() {
    if (!hasPerm('users.manage')) return '';
    if (needLoad('users', async () => { B.users = await api('/users'); })) return '<section class="panel"><div class="empty">Loading users…</div></section>';
    const R = B.users.roles;
    return `<section class="panel"><div class="panel-head"><h2>Users and roles</h2><div class="spacer"></div><button class="btn sm primary" id="usNew">${I('plus')}Add user</button></div>
      <div class="scroll-x"><table class="tbl"><thead><tr><th>User</th><th>Role</th><th>Status</th><th>Last sign-in</th><th>Sessions</th><th></th></tr></thead><tbody>
      ${B.users.users.map(u => `<tr><td><b>${esc(u.username)}</b>${u.username === state.auth.username ? ' <span class="muted small">(you)</span>' : ''}</td>
        <td><select data-urole="${esc(u.username)}" ${u.username === state.auth.username ? 'disabled' : ''}>${opts(Object.entries(R).map(([k, v]) => [k, v.label]), u.role)}</select></td>
        <td>${u.disabled ? chip('disabled', 'crit') : chip('active', 'ok')}</td><td class="small">${u.lastLoginAt ? rel(u.lastLoginAt) : 'never'}</td><td class="small">${u.activeSessions}</td>
        <td><div class="row" style="flex-wrap:nowrap;gap:6px">${u.username === state.auth.username ? '' : `<button class="btn sm ghost" data-ureset="${esc(u.username)}">Reset password</button><button class="btn sm ghost ${u.disabled ? '' : 'danger'}" data-udis="${esc(u.username)}" data-v="${u.disabled ? '0' : '1'}">${u.disabled ? 'Enable' : 'Disable'}</button>`}</div></td></tr>`).join('')}
      </tbody></table></div>
      <p class="muted small" style="margin-bottom:0">Roles are checked by the server on every request. Technical advisors and operators have no finance access; investor viewers see nothing until reports are published to them (v2.1.2). Changing a role signs that user out.</p></section>`;
  }
  function usersAfter() {
    if (!Array.isArray(B.users?.users)) return;
    const showTemp = (u, pw) => { const m = openModal(`<h3>Temporary password for ${esc(u)}</h3><p class="notice warn" style="margin:12px 0">Shown only once. Give it to the person privately; they should change it under Settings → Account.</p><pre class="code-box">${esc(pw)}</pre><div class="modal-actions"><button class="btn primary" data-x>Done</button></div>`); m.querySelector('[data-x]').onclick = closeModal; };
    $('#usNew')?.addEventListener('click', () => {
      const m = openModal(`<h3>Add user</h3><div class="form-grid" style="margin-top:12px"><label class="field">Username<input type="text" id="unName" maxlength="32" autocapitalize="none"></label>
        <label class="field">Role<select id="unRole">${opts(Object.entries(B.users.roles).filter(([k]) => k !== 'founder').map(([k, v]) => [k, v.label]), 'operator')}</select></label></div>
        <div class="modal-actions"><button class="btn" data-x>Cancel</button><button class="btn primary" id="unGo">Create user</button></div>`);
      m.querySelector('[data-x]').onclick = closeModal;
      $('#unGo').onclick = async () => { try { const r = await api('/users', { method: 'POST', body: { username: val('#unName'), role: val('#unRole') } }); B.users = null; showTemp(r.user.username, r.tempPassword); render(); } catch (e) { toast(e.message, 'err'); } };
    });
    $$('[data-urole]').forEach(sel => sel.addEventListener('change', async () => { try { await api('/users/' + encodeURIComponent(sel.dataset.urole), { method: 'PUT', body: { role: sel.value } }); toast('Role changed; that user was signed out', 'ok'); B.users = null; render(); } catch (e) { toast(e.message, 'err'); B.users = null; render(); } }));
    $$('[data-udis]').forEach(b => b.addEventListener('click', async () => { try { await api('/users/' + encodeURIComponent(b.dataset.udis), { method: 'PUT', body: { disabled: b.dataset.v === '1' } }); B.users = null; render(); } catch (e) { toast(e.message, 'err'); } }));
    $$('[data-ureset]').forEach(b => b.addEventListener('click', async () => { if (!await confirmDialog('Reset password?', 'The user is signed out and gets a new temporary password.', 'Reset', false)) return; try { const r = await api(`/users/${encodeURIComponent(b.dataset.ureset)}/reset-password`, { method: 'POST' }); showTemp(b.dataset.ureset, r.tempPassword); } catch (e) { toast(e.message, 'err'); } }));
  }
  function localAccountPanel() {
    return `<section class="panel"><div class="panel-head"><h2>Account</h2><div class="spacer"></div><span class="chip ok">Signed in as ${esc(state.auth?.username)} · ${esc(state.auth?.roleLabel || '')}</span></div>
      <div class="form-grid"><label class="field">Current password<input type="password" id="pwCur" autocomplete="current-password"></label>
      <label class="field">New password<small>At least 12 characters with letters and numbers</small><input type="password" id="pwNew" autocomplete="new-password"></label></div>
      <div class="modal-actions" style="justify-content:flex-start"><button class="btn primary" id="pwSave2">Change password</button><button class="btn ghost" id="logout2">Sign out</button></div></section>`;
  }
  function localAccountAfter() {
    $('#pwSave2')?.addEventListener('click', async () => { try { await api('/auth/password', { method: 'POST', body: { current: $('#pwCur').value, password: $('#pwNew').value } }); toast('Password changed. Other devices are signed out.', 'ok'); } catch (e) { toast(e.message, 'err'); } });
    $('#logout2')?.addEventListener('click', signOut);
  }

  // ------------------------------------------------------------ render
  const SUBS = {
    overview: () => state.info?.site?.name || '',
    ponds: () => pondList().length + ' registered from real telemetry',
    trends: () => 'Real stored history only',
    feeding: () => 'Schedules, commands and honest status',
    controls: () => 'Reserved for v2.2.0',
    apps: () => 'Any brand, any protocol',
    alerts: () => activeAlerts().length + ' active',
    calibration: () => 'pH probe calibration',
    water: () => 'Test-kit results and limits',
    poc: () => 'Trials with fixed success criteria',
    finance: () => 'Expense ledger, approvals and cost per kg',
    evidence: () => 'Receipts, photos and agreements with SHA-256',
    audit: () => 'Who changed what, when and why',
    investor: () => 'Read-only access',
    cycle: () => 'Stocking to harvest',
    settings: () => 'Server ' + (state.info?.hostname || '')
  };
  function render() {
    const r = route();
    const meta = ROUTES.find(x => x.id === r);
    document.title = meta.title + ' | SMARTFUZE AQUA';
    $('#pageTitle').textContent = meta.title;
    $('#pageSub').textContent = SUBS[r]?.() || '';
    charts.clear();
    document.body.classList.toggle('fit-ov', r === 'overview');
    renderNav();
    renderPondPicker();
    const view = $('#view');
    view.innerHTML = VIEWS[r]();
    mountCharts();
    if (VIEWS[r].after) VIEWS[r].after();
  }

  // live relative times
  setInterval(() => {
    for (const el of $$('[data-rel]')) { const ts = el.dataset.rel; el.textContent = ts ? rel(ts) : DASH; }
  }, 10000);

  // ------------------------------------------------------------ WebSocket
  let wsDelay = 1000;
  function connectWs() {
    const ws = new WebSocket((location.protocol === 'https:' ? 'wss://' : 'ws://') + location.host + '/ws');
    state.ws = ws;
    ws.onopen = async () => {
      const wasDown = state.loaded && !state.wsOk;
      state.wsOk = true; wsDelay = 1000;
      if (wasDown) { state.history = {}; await loadAll(); }
      render();
    };
    ws.onclose = async () => {
      state.wsOk = false; renderNav();
      if (state.ws !== ws) return; // replaced or closed on purpose
      if (state.auth?.required) {
        try { const st = await (await fetch('/api/auth/status', { cache: 'no-store' })).json(); if (!st.loggedIn) { showLogin('Please sign in again.'); return; } } catch (_) {}
      }
      setTimeout(connectWs, wsDelay);
      wsDelay = Math.min(wsDelay * 2, 15000);
    };
    ws.onerror = () => { try { ws.close(); } catch (_) {} };
    ws.onmessage = ev => {
      let msg; try { msg = JSON.parse(ev.data); } catch (_) { return; }
      handleWs(msg);
    };
  }
  const refetchTimers = {};
  function refetchSoon(kind) {
    clearTimeout(refetchTimers[kind]);
    refetchTimers[kind] = setTimeout(async () => { try { await load[kind](); } catch (_) {} if (!$('#modalRoot').innerHTML) render(); else renderNav(); }, 150);
  }
  function handleWs(msg) {
    const r = route();
    switch (msg.type) {
      case 'hello':
        for (const p of msg.ponds || []) state.ponds[p.id] = p;
        if (state.loaded) render();
        break;
      case 'telemetry':
      case 'pond': {
        const isNew = !state.ponds[msg.pond.id];
        state.ponds[msg.pond.id] = msg.pond;
        if (msg.type === 'telemetry' && msg.stored) {
          for (const k of Object.keys(state.history)) if (k.startsWith(msg.pond.id + '|')) delete state.history[k];
        }
        if (isNew) { toast(`${msg.pond.name} connected (real telemetry)`, 'ok'); load.integrations().catch(() => {}); }
        if (msg.type === 'telemetry' && $('#calLiveRaw')) { /* calibration view refreshes below */ }
        const liveRaw = $('#cLive');
        if (liveRaw && msg.pond.id === selectedPond()?.id) liveRaw.textContent = msg.pond.latest?.phRaw ?? DASH;
        if (['overview', 'ponds', 'calibration', 'trends'].includes(r) && !$('#modalRoot').innerHTML) {
          render();
          if (msg.type === 'telemetry' && r === 'overview') { $('#vTemp')?.classList.add('flash'); $('#vPh')?.classList.add('flash'); }
        } else renderNav();
        if (r === 'apps') refetchSoon('integrations');
        break;
      }
      case 'feedEvent':
        if (msg.event.status === 'Confirmed') toast('Feeding confirmed by the feeder', 'ok');
        if (msg.event.status === 'Failed') toast('Feeding failed: ' + (msg.event.detail || ''), 'err');
        refetchSoon('feeding');
        break;
      case 'alert':
        if (!msg.alert.resolvedAt && !msg.alert.acknowledged) toast(msg.alert.message, 'err');
        refetchSoon('alerts');
        break;
      case 'alerts': refetchSoon('alerts'); break;
      case 'integrations': refetchSoon('integrations'); break;
      case 'feeding': refetchSoon('feeding'); break;
      case 'calibrations': refetchSoon('calibrations'); break;
      case 'settings': refetchSoon('info'); refetchSoon('full'); break;
      case 'water': refetchSoon('water'); break;
      case 'backfill':
        for (const k of Object.keys(state.history)) if (k.startsWith(msg.pondId + '|')) delete state.history[k];
        if (['overview', 'trends'].includes(r) && !$('#modalRoot').innerHTML) render();
        break;
      case 'cycles': refetchSoon('cycles'); break;
    }
  }

  document.addEventListener('visibilitychange', async () => {
    if (document.visibilityState === 'visible' && state.loaded && !document.body.classList.contains('locked')) {
      state.history = {};
      await loadAll();
      if (!$('#modalRoot').innerHTML) render();
    }
  });

  window.addEventListener('hashchange', () => {
    if (location.hash === '#more') return;
    closeModal();
    render();
    window.scrollTo(0, 0);
    $('#view').focus({ preventScroll: true });
  });

  // ------------------------------------------------------------ login (cloud mode)
  async function refreshAuth() {
    try { state.auth = await (await fetch('/api/auth/status', { cache: 'no-store' })).json(); }
    catch (_) { state.auth = state.auth || { required: false, loggedIn: true, perms: [] }; }
  }
  async function afterSignIn() {
    document.body.classList.remove('locked');
    await refreshAuth();
    state.creds = null; state.history = {}; Object.assign(state.biz, { pocs: null, expenses: null, evidence: null, users: null, audit: null });
    await loadAll(); render();
    if (hasPerm('monitor.read')) connectWs();
  }
  async function signOut() {
    try { await api('/auth/logout', { method: 'POST' }); } catch (_) {}
    await refreshAuth();
    if (state.auth.required) showLogin('Signed out.'); else { location.hash = '#/overview'; render(); toast('Signed out', 'ok'); }
  }
  function showLogin(msg) {
    document.body.classList.add('locked');
    closeModal();
    if (state.ws) { const w = state.ws; state.ws = null; try { w.close(); } catch (_) {} }
    $('#pageTitle').textContent = 'Sign in'; $('#pageSub').textContent = ''; $('#pondPicker').innerHTML = '';
    const setup = state.auth?.needsSetup && state.auth?.canSetup;
    const back = !state.auth?.required ? '<button class="btn ghost" type="button" id="lgBack">Back to monitoring</button>' : '';
    $('#view').innerHTML = `<section class="panel login-card">
      <div class="login-brand"><svg viewBox="0 0 64 64" aria-hidden="true"><use href="#logo"/></svg><div><b>SMARTFUZE</b><span>AQUA</span></div></div>
      ${setup ? '<h3 style="margin:0 0 6px">Create the founder account</h3><p class="muted small" style="margin:0 0 10px">No account exists yet. This first account owns all business records and manages other users. It can only be created on this computer.</p>'
              : msg ? `<p class="muted small" style="margin:0 0 6px">${esc(msg)}</p>` : ''}
      <form id="loginForm" class="grid" style="gap:14px">
        <label class="field">Username<input type="text" id="lgUser" value="${setup ? '' : 'admin'}" autocomplete="username" autocapitalize="none" spellcheck="false"></label>
        <label class="field">Password${setup ? '<small>At least 12 characters with letters and numbers</small>' : ''}<input type="password" id="lgPass" autocomplete="${setup ? 'new-password' : 'current-password'}"></label>
        <button class="btn primary" type="submit" id="lgGo">${setup ? 'Create founder account' : 'Sign in'}</button>
        ${back}
        <p class="muted small" style="margin:0">Sessions last 7 to 30 days depending on the role. Finance roles sign in again every 14 days.</p>
      </form></section>`;
    setTimeout(() => (setup ? $('#lgUser') : $('#lgPass'))?.focus(), 50);
    $('#lgBack')?.addEventListener('click', () => { document.body.classList.remove('locked'); location.hash = '#/overview'; render(); });
    $('#loginForm').addEventListener('submit', async e => {
      e.preventDefault();
      $('#lgGo').disabled = true;
      try {
        const r = await fetch(setup ? '/api/auth/setup' : '/api/auth/login', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ username: $('#lgUser').value.trim(), password: $('#lgPass').value }) });
        const d = await r.json().catch(() => ({}));
        if (!r.ok) throw new Error(d.error || 'Sign-in failed');
        await afterSignIn();
      } catch (err) { toast(err.message, 'err'); $('#lgGo').disabled = false; }
    });
  }

  // ------------------------------------------------------------ boot
  (async () => {
    $('#view').innerHTML = `<div class="empty big"><b>Loading</b>Connecting to the AQUA server…</div>`;
    await refreshAuth();
    if (state.auth.required && !state.auth.loggedIn) { showLogin(); return; }
    await loadAll();
    render();
    if (hasPerm('monitor.read')) connectWs();
  })();
  setInterval(() => { if (state.wsOk) load.info().catch(() => {}); }, 60000);

  if ('serviceWorker' in navigator && (window.isSecureContext)) {
    window.addEventListener('load', () => navigator.serviceWorker.register('/sw.js').catch(() => {}));
  }
})();
